"use client";

import Link from "next/link";
import { useState, type ReactNode } from "react";

export type DashboardNavItem = {
  key: string;
  label: string;
  description?: string;
  href?: string;
  icon?: string;
  badge?: string;
};

type DashboardShellProps = {
  activeKey: string;
  navItems: readonly DashboardNavItem[];
  title: string;
  subtitle: string;
  userName: string;
  userLabel: string;
  schoolName?: string;
  children: ReactNode;
  onNavigate?: (key: string) => void;
  rightSlot?: ReactNode;
};

function NavButton({
  item,
  active,
  onClick,
}: {
  item: DashboardNavItem;
  active: boolean;
  onClick?: () => void;
}) {
  const content = (
    <>
      <span
        className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl text-sm font-black transition ${
          active ? "bg-white text-sky-800 shadow-sm" : "bg-slate-100 text-slate-500 group-hover:bg-sky-50 group-hover:text-sky-800"
        }`}
      >
        {item.icon ?? item.label.slice(0, 1)}
      </span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-sm font-black">{item.label}</span>
        {item.description && <span className="mt-0.5 block truncate text-xs font-semibold opacity-70">{item.description}</span>}
      </span>
      {item.badge && (
        <span className={`rounded-full px-2 py-1 text-[11px] font-black ${active ? "bg-white/20 text-white" : "bg-amber-100 text-amber-700"}`}>
          {item.badge}
        </span>
      )}
    </>
  );

  const className = `group flex w-full items-center gap-3 rounded-2xl px-3 py-3 text-left transition ${
    active
      ? "bg-sky-900 text-white shadow-lg shadow-slate-900/10"
      : "text-slate-600 hover:bg-slate-50 hover:text-slate-950"
  }`;

  if (item.href) {
    return (
      <Link href={item.href} className={className} onClick={onClick}>
        {content}
      </Link>
    );
  }

  return (
    <button type="button" className={className} onClick={onClick}>
      {content}
    </button>
  );
}

export function DashboardShell({
  activeKey,
  navItems,
  title,
  subtitle,
  userName,
  userLabel,
  schoolName,
  children,
  onNavigate,
  rightSlot,
}: DashboardShellProps) {
  const [open, setOpen] = useState(false);

  const sidebar = (
    <aside className="flex h-full flex-col bg-white">
      <div className="border-b border-slate-100 px-5 py-5">
        <Link href="/" className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-sky-900 text-sm font-black text-white shadow-lg shadow-slate-900/20">
            SL
          </div>
          <div className="min-w-0">
            <p className="truncate text-lg font-black tracking-tight text-slate-950">SkillLens</p>
            <p className="truncate text-xs font-semibold text-slate-500">Career Decision Support</p>
          </div>
        </Link>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-5">
        <p className="px-3 text-xs font-black uppercase tracking-[0.18em] text-slate-400">Menu utama</p>
        <nav className="mt-4 space-y-2">
          {navItems.map((item) => (
            <NavButton
              key={item.key}
              item={item}
              active={activeKey === item.key}
              onClick={() => {
                onNavigate?.(item.key);
                setOpen(false);
              }}
            />
          ))}
        </nav>
      </div>

      <div className="border-t border-slate-100 p-4">
        <div className="rounded-3xl bg-slate-950 p-4 text-white shadow-xl shadow-slate-900/10">
          <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-200">Status sekolah</p>
          <p className="mt-2 text-sm font-black leading-5">{schoolName ?? "Satuan pendidikan aktif"}</p>
          <div className="mt-4 h-2 overflow-hidden rounded-full bg-white/15">
            <div className="h-full w-[82%] rounded-full bg-cyan-300" />
          </div>
          <p className="mt-2 text-xs font-semibold text-slate-300">Kelengkapan data 82%</p>
        </div>
      </div>
    </aside>
  );

  return (
    <main className="min-h-screen bg-[#f2f5fb] text-slate-950">
      <header className="fixed inset-x-0 top-0 z-50 h-[72px] bg-slate-950 text-white shadow-lg shadow-slate-900/20">
        <div className="flex h-full items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <button
              type="button"
              onClick={() => setOpen(true)}
              className="grid h-11 w-11 place-items-center rounded-2xl bg-white/12 text-lg font-black backdrop-blur transition hover:bg-white/20 lg:hidden"
              aria-label="Buka menu"
            >
              Menu
            </button>
            <Link href="/" className="hidden items-center gap-3 lg:flex">
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white text-sm font-black text-sky-800 shadow-md">SL</div>
              <div>
                <p className="text-lg font-black tracking-tight">SkillLens</p>
                <p className="text-xs font-semibold text-white/70">Career Decision Support</p>
              </div>
            </Link>
          </div>

          <div className="hidden min-w-0 max-w-xl flex-1 items-center gap-3 rounded-2xl bg-white/13 px-4 py-3 text-sm font-semibold text-white/80 backdrop-blur md:flex">
            <span className="text-white/80">Cari</span>
            <span className="truncate">Cari siswa, kelas, hasil keputusan, atau agenda bimbingan</span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {rightSlot}
            <button type="button" className="hidden h-11 w-11 place-items-center rounded-2xl bg-white/12 text-base backdrop-blur transition hover:bg-white/20 sm:grid" aria-label="Notifikasi">
              N
            </button>
            <button type="button" className="hidden h-11 w-11 place-items-center rounded-2xl bg-white/12 text-base backdrop-blur transition hover:bg-white/20 sm:grid" aria-label="Pesan">
              P
            </button>
            <div className="flex items-center gap-3 rounded-2xl bg-white/14 px-3 py-2 backdrop-blur">
              <div className="grid h-9 w-9 place-items-center rounded-xl bg-amber-300 text-sm font-black text-slate-950">
                {userName.slice(0, 1)}
              </div>
              <div className="hidden text-right sm:block">
                <p className="text-sm font-black leading-4">{userName}</p>
                <p className="text-xs font-semibold text-white/70">{userLabel}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="fixed bottom-0 left-0 top-[72px] z-40 hidden w-[288px] border-r border-slate-200/70 bg-white shadow-xl shadow-slate-900/5 lg:block">
        {sidebar}
      </div>

      {open && (
        <div className="fixed inset-0 z-[60] lg:hidden">
          <button className="absolute inset-0 bg-slate-950/50" onClick={() => setOpen(false)} aria-label="Tutup menu" />
          <div className="absolute bottom-0 left-0 top-0 w-[min(320px,88vw)] shadow-2xl shadow-slate-950/30">{sidebar}</div>
        </div>
      )}

      <section className="pt-[72px] lg:pl-[288px]">
        <div className="mx-auto w-full max-w-[1560px] px-4 py-5 sm:px-6 lg:px-8 lg:py-8">
          <div className="mb-6 flex flex-col justify-between gap-4 xl:flex-row xl:items-end">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-sky-800">SkillLens Workspace</p>
              <h1 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950 sm:text-3xl lg:text-4xl">{title}</h1>
              <p className="mt-2 max-w-3xl text-sm font-semibold leading-7 text-slate-500">{subtitle}</p>
            </div>
          </div>
          {children}
        </div>
      </section>
    </main>
  );
}
