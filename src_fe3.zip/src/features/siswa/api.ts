import { apiFetch } from "../../lib/axios";
import type { CareerRoadmap, CriteriaBreakdown, Recommendation, StudentProfileForm } from "./types";

const delay = (ms = 300) => new Promise((resolve) => setTimeout(resolve, ms));


type AcademicProfileResponse = {
  id_siswa: number;
  nisn: string;
  nama: string;
  kelas: string;
  jurusan: string;
  nilai_akademik: Partial<Record<"numerik" | "bahasa" | "sains" | "sosial" | "teknologi" | "agama" | "kreativitas" | "softskill", number>>;
};

function average(values: Array<number | undefined>) {
  const valid = values.filter((value): value is number => typeof value === "number" && Number.isFinite(value));
  if (!valid.length) return 0;
  return Math.round(valid.reduce((total, value) => total + value, 0) / valid.length);
}

export async function getStudentAcademicProfile(idSiswa: number): Promise<Partial<StudentProfileForm> & { backendId: number; academicCategorySummary: AcademicProfileResponse["nilai_akademik"] }> {
  const response = await apiFetch<AcademicProfileResponse>(`/nilai-siswa/akademik/${idSiswa}`);
  const scores = response.nilai_akademik ?? {};

  return {
    backendId: response.id_siswa,
    name: response.nama,
    nisn: response.nisn,
    className: response.kelas,
    major: response.jurusan,
    bahasaIndonesia: Math.round(scores.bahasa ?? 0),
    bahasaInggris: Math.round(scores.bahasa ?? 0),
    matematika: Math.round(scores.numerik ?? 0),
    dll: average([scores.sains, scores.sosial, scores.teknologi, scores.agama, scores.kreativitas, scores.softskill]),
    academicFocus: `Nilai akademik sudah disinkronkan dari backend: numerik ${scores.numerik ?? 0}, bahasa ${scores.bahasa ?? 0}, sains ${scores.sains ?? 0}, sosial ${scores.sosial ?? 0}, teknologi ${scores.teknologi ?? 0}, agama ${scores.agama ?? 0}, kreativitas ${scores.kreativitas ?? 0}, softskill ${scores.softskill ?? 0}.`,
    academicCategorySummary: scores,
  };
}

type Alternative = {
  id: string;
  title: string;
  category: Recommendation["category"];
  summary: string;
  tags: string[];
  suggestedMajors: string[];
  roadmapId: string;
};

const alternatives: Alternative[] = [
  {
    id: "data-analyst-ai",
    title: "Data Analyst dan AI Specialist",
    category: "Karier",
    summary: "Arah ini cocok untuk siswa yang kuat pada matematika, logika, spreadsheet, data, dan ingin memahami AI secara terapan.",
    tags: ["data", "analisis", "matematika", "spreadsheet", "ai", "kecerdasan buatan", "dashboard", "statistik", "database"],
    suggestedMajors: ["Sains Data", "Sistem Informasi", "Statistika", "Informatika"],
    roadmapId: "data-analyst-ai",
  },
  {
    id: "software-engineer",
    title: "Software Engineer / Fullstack Developer",
    category: "Karier",
    summary: "Cocok untuk siswa yang tertarik membangun aplikasi, memahami logika pemrograman, dan menyukai proyek digital.",
    tags: ["web", "coding", "pemrograman", "aplikasi", "database", "react", "next", "teknologi", "problem solving"],
    suggestedMajors: ["Informatika", "Rekayasa Perangkat Lunak", "Teknik Komputer", "Sistem Informasi"],
    roadmapId: "software-engineer",
  },
  {
    id: "uiux-product",
    title: "UI/UX Product Designer",
    category: "Karier",
    summary: "Direkomendasikan untuk siswa yang kuat di visual, empati pengguna, desain, riset ringan, dan ingin membuat produk nyaman digunakan.",
    tags: ["desain", "ui", "ux", "figma", "visual", "produk", "kreatif", "riset", "komunikasi visual"],
    suggestedMajors: ["DKV", "Desain Produk", "Sistem Informasi", "Ilmu Komunikasi"],
    roadmapId: "uiux-product",
  },
  {
    id: "business-analyst",
    title: "Business Analyst / System Analyst",
    category: "Karier",
    summary: "Arah ini menggabungkan pemahaman proses bisnis, data, komunikasi, dokumentasi, dan kemampuan menjembatani user dengan tim teknis.",
    tags: ["bisnis", "analisis", "komunikasi", "manajemen", "proses bisnis", "dokumen", "presentasi", "spreadsheet"],
    suggestedMajors: ["Sistem Informasi", "Manajemen", "Bisnis Digital", "Akuntansi"],
    roadmapId: "business-analyst",
  },
  {
    id: "digital-marketing",
    title: "Creative Digital Marketing",
    category: "Karier",
    summary: "Cocok untuk siswa yang suka konten, komunikasi, tren media sosial, brand, dan ingin membaca performa kampanye.",
    tags: ["marketing", "konten", "komunikasi", "social media", "brand", "copywriting", "bisnis digital", "e-commerce"],
    suggestedMajors: ["Ilmu Komunikasi", "Marketing", "Bisnis Digital", "DKV"],
    roadmapId: "digital-marketing",
  },
  {
    id: "accounting-finance",
    title: "Accounting and Finance Path",
    category: "Kuliah",
    summary: "Cocok untuk siswa yang teliti, rapi, suka angka, catatan keuangan, dan ingin masuk ke akuntansi, pajak, atau finance.",
    tags: ["akuntansi", "keuangan", "teliti", "angka", "administrasi", "spreadsheet", "pajak", "laporan"],
    suggestedMajors: ["Akuntansi", "Manajemen Keuangan", "Perpajakan", "Administrasi Bisnis"],
    roadmapId: "accounting-finance",
  },
  {
    id: "health-public-service",
    title: "Health and Public Service",
    category: "Kuliah",
    summary: "Arah ini cocok untuk siswa yang empatik, suka membantu orang, tertarik kesehatan, pelayanan sosial, atau edukasi masyarakat.",
    tags: ["kesehatan", "empati", "keperawatan", "farmasi", "gizi", "pelayanan", "sosial", "relawan"],
    suggestedMajors: ["Kesehatan Masyarakat", "Keperawatan", "Farmasi", "Gizi"],
    roadmapId: "health-public-service",
  },
  {
    id: "engineering-technician",
    title: "Engineering Technician / Industrial Path",
    category: "Jalur Kerja",
    summary: "Cocok untuk siswa yang menyukai praktik teknik, mesin, listrik, manufaktur, maintenance, dan problem solving lapangan.",
    tags: ["teknik", "mesin", "elektro", "manufaktur", "robotika", "iot", "maintenance", "praktik"],
    suggestedMajors: ["Teknik Mesin", "Teknik Elektro", "Teknik Industri", "Mekatronika"],
    roadmapId: "engineering-technician",
  },
];

function averageScore(profile: StudentProfileForm) {
  return Math.round((profile.bahasaIndonesia + profile.bahasaInggris + profile.matematika + profile.dll) / 4);
}

function toCorpus(profile: StudentProfileForm) {
  return [
    profile.academicFocus,
    profile.goal,
    profile.learningPreference,
    profile.constraints,
    profile.achievements,
    ...profile.interests,
    ...profile.hobbies,
    ...profile.talents,
    ...profile.skills,
  ]
    .join(" ")
    .toLowerCase();
}

function tagScore(tags: string[], corpus: string) {
  const matches = tags.filter((tag) => corpus.includes(tag.toLowerCase())).length;
  return Math.min(100, 45 + matches * 9);
}

function fuzzyLabel(score: number): Recommendation["fuzzyLabel"] {
  if (score >= 86) return "Sangat cocok";
  if (score >= 76) return "Cocok";
  return "Cukup cocok";
}

function buildCriteria(profile: StudentProfileForm, alternative: Alternative): CriteriaBreakdown {
  const academicAverage = averageScore(profile);
  const corpus = toCorpus(profile);
  const interest = Math.max(
    tagScore(alternative.tags, corpus),
    Math.min(100, 52 + profile.interests.length * 4 + profile.hobbies.length * 2),
  );
  const talentSkill = Math.min(100, 55 + profile.talents.length * 4 + profile.skills.length * 3 + tagScore(alternative.tags, corpus) * 0.12);
  const goalFit = Math.min(100, 58 + (profile.goal.length > 40 ? 14 : 8) + (profile.constraints ? 4 : 0) + (profile.learningPreference ? 6 : 0));

  return {
    academic: academicAverage,
    interest: Math.round(interest),
    talentSkill: Math.round(talentSkill),
    goalFit: Math.round(goalFit),
  };
}

function weightedTopsisPreview(criteria: CriteriaBreakdown) {
  // Bobot eksplisit untuk perhitungan tampilan Fuzzy + TOPSIS.
  const score =
    criteria.academic * 0.35 +
    criteria.interest * 0.3 +
    criteria.talentSkill * 0.25 +
    criteria.goalFit * 0.1;
  return Math.round(score);
}

function reasonsFor(criteria: CriteriaBreakdown, alternative: Alternative, profile: StudentProfileForm) {
  const reasons = [
    `Nilai akademik rata-rata ${criteria.academic} mendukung pemrosesan TOPSIS.`,
    `Kecocokan minat/hobi pada topik ${alternative.tags.slice(0, 3).join(", ")} bernilai ${criteria.interest}.`,
    `Faktor bakat dan skill berada di skor ${criteria.talentSkill}, cocok untuk tahap roadmap awal.`,
  ];

  if (profile.goal.toLowerCase().includes("kerja") || profile.goal.toLowerCase().includes("magang")) {
    reasons.push("Tujuan siswa mengarah ke kesiapan kerja atau magang, sehingga roadmap dibuat lebih praktis.");
  } else {
    reasons.push("Tujuan siswa masih dapat diarahkan ke pilihan kuliah, pelatihan, atau jalur kerja yang relevan.");
  }

  return reasons;
}

export async function generateRecommendations(profile: StudentProfileForm): Promise<Recommendation[]> {
  await delay(320);

  const ranked = alternatives
    .map((alternative) => {
      const criteria = buildCriteria(profile, alternative);
      const score = weightedTopsisPreview(criteria);
      const corpus = toCorpus(profile);
      const dominantFactors = alternative.tags
        .filter((tag) => corpus.includes(tag.toLowerCase()))
        .slice(0, 4);

      return {
        id: alternative.id,
        title: alternative.title,
        category: alternative.category,
        score,
        fuzzyLabel: fuzzyLabel(score),
        topsisRank: 0,
        summary: alternative.summary,
        reasons: reasonsFor(criteria, alternative, profile),
        suggestedMajors: alternative.suggestedMajors,
        criteria,
        dominantFactors: dominantFactors.length ? dominantFactors : alternative.tags.slice(0, 3),
      } satisfies Recommendation;
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map((item, index) => ({ ...item, topsisRank: index + 1 }));

  return ranked;
}

export const careerRoadmaps: Record<string, CareerRoadmap> = {
  "data-analyst-ai": {
    careerId: "data-analyst-ai",
    headline: "Roadmap Data Analyst dan AI Specialist",
    targetRole: "Junior Data Analyst, BI Intern, AI Assistant Operator",
    initialCompleted: 2,
    steps: [
      {
        id: "da-1",
        phase: "Fondasi",
        title: "Kuasai spreadsheet dan statistik dasar",
        description: "Latih Excel atau Google Sheets, pivot table, rata-rata, korelasi, dan visualisasi sederhana.",
        duration: "2 minggu",
        output: "Mini dashboard nilai atau absensi kelas",
        checklist: ["Pivot table", "Grafik sederhana", "Interpretasi insight"],
      },
      {
        id: "da-2",
        phase: "Skill inti",
        title: "Belajar SQL dan pembersihan data",
        description: "Pelajari SELECT, WHERE, GROUP BY, JOIN, serta cara membaca data yang tidak rapi.",
        duration: "3 minggu",
        output: "Query laporan data akademik siswa",
        checklist: ["Query filter", "Group data", "Join dua tabel"],
      },
      {
        id: "da-3",
        phase: "Portofolio",
        title: "Bangun dashboard interaktif",
        description: "Gunakan Looker Studio, Power BI, atau dashboard web sederhana untuk menampilkan insight.",
        duration: "3 minggu",
        output: "Dashboard analisis karier SkillLens",
        checklist: ["Tentukan metrik", "Buat chart", "Tulis kesimpulan"],
      },
      {
        id: "da-4",
        phase: "AI dasar",
        title: "Pahami machine learning pemula",
        description: "Pelajari klasifikasi, regresi, evaluasi model, dan etika penggunaan AI.",
        duration: "4 minggu",
        output: "Notebook prediksi minat karier sederhana",
        checklist: ["Data latih", "Model dasar", "Evaluasi akurasi"],
      },
      {
        id: "da-5",
        phase: "Validasi",
        title: "Ikut lomba atau magang data",
        description: "Gunakan portofolio untuk daftar kompetisi data sekolah, magang, atau program kampus.",
        duration: "Berkelanjutan",
        output: "CV dan portofolio data siap kirim",
        checklist: ["CV ringkas", "Repo proyek", "Simulasi presentasi"],
      },
    ],
  },
  "software-engineer": {
    careerId: "software-engineer",
    headline: "Roadmap Software Engineer",
    targetRole: "Frontend Developer, Backend Intern, Fullstack Junior",
    initialCompleted: 1,
    steps: [
      {
        id: "se-1",
        phase: "Fondasi",
        title: "Kuatkan HTML, CSS, JavaScript, dan Git",
        description: "Bangun dasar web, layout responsif, logika JavaScript, serta version control.",
        duration: "3 minggu",
        output: "Landing page responsif di GitHub",
        checklist: ["Semantic HTML", "Responsive CSS", "Git commit"],
      },
      {
        id: "se-2",
        phase: "Frontend",
        title: "Bangun aplikasi dengan React atau Next.js",
        description: "Pelajari komponen, state, props, routing, form, dan pemanggilan API.",
        duration: "4 minggu",
        output: "Dashboard siswa SkillLens versi frontend",
        checklist: ["Component reusable", "State form", "Route halaman"],
      },
      {
        id: "se-3",
        phase: "Backend",
        title: "Pahami REST API dan database",
        description: "Pelajari autentikasi, relasi data, validasi request, dan desain endpoint.",
        duration: "4 minggu",
        output: "API data siswa dan hasil SPK",
        checklist: ["Endpoint GET", "Endpoint POST", "Validasi request"],
      },
      {
        id: "se-4",
        phase: "Kualitas",
        title: "Terapkan testing dan clean code",
        description: "Rapikan struktur folder, reusable component, error state, loading state, dan validasi form.",
        duration: "2 minggu",
        output: "Checklist kualitas aplikasi",
        checklist: ["Loading state", "Error state", "Code review"],
      },
      {
        id: "se-5",
        phase: "Karier",
        title: "Siapkan portofolio dan simulasi interview",
        description: "Dokumentasikan proyek, buat README, dan latihan menjelaskan keputusan teknis.",
        duration: "Berkelanjutan",
        output: "Portofolio siap magang",
        checklist: ["README", "Demo link", "Latihan wawancara"],
      },
    ],
  },
  "uiux-product": {
    careerId: "uiux-product",
    headline: "Roadmap UI/UX Product Designer",
    targetRole: "UI Designer, UX Research Assistant, Product Designer Intern",
    initialCompleted: 2,
    steps: [
      {
        id: "ux-1",
        phase: "Riset",
        title: "Pelajari masalah pengguna",
        description: "Buat persona, user journey, dan pertanyaan wawancara untuk memahami kebutuhan siswa.",
        duration: "2 minggu",
        output: "Dokumen persona siswa kelas akhir",
        checklist: ["Persona", "Pain point", "User journey"],
      },
      {
        id: "ux-2",
        phase: "Desain",
        title: "Buat wireframe dan design system",
        description: "Susun komponen tombol, card, form, warna, typography, dan alur halaman utama.",
        duration: "3 minggu",
        output: "Wireframe SkillLens di Figma",
        checklist: ["Wireframe", "Komponen", "Style guide"],
      },
      {
        id: "ux-3",
        phase: "Prototype",
        title: "Bangun prototype interaktif",
        description: "Hubungkan flow login, isi data, hasil rekomendasi, dan roadmap supaya bisa diuji.",
        duration: "2 minggu",
        output: "Prototype clickable untuk presentasi",
        checklist: ["Flow login", "Flow siswa", "Flow guru"],
      },
      {
        id: "ux-4",
        phase: "Testing",
        title: "Lakukan usability testing",
        description: "Minta 5 siswa mencoba prototype, catat hambatan, lalu perbaiki prioritas UI.",
        duration: "1 minggu",
        output: "Catatan testing dan revisi desain",
        checklist: ["Skenario test", "Catatan masalah", "Revisi prioritas"],
      },
      {
        id: "ux-5",
        phase: "Portofolio",
        title: "Susun case study",
        description: "Tulis konteks masalah, proses desain, keputusan UI, hasil testing, dan dampaknya.",
        duration: "1 minggu",
        output: "Case study UI/UX SkillLens",
        checklist: ["Problem", "Process", "Outcome"],
      },
    ],
  },
  "business-analyst": {
    careerId: "business-analyst",
    headline: "Roadmap Business Analyst",
    targetRole: "Business Analyst Intern, Product Analyst, System Analyst Junior",
    initialCompleted: 1,
    steps: [
      {
        id: "ba-1",
        phase: "Fondasi",
        title: "Pahami proses bisnis dan kebutuhan pengguna",
        description: "Latih membuat problem statement, stakeholder map, dan kebutuhan fungsional.",
        duration: "2 minggu",
        output: "Dokumen kebutuhan fitur SkillLens",
        checklist: ["Problem statement", "Stakeholder", "Kebutuhan fitur"],
      },
      {
        id: "ba-2",
        phase: "Analisis",
        title: "Belajar flowchart, use case, dan user story",
        description: "Terjemahkan kebutuhan ke diagram dan backlog yang mudah dipahami tim teknis.",
        duration: "3 minggu",
        output: "Use case guru dan siswa",
        checklist: ["Use case", "Flowchart", "User story"],
      },
      {
        id: "ba-3",
        phase: "Data",
        title: "Gunakan spreadsheet untuk analisis keputusan",
        description: "Buat matriks prioritas, bobot kriteria, skor alternatif, dan ringkasan insight.",
        duration: "2 minggu",
        output: "Template TOPSIS sederhana",
        checklist: ["Bobot kriteria", "Skor alternatif", "Ranking"],
      },
      {
        id: "ba-4",
        phase: "Komunikasi",
        title: "Latih presentasi rekomendasi",
        description: "Sampaikan masalah, data, alternatif solusi, risiko, dan keputusan yang diambil.",
        duration: "1 minggu",
        output: "Deck presentasi analisis bisnis",
        checklist: ["Insight", "Rekomendasi", "Risiko"],
      },
      {
        id: "ba-5",
        phase: "Portofolio",
        title: "Bangun case study sistem",
        description: "Dokumentasikan proses dari masalah sekolah sampai rancangan fitur yang siap dibangun.",
        duration: "Berkelanjutan",
        output: "Case study Business Analyst",
        checklist: ["Konteks", "Diagram", "Solusi"],
      },
    ],
  },
  "digital-marketing": {
    careerId: "digital-marketing",
    headline: "Roadmap Creative Digital Marketing",
    targetRole: "Social Media Specialist, SEO Junior, Content Strategist Intern",
    initialCompleted: 1,
    steps: [
      {
        id: "dm-1",
        phase: "Fondasi",
        title: "Pahami brand, audiens, dan channel digital",
        description: "Pelajari cara menentukan target audiens, pesan utama, dan kanal promosi.",
        duration: "2 minggu",
        output: "Persona audiens dan brand brief",
        checklist: ["Persona", "Channel", "Pesan utama"],
      },
      {
        id: "dm-2",
        phase: "Konten",
        title: "Buat kalender konten dan copywriting",
        description: "Susun ide konten edukasi, promosi, dan storytelling untuk beberapa platform.",
        duration: "3 minggu",
        output: "30 ide konten dan 5 caption siap publikasi",
        checklist: ["Ide konten", "Caption", "Format visual"],
      },
      {
        id: "dm-3",
        phase: "Data",
        title: "Baca metrik performa konten",
        description: "Pelajari reach, engagement, CTR, conversion, dan cara membuat insight sederhana.",
        duration: "2 minggu",
        output: "Laporan performa konten mingguan",
        checklist: ["Reach", "Engagement", "Insight"],
      },
      {
        id: "dm-4",
        phase: "Eksperimen",
        title: "Jalankan mini campaign",
        description: "Uji 2 konsep konten, bandingkan hasil, lalu tentukan perbaikan kampanye.",
        duration: "2 minggu",
        output: "Mini campaign report",
        checklist: ["Hipotesis", "Hasil", "Optimasi"],
      },
      {
        id: "dm-5",
        phase: "Portofolio",
        title: "Susun portfolio konten dan report",
        description: "Gabungkan brief, konten, metrik, dan insight menjadi case study yang mudah dinilai.",
        duration: "1 minggu",
        output: "Portfolio digital marketing",
        checklist: ["Brief", "Konten", "Report"],
      },
    ],
  },
  "accounting-finance": {
    careerId: "accounting-finance",
    headline: "Roadmap Accounting and Finance",
    targetRole: "Accounting Staff Intern, Finance Admin, Tax Assistant",
    initialCompleted: 1,
    steps: [
      {
        id: "af-1",
        phase: "Fondasi",
        title: "Kuatkan akuntansi dasar dan spreadsheet",
        description: "Latih jurnal umum, buku besar, neraca saldo, dan formula spreadsheet.",
        duration: "3 minggu",
        output: "Buku kas sederhana",
        checklist: ["Jurnal", "Buku besar", "Formula SUMIF"],
      },
      {
        id: "af-2",
        phase: "Laporan",
        title: "Buat laporan laba rugi dan arus kas",
        description: "Pahami struktur laporan keuangan sederhana dan cara membaca kondisi usaha.",
        duration: "3 minggu",
        output: "Laporan keuangan UMKM latihan",
        checklist: ["Laba rugi", "Arus kas", "Ringkasan"],
      },
      {
        id: "af-3",
        phase: "Pajak dasar",
        title: "Kenali pajak dan administrasi dokumen",
        description: "Pelajari dokumen transaksi, invoice, bukti kas, dan konsep pajak dasar.",
        duration: "2 minggu",
        output: "Folder dokumen transaksi rapi",
        checklist: ["Invoice", "Bukti kas", "Arsip"],
      },
      {
        id: "af-4",
        phase: "Tools",
        title: "Latih software akuntansi ringan",
        description: "Coba aplikasi akuntansi atau template spreadsheet untuk simulasi input transaksi.",
        duration: "2 minggu",
        output: "Simulasi input transaksi",
        checklist: ["Data vendor", "Data transaksi", "Export laporan"],
      },
      {
        id: "af-5",
        phase: "Karier",
        title: "Siapkan CV admin finance",
        description: "Tuliskan kemampuan spreadsheet, ketelitian, dan contoh laporan sebagai portofolio.",
        duration: "1 minggu",
        output: "CV dan portofolio finance admin",
        checklist: ["CV", "Portofolio", "Simulasi interview"],
      },
    ],
  },
  "health-public-service": {
    careerId: "health-public-service",
    headline: "Roadmap Health and Public Service",
    targetRole: "Health Promotion Volunteer, Clinic Admin, Public Service Assistant",
    initialCompleted: 1,
    steps: [
      {
        id: "hp-1",
        phase: "Eksplorasi",
        title: "Kenali bidang kesehatan dan pelayanan publik",
        description: "Bandingkan keperawatan, farmasi, gizi, kesehatan masyarakat, dan administrasi layanan.",
        duration: "2 minggu",
        output: "Matriks perbandingan jurusan kesehatan",
        checklist: ["Jurusan", "Prospek", "Risiko"],
      },
      {
        id: "hp-2",
        phase: "Empati",
        title: "Ikut kegiatan relawan atau edukasi kesehatan",
        description: "Latih komunikasi empatik, mendengar aktif, dan penyampaian informasi kesehatan sederhana.",
        duration: "3 minggu",
        output: "Catatan kegiatan relawan",
        checklist: ["Brief edukasi", "Dokumentasi", "Refleksi"],
      },
      {
        id: "hp-3",
        phase: "Data",
        title: "Belajar pencatatan dan rekam data sederhana",
        description: "Pahami data peserta, catatan pemeriksaan, privasi, dan ringkasan laporan layanan.",
        duration: "2 minggu",
        output: "Template data layanan masyarakat",
        checklist: ["Form data", "Privasi", "Laporan"],
      },
      {
        id: "hp-4",
        phase: "Kesiapan",
        title: "Pelajari syarat masuk jurusan kesehatan",
        description: "Cek mata pelajaran penting, biaya, praktik, dan kesiapan fisik maupun mental.",
        duration: "1 minggu",
        output: "Checklist kesiapan jurusan",
        checklist: ["Syarat", "Biaya", "Komitmen"],
      },
      {
        id: "hp-5",
        phase: "Validasi",
        title: "Konsultasi dengan guru BK dan keluarga",
        description: "Bahas hasil rekomendasi, minat, nilai, dan konsekuensi pilihan secara terbuka.",
        duration: "Berkelanjutan",
        output: "Keputusan pilihan prioritas",
        checklist: ["Diskusi guru", "Diskusi keluarga", "Rencana daftar"],
      },
    ],
  },
  "engineering-technician": {
    careerId: "engineering-technician",
    headline: "Roadmap Engineering Technician",
    targetRole: "Maintenance Technician, Industrial Operator, IoT Technician",
    initialCompleted: 1,
    steps: [
      {
        id: "et-1",
        phase: "Fondasi",
        title: "Kuatkan matematika terapan dan keselamatan kerja",
        description: "Latih satuan, pengukuran, logika rangkaian, dan prinsip K3.",
        duration: "2 minggu",
        output: "Checklist K3 dan catatan pengukuran",
        checklist: ["Satuan", "Pengukuran", "K3"],
      },
      {
        id: "et-2",
        phase: "Praktik",
        title: "Kerjakan proyek teknik kecil",
        description: "Buat rangkaian sederhana, mekanisme kecil, atau sensor IoT dasar.",
        duration: "4 minggu",
        output: "Prototipe teknik sederhana",
        checklist: ["Skema", "Komponen", "Uji coba"],
      },
      {
        id: "et-3",
        phase: "Dokumentasi",
        title: "Buat laporan teknis proyek",
        description: "Tulis tujuan, alat, langkah kerja, hasil pengujian, dan perbaikan.",
        duration: "1 minggu",
        output: "Laporan teknis proyek",
        checklist: ["Tujuan", "Langkah", "Hasil"],
      },
      {
        id: "et-4",
        phase: "Sertifikasi",
        title: "Cari pelatihan atau sertifikasi dasar",
        description: "Pilih pelatihan K3, listrik dasar, CAD, atau teknisi sesuai minat.",
        duration: "Berkelanjutan",
        output: "Daftar pelatihan prioritas",
        checklist: ["Biaya", "Jadwal", "Manfaat"],
      },
      {
        id: "et-5",
        phase: "Karier",
        title: "Siapkan lamaran magang teknisi",
        description: "Susun CV, foto proyek, laporan, dan latihan menjelaskan proses troubleshooting.",
        duration: "2 minggu",
        output: "CV teknisi dan portofolio proyek",
        checklist: ["CV", "Foto proyek", "Pitch"],
      },
    ],
  },
};

export function getRoadmapForCareer(careerId: string): CareerRoadmap {
  return careerRoadmaps[careerId] ?? careerRoadmaps["data-analyst-ai"];
}
