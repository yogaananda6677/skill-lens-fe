import { apiFetch } from "../../lib/axios";

export type AdminDashboardResponse = {
  stats: { schools: number; pendingSchools: number; teachers: number; students: number; majors?: number };
  activities: Array<{ title: string; text: string; tone: string }>;
};

export type VerificationRow = {
  id: number;
  school: string;
  level: string;
  city: string;
  status: string;
  address: string;
  phone: string;
};

export function getAdminDashboard() {
  return apiFetch<AdminDashboardResponse>("/admin/dashboard");
}

export function getSchoolVerifications() {
  return apiFetch<VerificationRow[]>("/admin/verifikasi");
}

export function approveSchool(id: number) {
  return apiFetch<{ message: string }>(`/admin/verifikasi/${id}`, { method: "PUT" });
}

export type AdminSchoolRow = { id: number; name: string; level: string; status: string; address: string; phone: string };
export type AdminMajorRow = { id: number; name: string; schoolId: number; schoolName: string };

export function getAdminSchools() {
  return apiFetch<AdminSchoolRow[]>("/admin/sekolah");
}

export function getAdminMajors(sekolahId?: number | string) {
  return apiFetch<AdminMajorRow[]>(`/admin/jurusan${sekolahId ? `?sekolahId=${sekolahId}` : ""}`);
}

export function createAdminMajor(payload: { id_sekolah: number | string; nama_jurusan: string }) {
  return apiFetch<AdminMajorRow>("/admin/jurusan", { method: "POST", body: JSON.stringify(payload) });
}
