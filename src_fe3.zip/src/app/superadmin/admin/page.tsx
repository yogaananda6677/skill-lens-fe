"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useState } from "react";
import {
  AdminUser,
  createAdmin,
  deleteAdmin,
  getAdmins,
  updateAdmin,
} from "../../../features/superadmin/api";

type FormState = {
  id_user?: number;
  nama: string;
  email: string;
  username: string;
  no_hp: string;
  password: string;
};

const emptyForm: FormState = {
  nama: "",
  email: "",
  username: "",
  no_hp: "",
  password: "",
};

export default function KelolaAdminPage() {
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [isModalOpen, setIsModalOpen] = useState(false);

  const isEdit = useMemo(() => Boolean(form.id_user), [form.id_user]);

  async function loadAdmins() {
    try {
      setLoading(true);
      setError("");
      const data = await getAdmins();
      setAdmins(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal mengambil data admin");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAdmins();
  }, []);

  function openCreateModal() {
    setForm(emptyForm);
    setError("");
    setMessage("");
    setIsModalOpen(true);
  }

  function openEditModal(admin: AdminUser) {
    setMessage("");
    setError("");
    setForm({
      id_user: admin.id_user,
      nama: admin.nama,
      email: admin.email,
      username: admin.username,
      no_hp: admin.no_hp || "",
      password: "",
    });
    setIsModalOpen(true);
  }

  function closeModal() {
    setIsModalOpen(false);
    setForm(emptyForm);
    setError("");
  }

  function handleChange(name: keyof FormState, value: string) {
    setForm((prev) => ({ ...prev, [name]: value }));
  }

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!form.nama || !form.email || !form.username) {
      setError("Nama, email, dan username wajib diisi.");
      return;
    }

    if (!isEdit && !form.password) {
      setError("Password wajib diisi saat membuat admin baru.");
      return;
    }

    try {
      setSaving(true);
      setError("");
      setMessage("");

      if (isEdit && form.id_user) {
        await updateAdmin(form.id_user, {
          nama: form.nama,
          email: form.email,
          username: form.username,
          no_hp: form.no_hp,
          ...(form.password ? { password: form.password } : {}),
        });

        setMessage("Data admin berhasil diperbarui.");
      } else {
        await createAdmin({
          nama: form.nama,
          email: form.email,
          username: form.username,
          no_hp: form.no_hp,
          password: form.password,
        });

        setMessage("Admin baru berhasil dibuat.");
      }

      closeModal();
      await loadAdmins();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal menyimpan data admin");
    } finally {
      setSaving(false);
    }
  }

  async function handleDelete(admin: AdminUser) {
    const confirmed = confirm(`Hapus admin ${admin.nama}?`);
    if (!confirmed) return;

    try {
      setError("");
      setMessage("");
      await deleteAdmin(admin.id_user);
      setMessage("Admin berhasil dihapus.");
      await loadAdmins();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal menghapus admin");
    }
  }

  function logout() {
    localStorage.clear();
    window.location.href = "/auth/login";
  }

  return (
    <main className="min-h-screen bg-slate-100 text-slate-950">
      <aside className="fixed inset-y-0 left-0 hidden w-72 border-r border-slate-200 bg-white lg:block">
        <div className="flex h-full flex-col">
          <div className="border-b border-slate-200 p-6">
            <Link href="/superadmin/admin" className="flex items-center gap-3">
              <div className="grid h-11 w-11 place-items-center rounded-2xl bg-slate-950 text-sm font-black text-white">
                SL
              </div>
              <div>
                <p className="font-black leading-5">SkillLens</p>
                <p className="text-xs font-bold text-slate-500">Superadmin Panel</p>
              </div>
            </Link>
          </div>

          <nav className="flex-1 space-y-2 p-4">
            <Link
              href="/superadmin/admin"
              className="flex items-center justify-between rounded-2xl bg-slate-950 px-4 py-3 text-sm font-black text-white"
            >
              <span>Kelola Admin</span>
              <span className="rounded-full bg-white/15 px-2 py-0.5 text-xs">Aktif</span>
            </Link>

            <Link
              href="/admin/dashboard"
              className="block rounded-2xl px-4 py-3 text-sm font-bold text-slate-600 hover:bg-slate-100 hover:text-slate-950"
            >
              Dashboard
            </Link>

            <Link
              href="/admin/verifikasi"
              className="block rounded-2xl px-4 py-3 text-sm font-bold text-slate-600 hover:bg-slate-100 hover:text-slate-950"
            >
              Verifikasi Sekolah
            </Link>

            <Link
              href="/admin/sekolah"
              className="block rounded-2xl px-4 py-3 text-sm font-bold text-slate-600 hover:bg-slate-100 hover:text-slate-950"
            >
              Data Sekolah
            </Link>
          </nav>

          <div className="border-t border-slate-200 p-4">
            <div className="rounded-2xl bg-slate-50 p-4">
              <p className="text-sm font-black">Superadmin</p>
              <p className="mt-1 text-xs font-bold text-slate-500">
                Mengelola akun admin sistem
              </p>
            </div>

            <button
              onClick={logout}
              className="mt-4 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-black text-slate-700 hover:bg-slate-50"
            >
              Keluar
            </button>
          </div>
        </div>
      </aside>

      <section className="lg:pl-72">
        <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
          <div className="flex items-center justify-between px-5 py-4 md:px-8">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-400">
                Superadmin
              </p>
              <h1 className="text-xl font-black md:text-2xl">Kelola Admin</h1>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={openCreateModal}
                className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-black text-white hover:bg-slate-800"
              >
                Tambah Admin
              </button>

              <button
                onClick={logout}
                className="rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-black text-slate-700 hover:bg-slate-50 lg:hidden"
              >
                Keluar
              </button>
            </div>
          </div>
        </header>

        <div className="space-y-6 p-5 md:p-8">
          <section className="grid gap-4 md:grid-cols-3">
            <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
              <p className="text-sm font-bold text-slate-500">Total Admin</p>
              <p className="mt-3 text-4xl font-black">{admins.length}</p>
              <p className="mt-1 text-sm font-semibold text-slate-500">Akun admin terdaftar</p>
            </div>

            <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
              <p className="text-sm font-bold text-slate-500">Hak Akses</p>
              <p className="mt-3 text-4xl font-black">Admin</p>
              <p className="mt-1 text-sm font-semibold text-slate-500">Verifikasi sekolah</p>
            </div>

            <div className="rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
              <p className="text-sm font-bold text-slate-500">Status</p>
              <p className="mt-3 text-4xl font-black text-emerald-600">Aktif</p>
              <p className="mt-1 text-sm font-semibold text-slate-500">Terhubung ke backend</p>
            </div>
          </section>

          {message && (
            <div className="rounded-2xl border border-emerald-200 bg-emerald-50 px-5 py-4 text-sm font-bold text-emerald-700">
              {message}
            </div>
          )}

          {error && !isModalOpen && (
            <div className="rounded-2xl border border-red-200 bg-red-50 px-5 py-4 text-sm font-bold text-red-700">
              {error}
            </div>
          )}

          <section className="rounded-3xl bg-white shadow-sm ring-1 ring-slate-200">
            <div className="flex flex-col justify-between gap-4 border-b border-slate-200 p-6 md:flex-row md:items-center">
              <div>
                <h2 className="text-xl font-black">Daftar Admin</h2>
                <p className="mt-1 text-sm text-slate-500">
                  Admin memiliki akses untuk memverifikasi data sekolah yang diajukan guru.
                </p>
              </div>

              <button
                onClick={openCreateModal}
                className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-black text-white hover:bg-slate-800"
              >
                Tambah Admin
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px] text-left">
                <thead className="bg-slate-50 text-xs font-black uppercase tracking-wider text-slate-500">
                  <tr>
                    <th className="px-6 py-4">Nama</th>
                    <th className="px-6 py-4">Username</th>
                    <th className="px-6 py-4">Email</th>
                    <th className="px-6 py-4">Kontak</th>
                    <th className="px-6 py-4 text-right">Aksi</th>
                  </tr>
                </thead>

                <tbody className="divide-y divide-slate-200">
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-sm font-bold text-slate-500">
                        Memuat data admin...
                      </td>
                    </tr>
                  ) : admins.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-12 text-center text-sm font-bold text-slate-500">
                        Belum ada admin yang dibuat.
                      </td>
                    </tr>
                  ) : (
                    admins.map((admin) => (
                      <tr key={admin.id_user} className="hover:bg-slate-50">
                        <td className="px-6 py-4">
                          <p className="font-black">{admin.nama}</p>
                          <p className="mt-1 text-xs font-bold uppercase text-slate-400">
                            {admin.role}
                          </p>
                        </td>

                        <td className="px-6 py-4 text-sm font-bold text-slate-700">
                          {admin.username}
                        </td>

                        <td className="px-6 py-4 text-sm font-semibold text-slate-600">
                          {admin.email}
                        </td>

                        <td className="px-6 py-4 text-sm font-semibold text-slate-600">
                          {admin.no_hp || "-"}
                        </td>

                        <td className="px-6 py-4">
                          <div className="flex justify-end gap-2">
                            <button
                              onClick={() => openEditModal(admin)}
                              className="rounded-xl border border-slate-200 px-4 py-2 text-xs font-black text-slate-700 hover:bg-white"
                            >
                              Edit
                            </button>

                            <button
                              onClick={() => handleDelete(admin)}
                              className="rounded-xl bg-red-50 px-4 py-2 text-xs font-black text-red-700 hover:bg-red-100"
                            >
                              Hapus
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </section>
        </div>
      </section>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/50 p-4 backdrop-blur-sm">
          <div className="w-full max-w-xl rounded-3xl bg-white shadow-2xl">
            <div className="flex items-start justify-between border-b border-slate-200 p-6">
              <div>
                <h2 className="text-2xl font-black">
                  {isEdit ? "Edit Admin" : "Tambah Admin"}
                </h2>
                <p className="mt-1 text-sm text-slate-500">
                  {isEdit
                    ? "Perbarui data admin. Kosongkan password jika tidak ingin mengganti."
                    : "Buat akun admin baru untuk membantu verifikasi sekolah."}
                </p>
              </div>

              <button
                onClick={closeModal}
                className="rounded-xl bg-slate-100 px-3 py-2 text-sm font-black text-slate-600 hover:bg-slate-200"
              >
                Tutup
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 p-6">
              {error && (
                <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-bold text-red-700">
                  {error}
                </div>
              )}

              <label className="block">
                <span className="text-sm font-bold text-slate-700">Nama lengkap</span>
                <input
                  value={form.nama}
                  onChange={(e) => handleChange("nama", e.target.value)}
                  className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold outline-none focus:border-slate-900 focus:bg-white"
                  placeholder="Contoh: Admin Pusat"
                />
              </label>

              <div className="grid gap-4 md:grid-cols-2">
                <label className="block">
                  <span className="text-sm font-bold text-slate-700">Email</span>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => handleChange("email", e.target.value)}
                    className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold outline-none focus:border-slate-900 focus:bg-white"
                    placeholder="admin@skilllens.local"
                  />
                </label>

                <label className="block">
                  <span className="text-sm font-bold text-slate-700">Username</span>
                  <input
                    value={form.username}
                    onChange={(e) => handleChange("username", e.target.value)}
                    className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold outline-none focus:border-slate-900 focus:bg-white"
                    placeholder="adminpusat"
                  />
                </label>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <label className="block">
                  <span className="text-sm font-bold text-slate-700">Nomor HP</span>
                  <input
                    value={form.no_hp}
                    onChange={(e) => handleChange("no_hp", e.target.value)}
                    className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold outline-none focus:border-slate-900 focus:bg-white"
                    placeholder="Opsional"
                  />
                </label>

                <label className="block">
                  <span className="text-sm font-bold text-slate-700">Password</span>
                  <input
                    type="password"
                    value={form.password}
                    onChange={(e) => handleChange("password", e.target.value)}
                    className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-semibold outline-none focus:border-slate-900 focus:bg-white"
                    placeholder={isEdit ? "Kosongkan jika tidak diganti" : "Minimal 6 karakter"}
                  />
                </label>
              </div>

              <div className="flex justify-end gap-3 border-t border-slate-200 pt-5">
                <button
                  type="button"
                  onClick={closeModal}
                  className="rounded-2xl border border-slate-200 px-5 py-3 text-sm font-black text-slate-700 hover:bg-slate-50"
                >
                  Batal
                </button>

                <button
                  disabled={saving}
                  className="rounded-2xl bg-slate-950 px-5 py-3 text-sm font-black text-white hover:bg-slate-800 disabled:opacity-60"
                >
                  {saving ? "Menyimpan..." : isEdit ? "Simpan Perubahan" : "Tambah Admin"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
}