"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { apiFetch } from "../../../lib/axios";
import { AppShell } from "../../../components/layout/AppShell";

type LoginResponse = {
  token: string;
  user: {
    id: number;
    nama: string;
    email?: string;
    username: string;
    role: "superadmin" | "admin" | "guru" | "siswa";
  };
};

function getRedirectPath(role: LoginResponse["user"]["role"]) {
  if (role === "superadmin") return "/superadmin/admin";
  if (role === "admin") return "/admin/dashboard";
  if (role === "guru") return "/guru";
  if (role === "siswa") return "/siswa";

  return "/";
}

export default function LoginPage() {
  const router = useRouter();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [rememberDevice, setRememberDevice] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleLogin(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const identifier = username.trim();

    if (!identifier || !password) {
      setError("Email/username dan password wajib diisi.");
      return;
    }

    setError("");
    setIsLoading(true);

    try {
      const data = await apiFetch<LoginResponse>("/auth/login", {
        method: "POST",
        body: JSON.stringify({
          username: identifier,
          password,
        }),
      });

      localStorage.setItem("skilllens_token", data.token);
      localStorage.setItem("skilllens_user", JSON.stringify(data.user));

      if (rememberDevice) {
        localStorage.setItem("skilllens_remember", "true");
      } else {
        localStorage.removeItem("skilllens_remember");
      }

      router.replace(getRedirectPath(data.user.role));
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login gagal. Periksa email/username dan password.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <AppShell
      active="auth"
      eyebrow="Login SkillLens"
      title="Masuk ke ruang kerja SkillLens."
      description="Gunakan akun yang sudah terdaftar untuk mengakses dashboard sesuai hak akses pengguna."
    >
      <div className="mx-auto grid max-w-5xl gap-6 lg:grid-cols-[1fr_0.85fr]">
        <section className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-900/5 md:p-8">
          <div className="mb-8">
            <p className="text-sm font-black uppercase tracking-[0.22em] text-[#0f2a5f]">
              Form masuk
            </p>
            <h2 className="mt-3 text-3xl font-black tracking-[-0.04em] text-slate-950">
              Gunakan akun yang sudah terdaftar
            </h2>
            <p className="mt-3 text-sm leading-7 text-slate-500">
              Masukkan email atau username dan password untuk masuk ke dashboard.
            </p>
          </div>

          <form className="space-y-5" onSubmit={handleLogin}>
            <label className="block">
              <span className="text-sm font-black text-slate-700">Email / username</span>
              <input
                value={username}
                onChange={(event) => setUsername(event.target.value)}
                autoComplete="username"
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
                placeholder="Masukkan email atau username"
              />
            </label>

            <label className="block">
              <span className="text-sm font-black text-slate-700">Password</span>
              <input
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                type="password"
                autoComplete="current-password"
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
                placeholder="Masukkan password"
              />
            </label>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <label className="flex items-center gap-3 text-sm font-bold text-slate-600">
                <input
                  type="checkbox"
                  checked={rememberDevice}
                  onChange={(event) => setRememberDevice(event.target.checked)}
                  className="h-4 w-4 accent-[#0f2a5f]"
                />
                Ingat perangkat ini
              </label>

              <span className="text-sm font-bold text-slate-500">
                Hubungi admin jika lupa password
              </span>
            </div>

            {error && (
              <div className="rounded-2xl bg-rose-50 p-4 text-sm font-bold text-rose-700 ring-1 ring-rose-100">
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={isLoading}
              className="flex w-full justify-center rounded-full bg-slate-950 px-6 py-4 text-sm font-black text-white shadow-xl shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-[#0f2a5f] disabled:cursor-not-allowed disabled:opacity-60"
            >
              {isLoading ? "Memeriksa akun..." : "Masuk ke dashboard"}
            </button>
          </form>

          <div className="mt-8 rounded-[1.5rem] bg-slate-50 p-5">
            <p className="font-black text-slate-950">Belum memiliki akun guru?</p>
            <p className="mt-1 text-sm font-bold leading-6 text-slate-500">
              Guru dapat membuat akun terlebih dahulu. Pemilihan sekolah dilakukan setelah berhasil login.
            </p>

            <Link
              href="/auth/register"
              className="mt-4 inline-flex rounded-full bg-white px-5 py-3 text-sm font-black text-[#0f2a5f] shadow-sm transition hover:-translate-y-0.5 hover:bg-[#eef5ff]"
            >
              Daftar akun guru
            </Link>
          </div>
        </section>

        <aside className="space-y-6">
          <section className="rounded-[2rem] bg-slate-950 p-6 text-white shadow-xl shadow-slate-900/10 md:p-8">
            <p className="text-sm font-black uppercase tracking-[0.24em] text-cyan-200">
              Hak akses pengguna
            </p>
            <h2 className="mt-3 text-3xl font-black tracking-[-0.04em]">
              Dashboard menyesuaikan peran akun.
            </h2>

            <div className="mt-6 space-y-3">
              {[
                {
                  title: "Superadmin",
                  text: "Mengelola akun admin dan dapat memantau proses verifikasi sekolah.",
                },
                {
                  title: "Admin",
                  text: "Memverifikasi data sekolah yang diajukan oleh guru.",
                },
                {
                  title: "Guru",
                  text: "Mengelola data siswa dan nilai setelah sekolah terverifikasi.",
                },
                {
                  title: "Siswa",
                  text: "Mengakses hasil dan informasi yang disediakan oleh sekolah.",
                },
              ].map((item) => (
                <div key={item.title} className="rounded-[1.25rem] border border-white/10 bg-white/8 p-4">
                  <p className="font-black">{item.title}</p>
                  <p className="mt-1 text-sm font-semibold leading-6 text-slate-300">
                    {item.text}
                  </p>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-900/5 md:p-8">
            <p className="text-sm font-black uppercase tracking-[0.24em] text-[#0f2a5f]">
              Informasi login
            </p>

            <div className="mt-5 space-y-4">
              {[
                "Akun guru dibuat melalui halaman pendaftaran guru.",
                "Akun siswa dibuat oleh sistem saat data siswa diproses oleh sekolah.",
                "Superadmin dan admin menggunakan akun yang dibuat melalui sistem manajemen pengguna.",
              ].map((item, index) => (
                <div key={item} className="flex gap-4 rounded-[1.25rem] bg-slate-50 p-4">
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-[#0f2a5f] text-sm font-black text-white">
                    {index + 1}
                  </div>
                  <p className="text-sm font-bold leading-6 text-slate-600">{item}</p>
                </div>
              ))}
            </div>
          </section>
        </aside>
      </div>
    </AppShell>
  );
}