"use client";

import { useEffect, useState } from "react";
import { DashboardShell, type DashboardNavItem } from "../../../components/layout/DashboardShell";
import { createAdminMajor, getAdminMajors, getAdminSchools, type AdminMajorRow, type AdminSchoolRow } from "../../../features/admin/api";

const navItems = [
  { key: "dashboard", label: "Dashboard", description: "Monitoring sistem", href: "/admin/dashboard", icon: "D" },
  { key: "verifikasi", label: "Verifikasi", description: "Sekolah", href: "/admin/verifikasi", icon: "V" },
  { key: "sekolah", label: "Data Sekolah", description: "Jurusan", href: "/admin/sekolah", icon: "S" },
] as const satisfies readonly DashboardNavItem[];

export default function AdminSchoolPage() {
  const [schools, setSchools] = useState<AdminSchoolRow[]>([]);
  const [majors, setMajors] = useState<AdminMajorRow[]>([]);
  const [selectedSchoolId, setSelectedSchoolId] = useState("");
  const [majorName, setMajorName] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  async function refresh() {
    const schoolData = await getAdminSchools();
    setSchools(schoolData);
    const nextSchoolId = selectedSchoolId || String(schoolData[0]?.id ?? "");
    setSelectedSchoolId(nextSchoolId);
    setMajors(nextSchoolId ? await getAdminMajors(nextSchoolId) : []);
  }

  useEffect(() => {
    refresh().catch((err) => setError(err instanceof Error ? err.message : "Gagal memuat data sekolah."));
  }, []);

  useEffect(() => {
    if (!selectedSchoolId) return;
    getAdminMajors(selectedSchoolId).then(setMajors).catch(() => setMajors([]));
  }, [selectedSchoolId]);

  return (
    <DashboardShell activeKey="sekolah" navItems={navItems} title="Data Sekolah dan Jurusan" subtitle="Kelola jurusan per sekolah. ID sekolah dan ID jurusan dipakai oleh sistem, tetapi tidak perlu ditampilkan kepada pengguna saat import nilai." userName="Super Admin" userLabel="Administrator" schoolName="Platform SkillLens">
      {(message || error) && <div className={`mb-5 rounded-2xl p-4 text-sm font-bold ${error ? "bg-rose-50 text-rose-700 ring-1 ring-rose-100" : "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"}`}>{error || message}</div>}

      <div className="grid gap-6 xl:grid-cols-[0.85fr_1.15fr]">
        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-xs font-black uppercase tracking-[0.2em] text-sky-700">Sekolah</p>
          <h2 className="mt-2 text-2xl font-black text-slate-950">Pilih sekolah</h2>
          <select value={selectedSchoolId} onChange={(event) => setSelectedSchoolId(event.target.value)} className="mt-5 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none focus:border-sky-700 focus:bg-white">
            {schools.map((school) => <option key={school.id} value={school.id}>{school.name} - {school.level} - {school.status === "approved" ? "Terverifikasi" : "Menunggu"}</option>)}
          </select>

          <form
            className="mt-6"
            onSubmit={async (event) => {
              event.preventDefault();
              setError("");
              setMessage("");
              try {
                await createAdminMajor({ id_sekolah: selectedSchoolId, nama_jurusan: majorName });
                setMajorName("");
                setMessage("Jurusan berhasil ditambahkan.");
                setMajors(await getAdminMajors(selectedSchoolId));
              } catch (err) {
                setError(err instanceof Error ? err.message : "Gagal menambahkan jurusan.");
              }
            }}
          >
            <label className="block">
              <span className="text-sm font-black text-slate-700">Nama jurusan baru</span>
              <input value={majorName} onChange={(event) => setMajorName(event.target.value)} placeholder="Contoh: Rekayasa Perangkat Lunak" className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none focus:border-sky-700 focus:bg-white" />
            </label>
            <button type="submit" className="mt-4 rounded-2xl bg-slate-950 px-5 py-4 text-sm font-black text-white transition hover:bg-sky-800">Tambah jurusan</button>
          </form>
        </section>

        <section className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <p className="text-xs font-black uppercase tracking-[0.2em] text-sky-700">Jurusan</p>
          <h2 className="mt-2 text-2xl font-black text-slate-950">Daftar jurusan sekolah</h2>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {majors.map((major) => <div key={major.id} className="rounded-2xl bg-slate-50 p-4"><p className="font-black text-slate-900">{major.name}</p><p className="mt-1 text-sm font-semibold text-slate-500">{major.schoolName}</p></div>)}
            {!majors.length && <p className="text-sm font-semibold text-slate-500">Belum ada jurusan untuk sekolah ini.</p>}
          </div>
        </section>
      </div>
    </DashboardShell>
  );
}
