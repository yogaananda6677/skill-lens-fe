"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { DashboardShell, type DashboardNavItem } from "../../../components/layout/DashboardShell";
import { getAdminDashboard, type AdminDashboardResponse } from "../../../features/admin/api";

const navItems = [
  { key: "dashboard", label: "Dashboard", description: "Monitoring sistem", href: "/admin/dashboard", icon: "D" },
  { key: "verifikasi", label: "Verifikasi", description: "Sekolah dan akun", href: "/admin/verifikasi", icon: "V" },
  { key: "sekolah", label: "Data Sekolah", description: "Jurusan", href: "/admin/sekolah", icon: "S" },
  { key: "laporan", label: "Laporan", description: "Aktivitas SPK", href: "/admin/dashboard", icon: "L" },
] as const satisfies readonly DashboardNavItem[];

type Metric = { label: string; value: string; detail: string; icon: string; tone: "navy" | "emerald" | "cyan" | "amber" };

function MetricCard({ item }: { item: Metric }) {
  const tone = {
    navy: "from-[#0f2a5f] to-[#1d4ed8]",
    emerald: "from-emerald-500 to-teal-300",
    amber: "from-amber-400 to-orange-300",
    cyan: "from-cyan-400 to-sky-400",
  }[item.tone];

  return (
    <article className="rounded-[1.4rem] border border-slate-100 bg-white p-5 shadow-lg shadow-slate-900/5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-400">{item.label}</p>
          <p className="mt-3 text-3xl font-black tracking-[-0.04em] text-slate-950">{item.value}</p>
        </div>
        <div className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${tone} text-lg font-black text-white shadow-lg shadow-slate-900/10`}>{item.icon}</div>
      </div>
      <p className="mt-3 text-sm font-semibold leading-6 text-slate-500">{item.detail}</p>
    </article>
  );
}

export default function AdminDashboardPage() {
  const [data, setData] = useState<AdminDashboardResponse | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    getAdminDashboard().then(setData).catch((err) => setError(err instanceof Error ? err.message : "Gagal mengambil dashboard"));
  }, []);

  const metrics = useMemo<Metric[]>(() => [
    { label: "Sekolah aktif", value: String(data?.stats.schools ?? 0), detail: "Satuan pendidikan dari database", icon: "S", tone: "navy" },
    { label: "Menunggu verifikasi", value: String(data?.stats.pendingSchools ?? 0), detail: "Sekolah perlu ditinjau admin", icon: "V", tone: "amber" },
    { label: "Pembimbing", value: String(data?.stats.teachers ?? 0), detail: "Akun guru dari database", icon: "G", tone: "emerald" },
    { label: "Siswa", value: String(data?.stats.students ?? 0), detail: "Akun siswa tersinkron", icon: "S", tone: "cyan" },
  ], [data]);

  return (
    <DashboardShell activeKey="dashboard" navItems={navItems} title="Dashboard Administrasi" subtitle="Pantau sekolah, akun pembimbing, data siswa, dan aktivitas sistem pendukung keputusan secara terpusat." userName="Admin Pusat" userLabel="Administrator" schoolName="Platform SkillLens">
      {error && <div className="mb-5 rounded-2xl bg-rose-50 p-4 text-sm font-bold text-rose-700 ring-1 ring-rose-100">{error}</div>}
      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">{metrics.map((item) => <MetricCard key={item.label} item={item} />)}</div>

      <div className="mt-6 grid gap-6 xl:grid-cols-[1.35fr_0.8fr]">
        <section className="rounded-[1.75rem] border border-slate-100 bg-white p-5 shadow-lg shadow-slate-900/5 sm:p-6">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Kinerja sistem</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Data langsung dari backend</h2>
              <p className="mt-2 max-w-2xl text-sm font-semibold leading-7 text-slate-500">Ringkasan ini membaca tabel sekolah, user guru, dan siswa melalui NestJS sehingga tidak lagi memakai data dummy.</p>
            </div>
            <Link href="/admin/verifikasi" className="rounded-full bg-slate-950 px-5 py-3 text-sm font-black text-white transition hover:-translate-y-0.5 hover:bg-[#0f2a5f]">Buka verifikasi</Link>
          </div>
          <div className="mt-6 rounded-[1.35rem] bg-[#f6f9ff] p-6">
            <p className="text-sm font-bold leading-7 text-slate-600">Pastikan backend aktif di alamat <span className="font-black text-[#0f2a5f]">NEXT_PUBLIC_API_URL</span> agar kartu metrik terisi dari database MySQL.</p>
          </div>
        </section>

        <section className="rounded-[1.75rem] border border-slate-100 bg-white p-5 shadow-lg shadow-slate-900/5 sm:p-6">
          <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Aktivitas terbaru</p>
          <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Timeline sistem</h2>
          <div className="mt-6 space-y-4">
            {(data?.activities ?? []).map((item, index) => (
              <div key={`${item.title}-${index}`} className="flex gap-4 rounded-[1.25rem] bg-slate-50 p-4">
                <div className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-white text-xs font-black text-[#0f2a5f] shadow-sm">{index + 1}</div>
                <div><p className="font-black text-slate-950">{item.title}</p><p className="mt-1 text-sm font-bold leading-6 text-slate-600">{item.text}</p></div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </DashboardShell>
  );
}
