import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SkillLens - Career Planning System",
  description: "Sistem pendukung perencanaan karier siswa berbasis web.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id" className="h-full scroll-smooth">
      <body className="min-h-full flex flex-col antialiased">{children}</body>
    </html>
  );
}
