"use client";

import Link from "next/link";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { DashboardShell, type DashboardNavItem } from "../../components/layout/DashboardShell";
import { generateRecommendations, getStudentAcademicProfile } from "../../features/siswa/api";
import { isApiConfigured } from "../../lib/axios";
import type { Recommendation, StudentProfileForm } from "../../features/siswa/types";
import { hobbyOptions, hobbyTotal, interestOptions, interestTotal, skillOptions, talentOptions } from "../../data/profile-options";

const initialProfile: StudentProfileForm = {
  name: "Alya Putri Rahmadani",
  nisn: "0012457788",
  school: "SMK Negeri 2 Jakarta",
  className: "XII RPL 1",
  major: "Rekayasa Perangkat Lunak",
  academicFocus: "Matematika, Informatika, Bahasa Inggris, database, dan dashboard data",
  bahasaIndonesia: 90,
  bahasaInggris: 92,
  matematika: 94,
  dll: 88,
  interests: ["Pengembangan web", "Analisis data", "Kecerdasan buatan", "Database design"],
  hobbies: ["Coding", "Membuat website", "Membuat dashboard", "Mencoba AI tools"],
  talents: ["Logika kuat", "Cepat memahami pola", "Suka membaca data"],
  skills: ["Problem solving", "Analisis data", "Spreadsheet", "Pemrograman dasar"],
  achievements: "Juara 2 lomba web design tingkat sekolah dan aktif membantu dokumentasi data kelas.",
  goal: "Ingin kuliah atau magang di bidang teknologi yang punya peluang kerja jelas dan bisa dimulai dari portofolio.",
  learningPreference: "Suka belajar lewat proyek, video singkat, dan latihan praktik bertahap.",
  constraints: "Masih mempertimbangkan biaya kuliah, lokasi kampus, dan peluang magang dekat sekolah.",
};

const studentNav = [
  { key: "profil", label: "Profil Karier", description: "Data diri dan minat", href: "/siswa", icon: "◎" },
  { key: "roadmap", label: "Roadmap", description: "Langkah belajar", href: "/siswa/roadmap", icon: "◇" },
  { key: "hasil", label: "Hasil SPK", description: "Tiga peringkat", href: "/siswa#hasil", icon: "▦" },
  { key: "bimbingan", label: "Bimbingan", description: "Catatan guru", href: "/siswa#bimbingan", icon: "◉" },
] as const satisfies readonly DashboardNavItem[];

type ArrayField = "interests" | "hobbies" | "talents" | "skills";
type TextField = "name" | "nisn" | "school" | "className" | "major" | "academicFocus" | "achievements" | "goal" | "learningPreference" | "constraints";

function ProgressBar({ value }: { value: number }) {
  return (
    <div className="h-2 overflow-hidden rounded-full bg-slate-100">
      <div className="h-full rounded-full bg-gradient-to-r from-[#0f2a5f] to-cyan-300" style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  );
}

function Panel({ children, className = "", id }: { children: ReactNode; className?: string; id?: string }) {
  return <section id={id} className={`rounded-[1.75rem] border border-slate-100 bg-white p-5 shadow-lg shadow-slate-900/5 sm:p-6 ${className}`}>{children}</section>;
}

function ToggleChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-full border px-4 py-2 text-sm font-black transition ${
        active ? "border-[#0f2a5f] bg-[#0f2a5f] text-white shadow-lg shadow-blue-950/20" : "border-slate-200 bg-white text-slate-600 hover:border-[#0f2a5f]/30 hover:text-[#0f2a5f]"
      }`}
    >
      {label}
    </button>
  );
}

function OptionPicker({
  title,
  subtitle,
  options,
  selected,
  onToggle,
  placeholder,
  maxVisible = 18,
}: {
  title: string;
  subtitle: string;
  options: readonly string[];
  selected: string[];
  onToggle: (value: string) => void;
  placeholder: string;
  maxVisible?: number;
}) {
  const [query, setQuery] = useState("");
  const visible = useMemo(() => {
    const keyword = query.trim().toLowerCase();
    const filtered = keyword ? options.filter((item) => item.toLowerCase().includes(keyword)) : options;
    const pinned = selected.filter((item) => !filtered.includes(item));
    return [...pinned, ...filtered].slice(0, maxVisible);
  }, [maxVisible, options, query, selected]);

  return (
    <div className="rounded-[1.35rem] border border-slate-100 bg-slate-50 p-4">
      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-start">
        <div>
          <p className="text-sm font-black text-slate-900">{title}</p>
          <p className="mt-1 text-xs font-bold leading-5 text-slate-500">{subtitle}</p>
        </div>
        <span className="w-fit rounded-full bg-white px-3 py-1 text-xs font-black text-[#0f2a5f] shadow-sm">{selected.length}/{options.length}</span>
      </div>
      <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder={placeholder} className="mt-4 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold outline-none transition placeholder:text-slate-400 focus:border-[#0f2a5f]" />
      <div className="mt-4 flex max-h-52 flex-wrap gap-2 overflow-y-auto pr-1">
        {visible.map((option) => <ToggleChip key={option} label={option} active={selected.includes(option)} onClick={() => onToggle(option)} />)}
      </div>
    </div>
  );
}

function ScoreInput({ label, value, onChange }: { label: string; value: number; onChange: (value: number) => void }) {
  return (
    <label className="block rounded-[1.25rem] bg-slate-50 p-4">
      <span className="text-xs font-black uppercase tracking-[0.18em] text-slate-400">{label}</span>
      <div className="mt-3 flex items-center gap-3">
        <input type="range" min={0} max={100} value={value} onChange={(event) => onChange(Number(event.target.value))} className="w-full accent-[#0f2a5f]" />
        <span className="w-12 rounded-full bg-white px-3 py-2 text-center text-sm font-black text-[#0f2a5f] shadow-sm">{value}</span>
      </div>
    </label>
  );
}

function readinessScores(profile: StudentProfileForm) {
  const academicAverage = Math.round((profile.bahasaIndonesia + profile.bahasaInggris + profile.matematika + profile.dll) / 4);
  const interestPower = Math.min(100, profile.interests.length * 12 + profile.hobbies.length * 7);
  const skillPower = Math.min(100, profile.talents.length * 12 + profile.skills.length * 8);
  const goalPower = Math.min(100, profile.goal.length > 80 ? 92 : profile.goal.length > 35 ? 78 : 58);
  const overall = Math.round(academicAverage * 0.35 + interestPower * 0.3 + skillPower * 0.25 + goalPower * 0.1);
  return { academicAverage, interestPower, skillPower, goalPower, overall };
}

function MetricCard({ label, value, detail, icon }: { label: string; value: string; detail: string; icon: string }) {
  return (
    <article className="rounded-[1.4rem] border border-slate-100 bg-white p-5 shadow-lg shadow-slate-900/5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-400">{label}</p>
          <p className="mt-3 text-3xl font-black tracking-[-0.04em] text-slate-950">{value}</p>
        </div>
        <div className="grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br from-[#0f2a5f] to-cyan-300 text-lg font-black text-white shadow-lg shadow-blue-950/20">{icon}</div>
      </div>
      <p className="mt-3 text-sm font-semibold leading-6 text-slate-500">{detail}</p>
    </article>
  );
}

function ProfileSnapshot({ profile }: { profile: StudentProfileForm }) {
  const scores = readinessScores(profile);
  const profileRows = [
    ["Nama", profile.name],
    ["NISN", profile.nisn],
    ["Sekolah", profile.school],
    ["Kelas", profile.className],
    ["Jurusan", profile.major],
  ];

  return (
    <Panel className="overflow-hidden">
      <div className="rounded-[1.5rem] bg-gradient-to-br from-slate-950 to-[#30337a] p-5 text-white">
        <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-start">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.2em] text-cyan-200">Profil siswa</p>
            <h2 className="mt-2 text-3xl font-black tracking-[-0.04em]">{profile.name}</h2>
            <p className="mt-2 text-sm font-semibold text-slate-300">{profile.className} · {profile.major}</p>
          </div>
          <div className="grid h-20 w-20 place-items-center rounded-[1.4rem] bg-cyan-300 text-2xl font-black text-slate-950">{scores.overall}</div>
        </div>
        <div className="mt-5"><ProgressBar value={scores.overall} /></div>
        <p className="mt-2 text-xs font-semibold text-slate-300">Kelengkapan dan kesiapan data untuk proses Fuzzy + TOPSIS</p>
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-2">
        {profileRows.map(([label, value]) => (
          <div key={label} className="rounded-2xl bg-slate-50 px-4 py-3">
            <p className="text-xs font-black uppercase tracking-[0.16em] text-slate-400">{label}</p>
            <p className="mt-1 text-sm font-black text-slate-950">{value}</p>
          </div>
        ))}
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-2">
        {[
          ["C1 Akademik", scores.academicAverage, "Nilai dari sekolah"],
          ["C2 Minat + hobi", scores.interestPower, `${profile.interests.length + profile.hobbies.length} indikator`],
          ["C3 Bakat + skill", scores.skillPower, `${profile.talents.length + profile.skills.length} indikator`],
          ["C4 Tujuan", scores.goalPower, "Rencana setelah lulus"],
        ].map(([label, value, detail]) => (
          <div key={label as string} className="rounded-2xl bg-slate-50 p-4">
            <div className="mb-2 flex justify-between gap-3 text-sm font-black text-slate-700">
              <span>{label}</span>
              <span className="text-[#0f2a5f]">{value}</span>
            </div>
            <ProgressBar value={Number(value)} />
            <p className="mt-2 text-xs font-bold text-slate-500">{detail}</p>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function ProfileDetail({ profile }: { profile: StudentProfileForm }) {
  const groups = [
    ["Minat utama", profile.interests],
    ["Hobi", profile.hobbies],
    ["Bakat dominan", profile.talents],
    ["Skill awal", profile.skills],
  ] as const;

  return (
    <Panel>
      <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Ringkasan lengkap</p>
      <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Informasi profil untuk keputusan</h2>
      <div className="mt-6 space-y-5">
        {groups.map(([title, items]) => (
          <div key={title}>
            <p className="text-sm font-black text-slate-900">{title}</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {items.map((item) => <span key={item} className="rounded-full bg-[#eef5ff] px-3 py-1 text-xs font-black text-[#4c51d9]">{item}</span>)}
            </div>
          </div>
        ))}
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="rounded-[1.35rem] bg-slate-50 p-4">
            <p className="text-sm font-black text-slate-900">Prestasi / pengalaman</p>
            <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">{profile.achievements}</p>
          </div>
          <div className="rounded-[1.35rem] bg-slate-50 p-4">
            <p className="text-sm font-black text-slate-900">Tujuan setelah lulus</p>
            <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">{profile.goal}</p>
          </div>
          <div className="rounded-[1.35rem] bg-slate-50 p-4">
            <p className="text-sm font-black text-slate-900">Preferensi belajar</p>
            <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">{profile.learningPreference}</p>
          </div>
          <div className="rounded-[1.35rem] bg-slate-50 p-4">
            <p className="text-sm font-black text-slate-900">Pertimbangan pribadi</p>
            <p className="mt-2 text-sm font-semibold leading-7 text-slate-600">{profile.constraints}</p>
          </div>
        </div>
      </div>
    </Panel>
  );
}

function CriteriaBars({ recommendation }: { recommendation: Recommendation }) {
  const rows = [
    ["Akademik", recommendation.criteria.academic],
    ["Minat", recommendation.criteria.interest],
    ["Bakat/skill", recommendation.criteria.talentSkill],
    ["Tujuan", recommendation.criteria.goalFit],
  ] as const;

  return (
    <div className="mt-5 space-y-3">
      {rows.map(([label, value]) => (
        <div key={label}>
          <div className="mb-1 flex justify-between text-xs font-black text-slate-500"><span>{label}</span><span>{value}</span></div>
          <ProgressBar value={value} />
        </div>
      ))}
    </div>
  );
}

function RecommendationCard({ recommendation, active, onSelect }: { recommendation: Recommendation; active: boolean; onSelect: () => void }) {
  return (
    <button type="button" onClick={onSelect} className={`group rounded-[1.5rem] border p-5 text-left transition hover:-translate-y-1 ${active ? "border-[#0f2a5f] bg-[#0f2a5f] text-white shadow-2xl shadow-blue-950/20" : "border-slate-200 bg-white text-slate-950 shadow-lg shadow-slate-900/5 hover:border-blue-200"}`}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="flex flex-wrap gap-2">
            <span className={`rounded-full px-3 py-1 text-xs font-black ${active ? "bg-white/15 text-cyan-100" : "bg-[#eef5ff] text-[#0f2a5f]"}`}>Peringkat {recommendation.topsisRank}</span>
            <span className={`rounded-full px-3 py-1 text-xs font-black ${active ? "bg-white/15 text-cyan-100" : "bg-slate-100 text-slate-600"}`}>{recommendation.category}</span>
          </div>
          <h3 className="mt-4 text-xl font-black leading-tight tracking-tight">{recommendation.title}</h3>
        </div>
        <div className={`grid h-16 w-16 shrink-0 place-items-center rounded-2xl text-xl font-black ${active ? "bg-white text-[#0f2a5f]" : "bg-slate-950 text-cyan-300"}`}>{recommendation.score}</div>
      </div>
      <p className={`mt-2 text-sm font-black ${active ? "text-cyan-100" : "text-[#0f2a5f]"}`}>{recommendation.fuzzyLabel} · skor kecocokan</p>
      <p className={`mt-4 text-sm leading-7 ${active ? "text-indigo-50" : "text-slate-500"}`}>{recommendation.summary}</p>
      <div className="mt-5 flex flex-wrap gap-2">
        {recommendation.suggestedMajors.map((major) => <span key={major} className={`rounded-full px-3 py-1 text-xs font-black ${active ? "bg-white/10 text-white" : "bg-slate-100 text-slate-600"}`}>{major}</span>)}
      </div>
      {!active && <CriteriaBars recommendation={recommendation} />}
    </button>
  );
}

export default function SiswaPage() {
  const [profile, setProfile] = useState<StudentProfileForm>(initialProfile);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [selectedCareerId, setSelectedCareerId] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [backendStudentId, setBackendStudentId] = useState("1");
  const [syncMessage, setSyncMessage] = useState("");
  const [syncError, setSyncError] = useState("");
  const [isSyncingAcademic, setIsSyncingAcademic] = useState(false);

  const scores = readinessScores(profile);

  useEffect(() => {
    generateRecommendations(initialProfile).then((result) => {
      setRecommendations(result);
      setSelectedCareerId(result[0]?.id ?? "");
    });
  }, []);

  const updateText = (field: TextField, value: string) => setProfile((current) => ({ ...current, [field]: value }));
  const updateScore = (field: "bahasaIndonesia" | "bahasaInggris" | "matematika" | "dll", value: number) => setProfile((current) => ({ ...current, [field]: value }));
  const toggleArrayValue = (field: ArrayField, value: string) => {
    setProfile((current) => {
      const exists = current[field].includes(value);
      return { ...current, [field]: exists ? current[field].filter((item) => item !== value) : [...current[field], value] };
    });
  };

  const handleLoadAcademicProfile = async () => {
    setIsSyncingAcademic(true);
    setSyncMessage("");
    setSyncError("");

    try {
      const id = Number(backendStudentId);
      if (!Number.isFinite(id) || id <= 0) {
        throw new Error("ID siswa backend harus berupa angka valid.");
      }

      const academicProfile = await getStudentAcademicProfile(id);
      setProfile((current) => ({
        ...current,
        ...academicProfile,
        school: current.school,
      }));
      setSyncMessage("Data akademik berhasil disinkronkan dari backend. Data nonakademik tetap bisa dilengkapi siswa.");
    } catch (error) {
      setSyncError(error instanceof Error ? error.message : "Gagal mengambil profil akademik siswa.");
    } finally {
      setIsSyncingAcademic(false);
    }
  };

  const handleGenerate = async () => {
    setIsLoading(true);
    const result = await generateRecommendations(profile);
    setRecommendations(result);
    setSelectedCareerId(result[0]?.id ?? "");
    setIsLoading(false);
  };

  const selectedRecommendation = recommendations.find((item) => item.id === selectedCareerId) ?? recommendations[0];

  return (
    <DashboardShell
      activeKey="profil"
      navItems={studentNav}
      title="Profil Karier Siswa"
      subtitle="Lengkapi data akademik dan nonakademik agar sistem dapat menyusun peringkat arah karier dan roadmap pengembangan diri."
      userName={profile.name}
      userLabel="Siswa kelas akhir"
      schoolName={profile.school}
      rightSlot={<span className="hidden rounded-full bg-white/15 px-4 py-2 text-xs font-black text-white md:inline-flex">Kelas XII</span>}
    >
      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard label="Kesiapan profil" value={`${scores.overall}%`} detail="Akademik, minat, skill, dan tujuan." icon="✓" />
        <MetricCard label="Minat dipilih" value={`${profile.interests.length}`} detail={`Dari ${interestTotal} opsi minat.`} icon="◎" />
        <MetricCard label="Hobi dipilih" value={`${profile.hobbies.length}`} detail={`Dari ${hobbyTotal} opsi hobi.`} icon="◇" />
        <MetricCard label="Rata-rata nilai" value={`${scores.academicAverage}`} detail="Sinkron dengan data sekolah." icon="∑" />
      </div>

      <div className="mt-6 grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
        <div className="space-y-6">
          <ProfileSnapshot profile={profile} />
          <ProfileDetail profile={profile} />

          <Panel id="bimbingan">
            <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Catatan bimbingan</p>
            <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Arahan pembimbing</h2>
            <div className="mt-5 space-y-3">
              {[
                "Bandingkan hasil peringkat dengan kondisi biaya, lokasi, dan dukungan keluarga.",
                "Pilih satu arah utama agar roadmap dapat dijalankan secara konsisten.",
                "Siapkan portofolio awal sesuai langkah pertama pada roadmap.",
              ].map((item, index) => (
                <div key={item} className="flex gap-4 rounded-[1.25rem] bg-slate-50 p-4">
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-[#0f2a5f] text-sm font-black text-white">{index + 1}</div>
                  <p className="text-sm font-bold leading-6 text-slate-600">{item}</p>
                </div>
              ))}
            </div>
          </Panel>
        </div>

        <div className="space-y-6">
          <Panel>
            <div className="mb-6 flex flex-col justify-between gap-4 md:flex-row md:items-start">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Data dasar</p>
                <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Identitas siswa</h2>
                <p className="mt-2 text-sm font-semibold leading-7 text-slate-500">Data ini menjadi pengenal profil sebelum proses perhitungan kriteria.</p>
              </div>
              <span className="rounded-full bg-emerald-50 px-4 py-2 text-xs font-black text-emerald-700">Tersimpan</span>
            </div>
            <div className="grid gap-4 md:grid-cols-2">
              <label className="block"><span className="text-sm font-black text-slate-700">Nama lengkap</span><input value={profile.name} onChange={(event) => updateText("name", event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white" /></label>
              <label className="block"><span className="text-sm font-black text-slate-700">NISN / username</span><input value={profile.nisn} onChange={(event) => updateText("nisn", event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white" /></label>
              <label className="block"><span className="text-sm font-black text-slate-700">Sekolah</span><input value={profile.school} onChange={(event) => updateText("school", event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white" /></label>
              <label className="block"><span className="text-sm font-black text-slate-700">Kelas</span><input value={profile.className} onChange={(event) => updateText("className", event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white" /></label>
              <label className="block md:col-span-2"><span className="text-sm font-black text-slate-700">Jurusan / peminatan</span><input value={profile.major} onChange={(event) => updateText("major", event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white" /></label>
            </div>
          </Panel>

          <Panel>
            <div className="flex flex-col justify-between gap-4 md:flex-row md:items-start">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">C1 Akademik</p>
                <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Nilai dari sekolah</h2>
                <p className="mt-2 text-sm font-semibold leading-7 text-slate-500">Nilai akademik menjadi kriteria terukur pada proses TOPSIS.</p>
              </div>
              <span className="rounded-full bg-[#eef5ff] px-4 py-2 text-xs font-black text-[#0f2a5f]">Terverifikasi</span>
            </div>
            <div className="mt-6 rounded-[1.35rem] bg-slate-50 p-4">
              <div className="grid gap-3 md:grid-cols-[1fr_auto] md:items-end">
                <label className="block">
                  <span className="text-sm font-black text-slate-700">ID siswa dari backend</span>
                  <input value={backendStudentId} onChange={(event) => setBackendStudentId(event.target.value)} placeholder="Contoh: 1" className="mt-2 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold outline-none transition focus:border-[#0f2a5f]" />
                </label>
                <button type="button" onClick={handleLoadAcademicProfile} disabled={!isApiConfigured || isSyncingAcademic} className="rounded-full bg-slate-950 px-5 py-3 text-sm font-black text-white transition hover:-translate-y-0.5 hover:bg-[#0f2a5f] disabled:cursor-not-allowed disabled:opacity-50">
                  {isSyncingAcademic ? "Sinkronisasi..." : "Ambil nilai sekolah"}
                </button>
              </div>
              <p className="mt-3 text-xs font-bold leading-5 text-slate-500">
                Setelah guru import Excel, siswa dapat memuat nilai akademik dari tabel kategori backend. Jika backend belum aktif, tombol ini otomatis nonaktif.
              </p>
              {(syncMessage || syncError) && (
                <div className={`mt-3 rounded-2xl px-4 py-3 text-sm font-bold ${syncError ? "bg-rose-50 text-rose-700" : "bg-emerald-50 text-emerald-700"}`}>
                  {syncError || syncMessage}
                </div>
              )}
            </div>

            <div className="mt-6 grid gap-4 sm:grid-cols-2">
              <ScoreInput label="Bahasa Indonesia" value={profile.bahasaIndonesia} onChange={(value) => updateScore("bahasaIndonesia", value)} />
              <ScoreInput label="Bahasa Inggris" value={profile.bahasaInggris} onChange={(value) => updateScore("bahasaInggris", value)} />
              <ScoreInput label="Matematika" value={profile.matematika} onChange={(value) => updateScore("matematika", value)} />
              <ScoreInput label="Mapel lain" value={profile.dll} onChange={(value) => updateScore("dll", value)} />
            </div>
            <label className="mt-4 block"><span className="text-sm font-black text-slate-700">Fokus akademik yang paling kuat</span><textarea value={profile.academicFocus} onChange={(event) => updateText("academicFocus", event.target.value)} className="mt-2 min-h-24 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold leading-7 outline-none transition focus:border-[#0f2a5f] focus:bg-white" /></label>
          </Panel>

          <Panel>
            <div className="mb-6">
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">C2 dan C3</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Minat, hobi, bakat, dan skill</h2>
              <p className="mt-2 text-sm font-semibold leading-7 text-slate-500">Katalog minat dan hobi berisi banyak pilihan. Gunakan pencarian agar pengisian tetap cepat.</p>
            </div>
            <div className="space-y-4">
              <OptionPicker title="Minat siswa" subtitle="Sinyal utama untuk kecocokan bidang karier." options={interestOptions} selected={profile.interests} onToggle={(value) => toggleArrayValue("interests", value)} placeholder="Cari minat, contoh: data, desain, bisnis..." />
              <OptionPicker title="Hobi siswa" subtitle="Sinyal tambahan agar profil tidak hanya akademik." options={hobbyOptions} selected={profile.hobbies} onToggle={(value) => toggleArrayValue("hobbies", value)} placeholder="Cari hobi, contoh: coding, futsal, menulis..." />
              <OptionPicker title="Bakat dominan" subtitle="Kemampuan yang paling sering muncul pada diri siswa." options={talentOptions} selected={profile.talents} onToggle={(value) => toggleArrayValue("talents", value)} placeholder="Cari bakat..." maxVisible={20} />
              <OptionPicker title="Skill yang sudah dimiliki" subtitle="Skill awal membantu menyusun roadmap yang realistis." options={skillOptions} selected={profile.skills} onToggle={(value) => toggleArrayValue("skills", value)} placeholder="Cari skill..." maxVisible={20} />
            </div>
          </Panel>

          <Panel>
            <div className="mb-6">
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">C4 Tujuan</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Prestasi dan rencana setelah lulus</h2>
            </div>
            <div className="space-y-4">
              <label className="block"><span className="text-sm font-black text-slate-700">Prestasi / pengalaman</span><textarea value={profile.achievements} onChange={(event) => updateText("achievements", event.target.value)} className="mt-2 min-h-24 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold leading-7 outline-none transition focus:border-[#0f2a5f] focus:bg-white" /></label>
              <label className="block"><span className="text-sm font-black text-slate-700">Tujuan setelah lulus</span><textarea value={profile.goal} onChange={(event) => updateText("goal", event.target.value)} className="mt-2 min-h-24 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold leading-7 outline-none transition focus:border-[#0f2a5f] focus:bg-white" /></label>
              <label className="block"><span className="text-sm font-black text-slate-700">Preferensi belajar</span><input value={profile.learningPreference} onChange={(event) => updateText("learningPreference", event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white" /></label>
              <label className="block"><span className="text-sm font-black text-slate-700">Kendala / pertimbangan</span><textarea value={profile.constraints} onChange={(event) => updateText("constraints", event.target.value)} className="mt-2 min-h-24 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold leading-7 outline-none transition focus:border-[#0f2a5f] focus:bg-white" /></label>
            </div>
            <button type="button" onClick={handleGenerate} disabled={isLoading} className="mt-6 w-full rounded-full bg-slate-950 px-6 py-4 text-sm font-black text-white shadow-xl shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-[#0f2a5f] disabled:cursor-not-allowed disabled:opacity-60">
              {isLoading ? "Mengolah data..." : "Hitung hasil SPK"}
            </button>
          </Panel>
        </div>
      </div>

      <Panel id="hasil" className="mt-6">
        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Hasil keputusan</p>
            <h2 className="mt-2 text-3xl font-black tracking-[-0.04em] text-slate-950">Tiga arah karier paling sesuai</h2>
            <p className="mt-2 max-w-3xl text-sm font-semibold leading-7 text-slate-500">Pilih salah satu hasil untuk membuka roadmap pengembangan diri pada halaman khusus.</p>
          </div>
          {selectedRecommendation && (
            <Link href={`/siswa/roadmap?career=${selectedRecommendation.id}`} className="rounded-full bg-[#0f2a5f] px-6 py-4 text-center text-sm font-black text-white shadow-xl shadow-blue-950/20 transition hover:-translate-y-0.5 hover:bg-slate-950">
              Buka roadmap pilihan
            </Link>
          )}
        </div>

        <div className="mt-6 grid gap-4 lg:grid-cols-3">
          {recommendations.map((recommendation) => (
            <RecommendationCard key={recommendation.id} recommendation={recommendation} active={selectedCareerId === recommendation.id} onSelect={() => setSelectedCareerId(recommendation.id)} />
          ))}
        </div>

        {selectedRecommendation && (
          <div className="mt-6 rounded-[1.5rem] bg-slate-50 p-5">
            <p className="text-sm font-black text-slate-950">Alasan utama untuk {selectedRecommendation.title}</p>
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              {selectedRecommendation.reasons.map((reason) => (
                <div key={reason} className="rounded-2xl bg-white p-4 text-sm font-semibold leading-7 text-slate-600 shadow-sm">{reason}</div>
              ))}
            </div>
          </div>
        )}
      </Panel>
    </DashboardShell>
  );
}
