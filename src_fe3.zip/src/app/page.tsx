import Link from "next/link";

const highlights = [
  {
    title: "Pengelolaan nilai akademik",
    text: "Guru mengunggah template nilai semester 1 sampai 5, memeriksa validitas baris, dan menyiapkan akun siswa dari data yang sudah terverifikasi.",
  },
  {
    title: "Profil siswa komprehensif",
    text: "Siswa melengkapi minat, hobi, bakat, skill, prestasi, preferensi belajar, kendala, dan tujuan setelah lulus dalam satu alur yang mudah dipahami.",
  },
  {
    title: "Ranking berbasis SPK",
    text: "Fuzzy digunakan untuk membaca data subjektif, sedangkan TOPSIS menyusun peringkat arah karier berdasarkan kriteria yang terukur.",
  },
  {
    title: "Roadmap pengembangan diri",
    text: "Setelah memilih hasil keputusan, siswa mendapatkan langkah belajar, output portofolio, dan progress yang dapat dipantau bersama guru.",
  },
];

const flows = [
  ["01", "Pendaftaran guru", "Guru mendaftarkan identitas sekolah, lalu admin melakukan verifikasi akun."],
  ["02", "Import nilai", "Nilai akademik siswa diunggah menggunakan template Excel resmi sekolah."],
  ["03", "Akun siswa", "Guru membuat akun siswa agar akses data tetap terkendali dan tidak ada pendaftaran mandiri."],
  ["04", "Profil siswa", "Siswa mengisi data minat, hobi, bakat, prestasi, dan tujuan setelah lulus."],
  ["05", "Perhitungan SPK", "Sistem mengolah kriteria dengan Fuzzy dan TOPSIS untuk menghasilkan tiga peringkat teratas."],
  ["06", "Roadmap", "Siswa memilih satu arah karier, lalu mengikuti roadmap belajar yang dapat dipantau progresnya."],
];

const metrics = [
  ["5", "semester nilai"],
  ["100+", "opsi minat"],
  ["100+", "opsi hobi"],
  ["3", "hasil teratas"],
];

const chartBars = [64, 72, 58, 81, 76, 88, 84, 92];

export default function Home() {
  return (
    <main className="min-h-screen overflow-hidden bg-[#f2f5fb] text-slate-950">
      <section className="relative bg-[#0b1530] text-white">
        <div className="absolute inset-0 opacity-45">
          <div className="absolute left-[-120px] top-[-150px] h-[360px] w-[360px] rounded-full bg-cyan-400 blur-[110px]" />
          <div className="absolute bottom-[-160px] right-[-80px] h-[420px] w-[420px] rounded-full bg-[#0f2a5f] blur-[130px]" />
        </div>
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.06)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:72px_72px]" />

        <nav className="relative z-10 mx-auto flex w-[min(1220px,calc(100%-32px))] items-center justify-between gap-4 py-6">
          <Link href="/" className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-white text-[#0f2a5f] shadow-lg shadow-black/10">
              <span className="text-sm font-black">SL</span>
            </div>
            <div>
              <p className="text-lg font-black tracking-tight">SkillLens</p>
              <p className="text-xs font-medium text-cyan-100/70">Career Decision Support</p>
            </div>
          </Link>

          <div className="hidden items-center gap-8 text-sm font-semibold text-white/70 md:flex">
            <a href="#fitur" className="hover:text-white">Fitur</a>
            <a href="#alur" className="hover:text-white">Alur</a>
            <a href="#metode" className="hover:text-white">Metode</a>
            <a href="#kontak" className="hover:text-white">Bantuan</a>
          </div>

          <div className="flex items-center gap-2">
            <Link href="/auth/login" className="hidden rounded-full border border-white/15 bg-white/10 px-5 py-3 text-sm font-black text-white backdrop-blur transition hover:bg-white hover:text-slate-950 sm:inline-flex">
              Masuk
            </Link>
            <Link href="/auth/register" className="rounded-full bg-cyan-300 px-5 py-3 text-sm font-black text-slate-950 shadow-[0_0_30px_rgba(103,232,249,0.35)] transition hover:-translate-y-0.5 hover:bg-white">
              Daftar Guru
            </Link>
          </div>
        </nav>

        <div className="relative z-10 mx-auto grid w-[min(1220px,calc(100%-32px))] gap-12 pb-20 pt-12 lg:grid-cols-[1fr_540px] lg:pb-28 lg:pt-20">
          <div className="max-w-3xl">
            <div className="mb-7 inline-flex items-center gap-3 rounded-full border border-cyan-200/20 bg-white/8 px-4 py-2 text-sm font-semibold text-cyan-100 backdrop-blur">
              <span className="h-2 w-2 rounded-full bg-cyan-300 shadow-[0_0_16px_rgba(103,232,249,0.9)]" />
              Sistem pendukung keputusan karier untuk SMA/SMK
            </div>
            <h1 className="text-[42px] font-black leading-[0.98] tracking-[-0.06em] text-white md:text-7xl lg:text-[82px]">
              Keputusan karier yang lebih terarah dan berbasis data.
            </h1>
            <p className="mt-7 max-w-2xl text-base leading-8 text-slate-300 md:text-lg">
              SkillLens membantu sekolah menggabungkan nilai akademik, minat, hobi, bakat, prestasi, dan tujuan siswa menjadi peringkat arah karier serta roadmap belajar yang dapat ditindaklanjuti.
            </p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Link href="/auth/login" className="rounded-full bg-cyan-300 px-7 py-4 text-center text-sm font-black text-slate-950 shadow-xl shadow-cyan-500/20 transition hover:-translate-y-0.5 hover:bg-white">
                Masuk ke aplikasi
              </Link>
              <Link href="/auth/register" className="rounded-full border border-white/15 bg-white/10 px-7 py-4 text-center text-sm font-black text-white backdrop-blur transition hover:-translate-y-0.5 hover:bg-white hover:text-slate-950">
                Ajukan akun guru
              </Link>
            </div>
          </div>

          <div className="rounded-[2rem] border border-white/10 bg-white/10 p-4 shadow-2xl shadow-black/20 backdrop-blur">
            <div className="overflow-hidden rounded-[1.5rem] bg-white text-slate-950 shadow-2xl shadow-slate-950/20">
              <div className="flex items-center justify-between bg-gradient-to-r from-[#0f2a5f] to-[#1d4ed8] px-5 py-4 text-white">
                <div className="flex items-center gap-3">
                  <div className="grid h-10 w-10 place-items-center rounded-2xl bg-white text-sm font-black text-[#0f2a5f]">SL</div>
                  <div>
                    <p className="text-sm font-black">Dashboard Karier</p>
                    <p className="text-xs font-semibold text-white/70">Ringkasan keputusan siswa</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <span className="h-3 w-3 rounded-full bg-white/40" />
                  <span className="h-3 w-3 rounded-full bg-white/40" />
                  <span className="h-3 w-3 rounded-full bg-white/40" />
                </div>
              </div>

              <div className="grid gap-4 p-5 sm:grid-cols-3">
                {[
                  ["248", "Siswa"],
                  ["92%", "Data valid"],
                  ["86", "Skor tertinggi"],
                ].map(([value, label]) => (
                  <div key={label} className="rounded-2xl bg-slate-50 p-4">
                    <p className="text-2xl font-black text-slate-950">{value}</p>
                    <p className="mt-1 text-xs font-black uppercase tracking-[0.16em] text-slate-400">{label}</p>
                  </div>
                ))}
              </div>

              <div className="px-5 pb-5">
                <div className="rounded-3xl border border-slate-100 bg-white p-5 shadow-lg shadow-slate-900/5">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-xs font-black uppercase tracking-[0.18em] text-[#0f2a5f]">Tren kesiapan</p>
                      <h2 className="mt-1 text-xl font-black">Perkembangan profil siswa</h2>
                    </div>
                    <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-black text-emerald-700">Naik 18%</span>
                  </div>
                  <div className="mt-6 flex h-40 items-end gap-3">
                    {chartBars.map((value, index) => (
                      <div key={index} className="flex flex-1 flex-col items-center gap-2">
                        <div className="w-full rounded-t-2xl bg-gradient-to-t from-[#0f2a5f] to-cyan-300" style={{ height: `${value}%` }} />
                        <span className="text-[10px] font-black text-slate-400">S{index + 1}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 space-y-3">
                  {[
                    ["Data Analyst dan AI Specialist", "92"],
                    ["Software Engineer", "89"],
                    ["UI/UX Product Designer", "82"],
                  ].map(([title, score], index) => (
                    <div key={title} className="flex items-center justify-between rounded-2xl bg-slate-50 p-4">
                      <div>
                        <p className="text-xs font-black uppercase tracking-[0.16em] text-slate-400">Peringkat {index + 1}</p>
                        <p className="mt-1 text-sm font-black text-slate-950">{title}</p>
                      </div>
                      <div className="grid h-11 w-11 place-items-center rounded-2xl bg-slate-950 font-black text-cyan-300">{score}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto grid w-[min(1220px,calc(100%-32px))] gap-4 py-8 sm:grid-cols-2 lg:grid-cols-4">
        {metrics.map(([value, label]) => (
          <div key={label} className="rounded-[1.5rem] bg-white p-6 text-center shadow-xl shadow-slate-900/5">
            <p className="text-4xl font-black tracking-[-0.04em] text-slate-950">{value}</p>
            <p className="mt-2 text-sm font-black uppercase tracking-[0.18em] text-slate-400">{label}</p>
          </div>
        ))}
      </section>

      <section id="fitur" className="mx-auto w-[min(1220px,calc(100%-32px))] py-10">
        <div className="mb-8 max-w-3xl">
          <p className="text-sm font-black uppercase tracking-[0.24em] text-[#0f2a5f]">Fitur utama</p>
          <h2 className="mt-3 text-4xl font-black tracking-[-0.05em] text-slate-950 md:text-5xl">Alur lengkap dari data sekolah sampai roadmap siswa.</h2>
        </div>
        <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {highlights.map((item, index) => (
            <article key={item.title} className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-900/5 transition hover:-translate-y-1">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#eef5ff] text-sm font-black text-[#0f2a5f]">{index + 1}</div>
              <h3 className="mt-5 text-xl font-black tracking-[-0.03em] text-slate-950">{item.title}</h3>
              <p className="mt-3 text-sm font-bold leading-7 text-slate-500">{item.text}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="alur" className="mx-auto w-[min(1220px,calc(100%-32px))] py-10">
        <div className="rounded-[2.5rem] bg-white p-6 shadow-xl shadow-slate-900/5 md:p-10">
          <div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end">
            <div>
              <p className="text-sm font-black uppercase tracking-[0.24em] text-[#0f2a5f]">Alur sistem</p>
              <h2 className="mt-3 text-4xl font-black tracking-[-0.05em] text-slate-950 md:text-5xl">Proses dibuat aman, runtut, dan mudah dipahami.</h2>
            </div>
            <Link href="/auth/login" className="rounded-full bg-slate-950 px-6 py-4 text-center text-sm font-black text-white transition hover:-translate-y-0.5 hover:bg-[#0f2a5f]">
              Masuk aplikasi
            </Link>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {flows.map(([number, title, text]) => (
              <div key={number} className="rounded-[1.5rem] bg-slate-50 p-5">
                <div className="mb-5 grid h-12 w-12 place-items-center rounded-2xl bg-cyan-300 text-sm font-black text-slate-950">{number}</div>
                <h3 className="text-xl font-black text-slate-950">{title}</h3>
                <p className="mt-3 text-sm font-bold leading-7 text-slate-500">{text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="metode" className="mx-auto grid w-[min(1220px,calc(100%-32px))] gap-6 py-10 lg:grid-cols-[0.9fr_1.1fr]">
        <div className="rounded-[2.5rem] bg-slate-950 p-8 text-white shadow-xl shadow-slate-900/10">
          <p className="text-sm font-black uppercase tracking-[0.24em] text-cyan-200">Metode SPK</p>
          <h2 className="mt-3 text-4xl font-black tracking-[-0.05em]">Fuzzy dan TOPSIS dalam satu alur keputusan.</h2>
          <p className="mt-5 text-sm font-semibold leading-7 text-slate-300">
            Data subjektif seperti minat, hobi, bakat, dan tujuan dibaca melalui Fuzzy. Setelah itu, TOPSIS melakukan pemeringkatan berdasarkan kedekatan tiap alternatif terhadap solusi ideal.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          {[
            ["C1", "Akademik", "Nilai semester 1 sampai 5 dari template Excel."],
            ["C2", "Minat", "Pilihan minat dari katalog besar yang mudah dicari."],
            ["C3", "Bakat dan skill", "Kemampuan awal, hobi, dan indikator nonakademik."],
            ["C4", "Tujuan", "Preferensi kuliah, pelatihan, kerja, serta kendala pribadi."],
          ].map(([code, title, text]) => (
            <div key={code} className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-900/5">
              <div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#eef5ff] text-sm font-black text-[#0f2a5f]">{code}</div>
              <h3 className="mt-5 text-xl font-black text-slate-950">{title}</h3>
              <p className="mt-3 text-sm font-bold leading-7 text-slate-500">{text}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="kontak" className="mx-auto w-[min(1220px,calc(100%-32px))] py-10 pb-20">
        <div className="flex flex-col items-start justify-between gap-6 rounded-[2.5rem] bg-white p-8 shadow-xl shadow-slate-900/5 md:flex-row md:items-center">
          <div>
            <p className="text-sm font-black uppercase tracking-[0.24em] text-[#0f2a5f]">Siap digunakan untuk presentasi</p>
            <h2 className="mt-3 text-3xl font-black tracking-[-0.04em] text-slate-950">Masuk melalui halaman autentikasi untuk melihat ruang kerja aplikasi.</h2>
          </div>
          <Link href="/auth/login" className="rounded-full bg-slate-950 px-7 py-4 text-center text-sm font-black text-white transition hover:-translate-y-0.5 hover:bg-[#0f2a5f]">
            Buka halaman masuk
          </Link>
        </div>
      </section>
    </main>
  );
}
