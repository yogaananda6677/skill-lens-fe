"use client";

import { useRef, useState } from "react";
import { apiFetch } from "../../lib/axios";
import { Icon } from "../../components/ui/icons";

type SchoolForm = {
  nama_sekolah: string;
  npsn: string;
  jenis_sekolah: string;
  alamat: string;
  kota: string;
  provinsi: string;
  no_telp: string;
};

type TeacherForm = {
  nama: string;
  email: string;
  no_hp: string;
  username: string;
  password: string;
  nip: string;
  jabatan: string;
};

const initialSchoolForm: SchoolForm = {
  nama_sekolah: "",
  npsn: "",
  jenis_sekolah: "SMA",
  alamat: "",
  kota: "",
  provinsi: "",
  no_telp: "",
};

const initialTeacherForm: TeacherForm = {
  nama: "",
  email: "",
  no_hp: "",
  username: "",
  password: "",
  nip: "",
  jabatan: "Guru BK",
};

function Field({
  label,
  value,
  placeholder,
  type = "text",
  onChange,
}: {
  label: string;
  value: string;
  placeholder: string;
  type?: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm font-semibold text-slate-700">
        {label}
      </span>
      <input
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-sky-700 focus:bg-white focus:ring-4 focus:ring-sky-100"
      />
    </label>
  );
}

function StatusMessage({
  message,
  error,
}: {
  message: string;
  error: string;
}) {
  if (!message && !error) return null;

  return (
    <div
      className={`rounded-2xl p-4 text-sm font-semibold ${
        error
          ? "bg-rose-50 text-rose-700 ring-1 ring-rose-100"
          : "bg-emerald-50 text-emerald-800 ring-1 ring-emerald-100"
      }`}
    >
      {error || message}
    </div>
  );
}

export default function AdminSekolahPage() {
  const fileRef = useRef<HTMLInputElement | null>(null);

  const [schoolForm, setSchoolForm] = useState<SchoolForm>(initialSchoolForm);
  const [teacherForm, setTeacherForm] =
    useState<TeacherForm>(initialTeacherForm);

  const [schoolMessage, setSchoolMessage] = useState("");
  const [schoolError, setSchoolError] = useState("");
  const [teacherMessage, setTeacherMessage] = useState("");
  const [teacherError, setTeacherError] = useState("");
  const [importMessage, setImportMessage] = useState("");
  const [importError, setImportError] = useState("");

  const [loadingSchool, setLoadingSchool] = useState(false);
  const [loadingTeacher, setLoadingTeacher] = useState(false);
  const [loadingImport, setLoadingImport] = useState(false);

  const updateSchool = (key: keyof SchoolForm, value: string) => {
    setSchoolForm((current) => ({ ...current, [key]: value }));
  };

  const updateTeacher = (key: keyof TeacherForm, value: string) => {
    setTeacherForm((current) => ({ ...current, [key]: value }));
  };

  const submitSchool = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    setSchoolMessage("");
    setSchoolError("");

    if (!schoolForm.nama_sekolah.trim()) {
      setSchoolError("Nama sekolah wajib diisi.");
      return;
    }

    setLoadingSchool(true);

    try {
      const result = await apiFetch<{ message?: string }>("/sekolah", {
        method: "POST",
        body: JSON.stringify({
          nama_sekolah: schoolForm.nama_sekolah.trim(),
          npsn: schoolForm.npsn.trim(),
          jenis_sekolah: schoolForm.jenis_sekolah,
          alamat: schoolForm.alamat.trim(),
          kota: schoolForm.kota.trim(),
          provinsi: schoolForm.provinsi.trim(),
          no_telp: schoolForm.no_telp.trim(),
          status_verifikasi: "pending",
        }),
      });

      setSchoolMessage(
        result.message ||
          "Data sekolah berhasil diajukan dan menunggu verifikasi.",
      );
      setSchoolForm(initialSchoolForm);
    } catch (err) {
      setSchoolError(
        err instanceof Error
          ? err.message
          : "Pengajuan sekolah gagal diproses.",
      );
    } finally {
      setLoadingSchool(false);
    }
  };

  const submitTeacher = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    setTeacherMessage("");
    setTeacherError("");

    if (
      !teacherForm.nama.trim() ||
      !teacherForm.email.trim() ||
      !teacherForm.username.trim() ||
      !teacherForm.password.trim() ||
      !teacherForm.nip.trim()
    ) {
      setTeacherError("Nama, email, username, password, dan NIP wajib diisi.");
      return;
    }

    setLoadingTeacher(true);

    try {
      const result = await apiFetch<{ message?: string }>("/auth/register-guru", {
        method: "POST",
        body: JSON.stringify({
          nama: teacherForm.nama.trim(),
          email: teacherForm.email.trim(),
          no_hp: teacherForm.no_hp.trim(),
          username: teacherForm.username.trim(),
          password: teacherForm.password,
          nip: teacherForm.nip.trim(),
          jabatan: teacherForm.jabatan,
        }),
      });

      setTeacherMessage(result.message || "Akun guru berhasil ditambahkan.");
      setTeacherForm(initialTeacherForm);
    } catch (err) {
      setTeacherError(
        err instanceof Error ? err.message : "Tambah guru gagal diproses.",
      );
    } finally {
      setLoadingTeacher(false);
    }
  };

  const submitImportSiswa = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    setImportMessage("");
    setImportError("");

    const file = fileRef.current?.files?.[0];

    if (!file) {
      setImportError("File Excel siswa wajib dipilih.");
      return;
    }

    const isExcel =
      file.name.endsWith(".xlsx") ||
      file.name.endsWith(".xls") ||
      file.type.includes("spreadsheet");

    if (!isExcel) {
      setImportError("File harus berformat .xlsx atau .xls.");
      return;
    }

    const formData = new FormData();
    formData.append("file", file);

    setLoadingImport(true);

    try {
      const result = await apiFetch<{ message?: string }>("/siswa/import", {
        method: "POST",
        body: formData,
      });

      setImportMessage(result.message || "Import data siswa berhasil diproses.");

      if (fileRef.current) {
        fileRef.current.value = "";
      }
    } catch (err) {
      setImportError(
        err instanceof Error ? err.message : "Import siswa gagal diproses.",
      );
    } finally {
      setLoadingImport(false);
    }
  };

  return (
    <main className="min-h-screen bg-slate-50 text-slate-950">
      <section className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-5 py-8 md:flex-row md:items-center md:justify-between">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.24em] text-sky-700">
              Dashboard Admin Sekolah
            </p>
            <h1 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">
              Kelola data awal sekolah.
            </h1>
            <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-500">
              Admin sekolah bertugas mengajukan data sekolah, menambahkan akun
              guru, dan mengimport data siswa dari file Excel.
            </p>
          </div>

          <div className="rounded-3xl bg-slate-950 px-5 py-4 text-white shadow-xl shadow-slate-900/10">
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-cyan-200">
              Role aktif
            </p>
            <p className="mt-1 text-lg font-bold">admin_sekolah</p>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-5 px-5 py-8 md:grid-cols-3">
        <div className="rounded-[2rem] border border-slate-100 bg-white p-6 shadow-xl shadow-slate-900/5">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-sky-50 text-sky-700">
            <Icon name="school" />
          </div>
          <h2 className="mt-4 text-lg font-bold">Pengajuan Sekolah</h2>
          <p className="mt-2 text-sm leading-6 text-slate-500">
            Ajukan atau lengkapi data sekolah untuk diverifikasi superadmin.
          </p>
        </div>

        <div className="rounded-[2rem] border border-slate-100 bg-white p-6 shadow-xl shadow-slate-900/5">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-emerald-50 text-emerald-700">
            <Icon name="users" />
          </div>
          <h2 className="mt-4 text-lg font-bold">Data Guru</h2>
          <p className="mt-2 text-sm leading-6 text-slate-500">
            Tambahkan akun guru untuk membantu pengelolaan siswa dan bimbingan.
          </p>
        </div>

        <div className="rounded-[2rem] border border-slate-100 bg-white p-6 shadow-xl shadow-slate-900/5">
          <div className="grid h-12 w-12 place-items-center rounded-2xl bg-violet-50 text-violet-700">
            <Icon name="upload" />
          </div>
          <h2 className="mt-4 text-lg font-bold">Import Siswa</h2>
          <p className="mt-2 text-sm leading-6 text-slate-500">
            Upload file Excel untuk membuat data siswa secara lebih cepat.
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-6 px-5 pb-12 lg:grid-cols-[1fr_1fr]">
        <form
          onSubmit={submitSchool}
          className="rounded-[2rem] border border-slate-100 bg-white p-6 shadow-xl shadow-slate-900/5 md:p-8"
        >
          <p className="text-sm font-bold uppercase tracking-[0.22em] text-sky-700">
            Form Sekolah
          </p>
          <h2 className="mt-3 text-2xl font-bold">Ajukan data sekolah</h2>
          <p className="mt-2 text-sm leading-7 text-slate-500">
            Data ini akan masuk sebagai pengajuan dan menunggu verifikasi
            superadmin.
          </p>

          <div className="mt-6 grid gap-4 md:grid-cols-2">
            <Field
              label="Nama sekolah"
              value={schoolForm.nama_sekolah}
              placeholder="SMAN 1 Contoh"
              onChange={(value) => updateSchool("nama_sekolah", value)}
            />

            <Field
              label="NPSN"
              value={schoolForm.npsn}
              placeholder="Masukkan NPSN"
              onChange={(value) => updateSchool("npsn", value)}
            />

            <label className="block">
              <span className="mb-2 block text-sm font-semibold text-slate-700">
                Jenis sekolah
              </span>
              <select
                value={schoolForm.jenis_sekolah}
                onChange={(event) =>
                  updateSchool("jenis_sekolah", event.target.value)
                }
                className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-sky-700 focus:bg-white focus:ring-4 focus:ring-sky-100"
              >
                <option value="SMA">SMA</option>
                <option value="SMK">SMK</option>
                <option value="MA">MA</option>
              </select>
            </label>

            <Field
              label="Nomor telepon"
              value={schoolForm.no_telp}
              placeholder="0354xxxxxx"
              onChange={(value) => updateSchool("no_telp", value)}
            />

            <Field
              label="Kota/Kabupaten"
              value={schoolForm.kota}
              placeholder="Kediri"
              onChange={(value) => updateSchool("kota", value)}
            />

            <Field
              label="Provinsi"
              value={schoolForm.provinsi}
              placeholder="Jawa Timur"
              onChange={(value) => updateSchool("provinsi", value)}
            />

            <label className="block md:col-span-2">
              <span className="mb-2 block text-sm font-semibold text-slate-700">
                Alamat sekolah
              </span>
              <textarea
                value={schoolForm.alamat}
                placeholder="Masukkan alamat lengkap sekolah"
                onChange={(event) => updateSchool("alamat", event.target.value)}
                className="min-h-28 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3.5 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-sky-700 focus:bg-white focus:ring-4 focus:ring-sky-100"
              />
            </label>
          </div>

          <div className="mt-5">
            <StatusMessage message={schoolMessage} error={schoolError} />
          </div>

          <button
            type="submit"
            disabled={loadingSchool}
            className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-slate-950 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-sky-800 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <Icon name="rocket" className="h-4 w-4" />
            {loadingSchool ? "Mengajukan..." : "Ajukan Sekolah"}
          </button>
        </form>

        <div className="space-y-6">
          <form
            onSubmit={submitTeacher}
            className="rounded-[2rem] border border-slate-100 bg-white p-6 shadow-xl shadow-slate-900/5 md:p-8"
          >
            <p className="text-sm font-bold uppercase tracking-[0.22em] text-emerald-700">
              Form Guru
            </p>
            <h2 className="mt-3 text-2xl font-bold">Tambah data guru</h2>
            <p className="mt-2 text-sm leading-7 text-slate-500">
              Akun guru dapat digunakan untuk mengelola nilai, siswa, dan
              catatan bimbingan.
            </p>

            <div className="mt-6 grid gap-4 md:grid-cols-2">
              <Field
                label="Nama guru"
                value={teacherForm.nama}
                placeholder="Nama lengkap guru"
                onChange={(value) => updateTeacher("nama", value)}
              />

              <Field
                label="NIP / NUPTK"
                value={teacherForm.nip}
                placeholder="Masukkan NIP/NUPTK"
                onChange={(value) => updateTeacher("nip", value)}
              />

              <Field
                label="Email"
                type="email"
                value={teacherForm.email}
                placeholder="guru@email.com"
                onChange={(value) => updateTeacher("email", value)}
              />

              <Field
                label="Nomor HP"
                value={teacherForm.no_hp}
                placeholder="08xxxxxxxxxx"
                onChange={(value) => updateTeacher("no_hp", value)}
              />

              <Field
                label="Username"
                value={teacherForm.username}
                placeholder="username guru"
                onChange={(value) => updateTeacher("username", value)}
              />

              <Field
                label="Password"
                type="password"
                value={teacherForm.password}
                placeholder="Password awal"
                onChange={(value) => updateTeacher("password", value)}
              />

              <label className="block md:col-span-2">
                <span className="mb-2 block text-sm font-semibold text-slate-700">
                  Jabatan
                </span>
                <select
                  value={teacherForm.jabatan}
                  onChange={(event) =>
                    updateTeacher("jabatan", event.target.value)
                  }
                  className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3.5 text-sm font-semibold text-slate-900 outline-none transition focus:border-sky-700 focus:bg-white focus:ring-4 focus:ring-sky-100"
                >
                  <option value="Guru BK">Guru BK</option>
                  <option value="Wali Kelas">Wali Kelas</option>
                  <option value="Kepala Program Keahlian">
                    Kepala Program Keahlian
                  </option>
                  <option value="Guru Mata Pelajaran">Guru Mata Pelajaran</option>
                </select>
              </label>
            </div>

            <div className="mt-5">
              <StatusMessage message={teacherMessage} error={teacherError} />
            </div>

            <button
              type="submit"
              disabled={loadingTeacher}
              className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-slate-950 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <Icon name="users" className="h-4 w-4" />
              {loadingTeacher ? "Menyimpan..." : "Tambah Guru"}
            </button>
          </form>

          <form
            onSubmit={submitImportSiswa}
            className="rounded-[2rem] border border-slate-100 bg-white p-6 shadow-xl shadow-slate-900/5 md:p-8"
          >
            <p className="text-sm font-bold uppercase tracking-[0.22em] text-violet-700">
              Import Siswa
            </p>
            <h2 className="mt-3 text-2xl font-bold">Upload file Excel siswa</h2>
            <p className="mt-2 text-sm leading-7 text-slate-500">
              Gunakan file Excel berisi minimal kolom NISN, Nama, Kelas, dan
              Jurusan.
            </p>

            <div className="mt-6 rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-6">
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls"
                className="w-full rounded-2xl border border-slate-200 bg-white px-4 py-4 text-sm font-semibold text-slate-600 file:mr-4 file:rounded-full file:border-0 file:bg-slate-950 file:px-4 file:py-2 file:text-sm file:font-bold file:text-white"
              />

              <div className="mt-4 rounded-2xl bg-white p-4 text-sm leading-7 text-slate-500">
                <p className="font-bold text-slate-700">Format minimal:</p>
                <p>NISN | Nama Siswa | Kelas | Jurusan</p>
              </div>
            </div>

            <div className="mt-5">
              <StatusMessage message={importMessage} error={importError} />
            </div>

            <button
              type="submit"
              disabled={loadingImport}
              className="mt-6 inline-flex items-center justify-center gap-2 rounded-full bg-slate-950 px-6 py-3.5 text-sm font-bold text-white shadow-xl shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-violet-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              <Icon name="upload" className="h-4 w-4" />
              {loadingImport ? "Mengimport..." : "Import Siswa"}
            </button>
          </form>
        </div>
      </section>
    </main>
  );
}