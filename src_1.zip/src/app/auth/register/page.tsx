"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { apiFetch } from "../../../lib/axios";
import { Icon } from "../../../components/ui/icons";

type RegisterForm = {
  nama: string;
  email: string;
  no_hp: string;
  username: string;
  password: string;
  password_confirmation: string;
};

const initialForm: RegisterForm = {
  nama: "",
  email: "",
  no_hp: "",
  username: "",
  password: "",
  password_confirmation: "",
};

function PublicNavbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/70 bg-white/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
        <Link href="/" className="flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-2xl bg-slate-950 text-white shadow-lg shadow-slate-900/20">
            <Icon name="sparkles" className="h-5 w-5" />
          </div>
          <div>
            <p className="text-base font-bold tracking-tight text-slate-950">
              SkillLens
            </p>
            <p className="text-xs font-semibold text-slate-500">
              Career Decision Support
            </p>
          </div>
        </Link>

        <nav className="hidden items-center gap-8 text-sm font-semibold text-slate-500 md:flex">
          <Link href="/#fitur" className="transition hover:text-slate-950">
            Fitur
          </Link>
          <Link href="/#alur" className="transition hover:text-slate-950">
            Alur
          </Link>
          <Link href="/#metode" className="transition hover:text-slate-950">
            Metode
          </Link>
          <Link href="/#bantuan" className="transition hover:text-slate-950">
            Bantuan
          </Link>
        </nav>

        <div className="flex items-center gap-3">
          <Link
            href="/auth/login"
            className="rounded-full border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:-translate-y-0.5 hover:border-sky-200 hover:text-sky-800"
          >
            Masuk
          </Link>
          <Link
            href="/auth/register"
            className="hidden rounded-full bg-slate-950 px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-slate-900/15 transition hover:-translate-y-0.5 hover:bg-sky-800 sm:inline-flex"
          >
            Daftar Admin
          </Link>
        </div>
      </div>
    </header>
  );
}

function FormInput({
  label,
  icon,
  type = "text",
  value,
  placeholder,
  autoComplete,
  onChange,
}: {
  label: string;
  icon: string;
  type?: string;
  value: string;
  placeholder: string;
  autoComplete?: string;
  onChange: (value: string) => void;
}) {
  return (
    <label className="block">
      <span className="mb-2 inline-flex items-center gap-2 text-sm font-semibold text-slate-700">
        <Icon name={icon as any} className="h-4 w-4 text-slate-500" />
        {label}
      </span>
      <input
        type={type}
        value={value}
        autoComplete={autoComplete}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-semibold text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-sky-700 focus:bg-white focus:ring-4 focus:ring-sky-100"
      />
    </label>
  );
}

export default function RegisterPage() {
  const router = useRouter();

  const [form, setForm] = useState<RegisterForm>(initialForm);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const passwordStrength = useMemo(() => {
    let score = 0;

    if (form.password.length >= 8) score += 1;
    if (/[A-Z]/.test(form.password)) score += 1;
    if (/[0-9]/.test(form.password)) score += 1;
    if (/[^A-Za-z0-9]/.test(form.password)) score += 1;

    return score;
  }, [form.password]);

  const update = (key: keyof RegisterForm, value: string) => {
    setForm((current) => ({
      ...current,
      [key]: value,
    }));
  };

  const validateForm = () => {
    if (!form.nama.trim()) return "Nama lengkap wajib diisi.";
    if (!form.email.trim()) return "Email wajib diisi.";
    if (!form.no_hp.trim()) return "Nomor HP wajib diisi.";
    if (!form.username.trim()) return "Username wajib diisi.";
    if (form.password.length < 8) return "Password minimal 8 karakter.";
    if (form.password !== form.password_confirmation) {
      return "Konfirmasi password tidak sesuai.";
    }

    return "";
  };

  const handleSubmit = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    setError("");
    setMessage("");

    const validationMessage = validateForm();
    if (validationMessage) {
      setError(validationMessage);
      return;
    }

    setIsLoading(true);

    try {
      const result = await apiFetch<{ message?: string }>(
        "/auth/register-admin-sekolah",
        {
          method: "POST",
          body: JSON.stringify({
            nama: form.nama.trim(),
            email: form.email.trim(),
            no_hp: form.no_hp.trim(),
            username: form.username.trim(),
            password: form.password,
            password_confirmation: form.password_confirmation,
          }),
        },
      );

      setMessage(
        result.message ||
          "Akun admin sekolah berhasil dibuat. Silakan login untuk melanjutkan.",
      );

      setTimeout(() => router.push("/auth/login"), 900);
    } catch (err) {
      setError(
        err instanceof Error
          ? err.message
          : "Pendaftaran gagal diproses. Silakan coba lagi.",
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="min-h-screen bg-[radial-gradient(circle_at_top_left,#e0f2fe,transparent_28%),linear-gradient(180deg,#f8fafc_0%,#ffffff_55%,#f8fafc_100%)] text-slate-950">
      <PublicNavbar />

      <section className="border-b border-slate-900 bg-slate-950">
        <div className="h-3 bg-[linear-gradient(90deg,#0f172a,#0284c7,#67e8f9)]" />
      </section>

      <section className="mx-auto grid max-w-7xl gap-8 px-5 py-12 lg:grid-cols-[1.05fr_0.95fr] lg:py-16">
        <section className="rounded-[2rem] border border-slate-100 bg-white p-6 shadow-2xl shadow-slate-900/5 md:p-8">
          <div>
            <p className="text-sm font-bold uppercase tracking-[0.26em] text-sky-700">
              Pendaftaran Admin Sekolah
            </p>
            <h1 className="mt-4 text-3xl font-bold tracking-tight text-slate-950 md:text-4xl">
              Buat akun pengelola sekolah.
            </h1>
            <p className="mt-4 max-w-2xl text-sm leading-7 text-slate-500">
              Akun ini digunakan oleh admin sekolah untuk mengelola data awal,
              mengajukan atau menghubungkan sekolah, serta membantu proses
              operasional sebelum fitur guru dan siswa digunakan.
            </p>
          </div>

          <form className="mt-8 grid gap-4 md:grid-cols-2" onSubmit={handleSubmit}>
            <FormInput
              label="Nama lengkap"
              icon="user"
              value={form.nama}
              placeholder="Masukkan nama lengkap"
              autoComplete="name"
              onChange={(value) => update("nama", value)}
            />

            <FormInput
              label="Email aktif"
              icon="mail"
              type="email"
              value={form.email}
              placeholder="contoh@email.com"
              autoComplete="email"
              onChange={(value) => update("email", value)}
            />

            <FormInput
              label="Nomor HP"
              icon="phone"
              value={form.no_hp}
              placeholder="08xxxxxxxxxx"
              autoComplete="tel"
              onChange={(value) => update("no_hp", value)}
            />

            <FormInput
              label="Username"
              icon="profile"
              value={form.username}
              placeholder="Buat username"
              autoComplete="username"
              onChange={(value) => update("username", value)}
            />

            <FormInput
              label="Password"
              icon="lock"
              type="password"
              value={form.password}
              placeholder="Minimal 8 karakter"
              autoComplete="new-password"
              onChange={(value) => update("password", value)}
            />

            <FormInput
              label="Ulangi password"
              icon="lock"
              type="password"
              value={form.password_confirmation}
              placeholder="Ulangi password"
              autoComplete="new-password"
              onChange={(value) => update("password_confirmation", value)}
            />

            <div className="md:col-span-2">
              <div className="mb-2 flex items-center justify-between text-xs font-semibold text-slate-500">
                <span>Kekuatan password</span>
                <span>{passwordStrength}/4</span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[1, 2, 3, 4].map((item) => (
                  <div
                    key={item}
                    className={`h-2 rounded-full ${
                      passwordStrength >= item ? "bg-sky-700" : "bg-slate-200"
                    }`}
                  />
                ))}
              </div>
            </div>

            {(message || error) && (
              <div
                className={`rounded-2xl p-4 text-sm font-semibold leading-6 md:col-span-2 ${
                  error
                    ? "bg-rose-50 text-rose-700 ring-1 ring-rose-100"
                    : "bg-emerald-50 text-emerald-800 ring-1 ring-emerald-100"
                }`}
              >
                {error || message}
              </div>
            )}

            <div className="flex flex-col gap-3 md:col-span-2 sm:flex-row">
              <button
                type="submit"
                disabled={isLoading}
                className="inline-flex items-center justify-center gap-2 rounded-full bg-slate-950 px-6 py-4 text-sm font-semibold text-white shadow-xl shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-sky-800 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <Icon name="rocket" className="h-4 w-4" />
                {isLoading ? "Mendaftarkan..." : "Daftar Admin Sekolah"}
              </button>

              <Link
                href="/auth/login"
                className="rounded-full border border-slate-200 bg-white px-6 py-4 text-center text-sm font-semibold text-slate-700 transition hover:-translate-y-0.5 hover:border-sky-200 hover:text-sky-800"
              >
                Sudah punya akun
              </Link>
            </div>
          </form>
        </section>

        <aside className="space-y-6">
          <section className="rounded-[2rem] bg-slate-950 p-6 text-white shadow-2xl shadow-slate-900/10 md:p-8">
            <p className="text-sm font-bold uppercase tracking-[0.26em] text-cyan-200">
              Role Akun
            </p>
            <h2 className="mt-4 text-3xl font-bold tracking-tight">
              Register hanya untuk admin sekolah.
            </h2>
            <p className="mt-4 text-sm leading-7 text-slate-200">
              Guru dan siswa tidak melakukan pendaftaran mandiri. Guru dapat
              dikelola oleh admin sekolah, sedangkan siswa dapat ditambahkan
              melalui proses import data sekolah.
            </p>
          </section>

          <section className="rounded-[2rem] border border-slate-100 bg-white p-6 shadow-2xl shadow-slate-900/5 md:p-8">
            <p className="text-sm font-bold uppercase tracking-[0.26em] text-sky-700">
              Alur Setelah Daftar
            </p>

            <div className="mt-5 space-y-4">
              {[
                "Admin sekolah membuat akun pengelola.",
                "Admin sekolah login ke dashboard.",
                "Admin sekolah memilih atau mengajukan data sekolah.",
                "Superadmin memverifikasi data sekolah.",
                "Fitur operasional sekolah dapat digunakan setelah verifikasi.",
              ].map((item, index) => (
                <div key={item} className="flex gap-4 rounded-2xl bg-slate-50 p-4">
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-sky-800 text-sm font-bold text-white">
                    {index + 1}
                  </div>
                  <p className="text-sm font-semibold leading-6 text-slate-600">
                    {item}
                  </p>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-[2rem] border border-slate-100 bg-sky-50 p-6 md:p-8">
            <p className="text-sm font-bold text-sky-900">Catatan</p>
            <p className="mt-2 text-sm leading-7 text-sky-800">
              Pastikan backend menyediakan endpoint{" "}
              <code className="rounded bg-white px-2 py-1 text-xs font-bold">
                /auth/register-admin-sekolah
              </code>{" "}
              agar akun yang dibuat otomatis memiliki role{" "}
              <code className="rounded bg-white px-2 py-1 text-xs font-bold">
                admin_sekolah
              </code>
              .
            </p>
          </section>
        </aside>
      </section>
    </main>
  );
}