import type { AuthRole } from "../lib/auth";
import type { DashboardNavItem } from "../components/layout/DashboardShell";

export const studentNav = [
  { key: "profil", label: "Profil", description: "Minat dan tujuan", href: "/siswa#profil", icon: "profile", roles: ["siswa"] },
  { key: "akademik", label: "Akademik", description: "Nilai sekolah", href: "/siswa#akademik", icon: "academic", roles: ["siswa"] },
  { key: "hasil", label: "Hasil SPK", description: "Rekomendasi", href: "/siswa#hasil", icon: "result", roles: ["siswa"] },
  { key: "roadmap", label: "Roadmap", description: "Progress belajar", href: "/siswa/roadmap", icon: "roadmap", roles: ["siswa"] },
] as const satisfies readonly DashboardNavItem[];

export const guruNav = [
  { key: "overview", label: "Ringkasan", description: "Status ruang kerja", href: "#overview", icon: "overview", roles: ["guru", "admin_sekolah"] },
  { key: "school", label: "Sekolah", description: "Data dan jurusan", href: "#school", icon: "school", roles: ["guru", "admin_sekolah"] },
  { key: "import", label: "Import Nilai", description: "Excel akademik", href: "#import", icon: "upload", roles: ["guru", "admin_sekolah"] },
  { key: "accounts", label: "Akun Siswa", description: "Hasil import", href: "#accounts", icon: "users", roles: ["guru", "admin_sekolah"] },
  { key: "guidance", label: "Bimbingan", description: "Catatan siswa", href: "#guidance", icon: "guidance", roles: ["guru", "admin_sekolah"] },
] as const satisfies readonly DashboardNavItem[];

export const adminNav = [
  { key: "dashboard", label: "Dashboard", description: "Monitoring sistem", href: "/admin/dashboard", icon: "dashboard", roles: ["admin", "superadmin"] },
  { key: "verifikasi", label: "Verifikasi", description: "Sekolah dan akun", href: "/admin/verifikasi", icon: "verify", roles: ["admin", "superadmin"] },
  { key: "sekolah", label: "Data Sekolah", description: "Daftar sekolah", href: "/admin/sekolah", icon: "school", roles: ["admin", "superadmin"] },
] as const satisfies readonly DashboardNavItem[];

export const superadminNav = [
  { key: "admin", label: "Kelola Admin", description: "Akun administrator", href: "/superadmin/admin", icon: "users", roles: ["superadmin"] },
] as const satisfies readonly DashboardNavItem[];

export function dashboardHomeByRole(role?: AuthRole | string | null) {
  if (role === "superadmin") return "/superadmin/admin";
  if (role === "admin") return "/admin/dashboard";
  if (role === "admin_sekolah") return "/admin-sekolah";
  if (role === "guru") return "/guru";
  if (role === "siswa") return "/siswa";
  return "/auth/login";
}
