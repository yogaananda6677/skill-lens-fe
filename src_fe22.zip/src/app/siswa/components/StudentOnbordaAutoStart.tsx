"use client";

import { useEffect } from "react";
import { useOnborda } from "onborda";
import { STUDENT_ONBORDA_TOUR } from "./StudentOnbordaProvider";
import { STUDENT_ONBORDA_START_EVENT } from "./StartStudentOnbordaButton";

type StudentOnbordaAutoStartProps = {
  autoStart?: boolean;
  studentKey?: string | number | null;
};

export function StudentOnbordaAutoStart({
  autoStart = false,
  studentKey,
}: StudentOnbordaAutoStartProps) {
  const { startOnborda } = useOnborda();

  useEffect(() => {
    if (!autoStart || !studentKey) return;

    const timer = window.setTimeout(() => {
      window.dispatchEvent(new CustomEvent(STUDENT_ONBORDA_START_EVENT));
      startOnborda(STUDENT_ONBORDA_TOUR);
    }, 700);

    return () => window.clearTimeout(timer);
  }, [autoStart, startOnborda, studentKey]);

  return null;
}
