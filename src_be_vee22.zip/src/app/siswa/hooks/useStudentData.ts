"use client";

import { useEffect, useState, type SetStateAction } from "react";
import {
  getSiswaMe,
  normalizeStudentAchievements,
  toStudentProfile,
  type SiswaMeResponse,
} from "../../../features/siswa/api";
import type {
  StudentAchievement,
  StudentProfileForm,
} from "../../../features/siswa/types";
import { getStoredUser } from "../../../lib/auth";

const emptyProfile: StudentProfileForm = {
  name: "",
  nisn: "",
  school: "",
  className: "",
  major: "",
  academicScores: {},
  interests: [],
  hobbies: [],
  talents: [],
  experiences: [],
  achievements: "",
  goal: "kuliah",
  learningPreference: "",
  constraints: "",
};

const FIRST_PREPARING_SESSION_KEY = "skilllens_student_preparing_seen";
const MIN_FIRST_PREPARING_TIME = 800;

type LoadedStudent = {
  data: SiswaMeResponse;
  profile: StudentProfileForm;
  prestasiRows: StudentAchievement[];
};

let cachedStudent: LoadedStudent | null = null;
let pendingStudentRequest: Promise<LoadedStudent> | null = null;

function wait(ms: number) {
  return new Promise((resolve) => window.setTimeout(resolve, ms));
}

function shouldUsePreparingDelay() {
  if (typeof window === "undefined") return false;
  return window.sessionStorage.getItem(FIRST_PREPARING_SESSION_KEY) !== "true";
}

function markPreparingDelayUsed() {
  if (typeof window === "undefined") return;
  window.sessionStorage.setItem(FIRST_PREPARING_SESSION_KEY, "true");
}

function getStoredMustChangePassword() {
  if (typeof window === "undefined") return false;
  return Boolean(getStoredUser()?.must_change_password);
}

function normalizeStudentResponse(data: SiswaMeResponse): SiswaMeResponse {
  const raw = data as any;
  const mustChangePassword =
    raw?.must_change_password ??
    raw?.mustChangePassword ??
    raw?.user?.must_change_password ??
    raw?.akun?.must_change_password ??
    getStoredMustChangePassword();

  return {
    ...data,
    must_change_password: Boolean(mustChangePassword),
  };
}

async function requestStudent(force = false) {
  if (!force && cachedStudent) return cachedStudent;
  if (!force && pendingStudentRequest) return pendingStudentRequest;

  pendingStudentRequest = getSiswaMe()
    .then((response) => {
      const data = normalizeStudentResponse(response);
      const loaded: LoadedStudent = {
        data,
        profile: toStudentProfile(data),
        prestasiRows: normalizeStudentAchievements(data),
      };

      cachedStudent = loaded;
      return loaded;
    })
    .finally(() => {
      pendingStudentRequest = null;
    });

  return pendingStudentRequest;
}

export function resetStudentDataCache() {
  cachedStudent = null;
  pendingStudentRequest = null;
}

export function useStudentData() {
  const [profile, setProfile] = useState<StudentProfileForm>(
    cachedStudent?.profile ?? emptyProfile,
  );
  const [studentData, setStudentData] = useState<SiswaMeResponse | null>(
    cachedStudent?.data ?? null,
  );
  const [prestasiRows, setPrestasiRows] = useState<StudentAchievement[]>(
    cachedStudent?.prestasiRows ?? [],
  );
  const [loadingProfile, setLoadingProfile] = useState(!cachedStudent);
  const [error, setError] = useState("");

  async function loadStudent(options?: { force?: boolean; showPreparing?: boolean }) {
    const force = Boolean(options?.force);
    const showPreparing = Boolean(options?.showPreparing);
    const startedAt = Date.now();
    const useDelay = showPreparing && !cachedStudent && shouldUsePreparingDelay();

    if (!force && cachedStudent) {
      setStudentData(cachedStudent.data);
      setProfile(cachedStudent.profile);
      setPrestasiRows(cachedStudent.prestasiRows);
      setLoadingProfile(false);
      setError("");
      return cachedStudent;
    }

    setLoadingProfile(true);
    setError("");

    try {
      const loaded = await requestStudent(force);
      setStudentData(loaded.data);
      setProfile(loaded.profile);
      setPrestasiRows(loaded.prestasiRows);
      return loaded;
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Gagal mengambil data siswa.",
      );
      return null;
    } finally {
      if (useDelay) {
        const elapsed = Date.now() - startedAt;
        const remaining = Math.max(0, MIN_FIRST_PREPARING_TIME - elapsed);

        if (remaining > 0) {
          await wait(remaining);
        }

        markPreparingDelayUsed();
      }

      setLoadingProfile(false);
    }
  }

  useEffect(() => {
    let active = true;

    async function init() {
      const loaded = await loadStudent({ showPreparing: true });
      if (!active || !loaded) return;
    }

    init();

    return () => {
      active = false;
    };
  }, []);

  function updateProfile(patch: Partial<StudentProfileForm>) {
    setProfile((current) => {
      const next = { ...current, ...patch };

      if (cachedStudent) {
        cachedStudent = { ...cachedStudent, profile: next };
      }

      return next;
    });
  }

  function markPasswordChanged() {
    setStudentData((current) => {
      const next = current ? { ...current, must_change_password: false } : current;

      if (cachedStudent && next) {
        cachedStudent = { ...cachedStudent, data: next };
      }

      return next;
    });
  }

  return {
    profile,
    setProfile: (value: SetStateAction<StudentProfileForm>) => {
      setProfile((current) => {
        const next = typeof value === "function" ? value(current) : value;

        if (cachedStudent) {
          cachedStudent = { ...cachedStudent, profile: next };
        }

        return next;
      });
    },
    studentData,
    mustChangePassword: Boolean(
      studentData?.must_change_password ?? getStoredMustChangePassword(),
    ),
    prestasiRows,
    loadingProfile,
    error,
    setError,
    updateProfile,
    markPasswordChanged,
    reloadStudent: () => loadStudent({ force: true, showPreparing: false }),
  };
}
