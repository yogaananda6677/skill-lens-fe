"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { clearAuth, getStoredUser } from "../../lib/auth";
import { studentNav } from "../../config/navigation";
import { Icon } from "../ui/icons";

export function StudentTopNav({ children }: { children: ReactNode }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [name, setName] = useState("Siswa");
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    const user = getStoredUser();
    if (!user || user.role !== "siswa") {
      router.replace(user ? "/auth/login" : "/auth/login");
      return;
    }
    setName(user.nama || "Siswa");
  }, [router]);

  function logout() {
    clearAuth();
    router.replace("/auth/login");
  }

  return (
    <main className="min-h-screen bg-slate-50 text-slate-950">
      <header className="sticky top-0 z-50 border-b border-slate-200/80 bg-white/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
          <Link href="/siswa" className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-slate-950 text-white shadow-lg shadow-slate-900/15">
              <Icon name="sparkles" className="h-5 w-5" />
            </div>
            <div>
              <p className="text-base font-extrabold tracking-tight">SkillLens</p>
              <p className="text-[11px] font-bold uppercase tracking-[0.18em] text-slate-400">Ruang siswa</p>
            </div>
          </Link>

          <nav className="hidden items-center gap-2 lg:flex">
            {studentNav.map((item) => {
              const isActive = item.href === pathname || (item.href?.includes("#") && pathname === "/siswa");
              return (
                <Link key={item.key} href={item.href ?? "/siswa"} className={`inline-flex items-center gap-2 rounded-full px-4 py-2.5 text-sm font-bold transition ${isActive ? "bg-slate-950 text-white" : "text-slate-600 hover:bg-slate-100 hover:text-slate-950"}`}>
                  <Icon name={item.icon ?? "dashboard"} className="h-4 w-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <div className="hidden items-center gap-3 sm:flex">
            <div className="rounded-full bg-slate-100 px-4 py-2 text-sm font-bold text-slate-700">{name}</div>
            <button type="button" onClick={logout} className="rounded-full border border-rose-100 bg-rose-50 px-4 py-2.5 text-sm font-bold text-rose-600 transition hover:bg-rose-600 hover:text-white">
              Keluar
            </button>
          </div>

          <button type="button" onClick={() => setMenuOpen((value) => !value)} className="grid h-11 w-11 place-items-center rounded-2xl bg-slate-100 lg:hidden" aria-label="Menu siswa">
            <Icon name={menuOpen ? "x" : "menu"} />
          </button>
        </div>
        {menuOpen && (
          <div className="border-t border-slate-200 bg-white px-5 py-4 lg:hidden">
            <div className="mx-auto grid max-w-7xl gap-2">
              {studentNav.map((item) => (
                <Link key={item.key} href={item.href ?? "/siswa"} onClick={() => setMenuOpen(false)} className="flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-bold text-slate-700 hover:bg-slate-100">
                  <Icon name={item.icon ?? "dashboard"} className="h-4 w-4" />
                  {item.label}
                </Link>
              ))}
              <button type="button" onClick={logout} className="mt-2 rounded-2xl bg-rose-50 px-4 py-3 text-left text-sm font-bold text-rose-600">
                Keluar
              </button>
            </div>
          </div>
        )}
      </header>
      {children}
    </main>
  );
}
