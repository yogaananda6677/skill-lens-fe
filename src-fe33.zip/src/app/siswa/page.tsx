"use client";

import { useEffect, useMemo, useState, type ReactNode } from "react";
import { StudentTopNav } from "../../components/layout/StudentTopNav";
import { FeedbackModal } from "../../components/ui/FeedbackModal";
import { Icon } from "../../components/ui/icons";
import { experienceOptions, hobbyOptions, interestOptions, talentOptions } from "../../data/profile-options";
import { getSiswaMe, processSiswaSpk, saveSiswaProfile, selectStudentRoadmap, toStudentProfile } from "../../features/siswa/api";
import type { AcademicScores, Recommendation, StudentProfileForm } from "../../features/siswa/types";

const emptyProfile: StudentProfileForm = { name: "", nisn: "", school: "", className: "", major: "", academicScores: {}, interests: [], hobbies: [], talents: [], experiences: [], achievements: "", goal: "kuliah", learningPreference: "", constraints: "" };

type ArrayField = "interests" | "hobbies" | "talents" | "experiences";

function Panel({ children, id, className = "" }: { children: ReactNode; id?: string; className?: string }) {
  return <section id={id} className={`scroll-mt-28 rounded-[2rem] border border-slate-100 bg-white p-6 shadow-xl shadow-slate-900/5 ${className}`}>{children}</section>;
}

function toList(text: string) {
  return text.split(/[,\n]/).map((item) => item.trim()).filter(Boolean);
}

function average(scores: AcademicScores) {
  const values = Object.values(scores).filter((value): value is number => typeof value === "number" && Number.isFinite(value) && value > 0);
  if (!values.length) return 0;
  return Math.round(values.reduce((sum, value) => sum + value, 0) / values.length);
}

function ToggleChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return <button type="button" onClick={onClick} className={`rounded-full border px-4 py-2 text-sm font-bold transition ${active ? "border-slate-950 bg-slate-950 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-slate-400 hover:text-slate-950"}`}>{label}</button>;
}

function OptionPicker({ title, options, selected, onToggle }: { title: string; options: readonly string[]; selected: string[]; onToggle: (value: string) => void }) {
  const [query, setQuery] = useState("");
  const visible = useMemo(() => {
    const keyword = query.trim().toLowerCase();
    const filtered = keyword ? options.filter((item) => item.toLowerCase().includes(keyword)) : options;
    const pinned = selected.filter((item) => !filtered.includes(item));
    return [...pinned, ...filtered].slice(0, 32);
  }, [options, query, selected]);

  return (
    <div className="rounded-3xl border border-slate-200 bg-slate-50 p-4">
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm font-extrabold text-slate-950">{title}</p>
        <span className="rounded-full bg-white px-3 py-1 text-xs font-extrabold text-slate-700 shadow-sm">{selected.length} dipilih</span>
      </div>
      <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Cari pilihan..." className="mt-4 w-full rounded-2xl border border-slate-200 bg-white px-4 py-3 text-sm font-bold outline-none focus:border-slate-950" />
      <div className="mt-4 flex max-h-56 flex-wrap gap-2 overflow-y-auto pr-1">{visible.map((option) => <ToggleChip key={option} label={option} active={selected.includes(option)} onClick={() => onToggle(option)} />)}</div>
    </div>
  );
}

function RecommendationCard({ item, onSelectRoadmap }: { item: Recommendation; onSelectRoadmap: (roadmapId?: number | null) => void }) {
  return (
    <article className="rounded-[2rem] border border-slate-100 bg-white p-6 shadow-xl shadow-slate-900/5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <span className="rounded-full bg-sky-50 px-3 py-1 text-xs font-extrabold text-sky-700">Peringkat {item.topsisRank}</span>
          <h3 className="mt-4 text-xl font-extrabold leading-tight text-slate-950">{item.title}</h3>
          <p className="mt-1 text-sm font-bold capitalize text-slate-500">{item.category}</p>
        </div>
        <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-slate-950 text-xl font-extrabold text-white">{Math.round(item.score || 0)}</div>
      </div>
      <p className="mt-4 text-sm font-medium leading-7 text-slate-600">{item.summary}</p>
      {!!item.dominantFactors.length && <div className="mt-4 flex flex-wrap gap-2">{item.dominantFactors.map((factor) => <span key={factor} className="rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-700">{factor}</span>)}</div>}
      <button type="button" onClick={() => onSelectRoadmap(item.roadmapId)} className="mt-5 w-full rounded-2xl bg-slate-950 px-5 py-3 text-sm font-extrabold text-white transition hover:bg-sky-700 disabled:opacity-50" disabled={!item.roadmapId}>{item.roadmapId ? "Pilih roadmap ini" : "Roadmap belum tersedia"}</button>
    </article>
  );
}

function buildPayload(profile: StudentProfileForm) {
  return { minat: profile.interests, hobi: profile.hobbies, bakat: profile.talents, pengalaman: profile.experiences, prestasi: toList(profile.achievements), tujuan_karir: profile.goal || "kuliah", top_n: 3 };
}

export default function SiswaPage() {
  const [profile, setProfile] = useState<StudentProfileForm>(emptyProfile);
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [loadingProfile, setLoadingProfile] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    getSiswaMe().then((data) => setProfile(toStudentProfile(data))).catch((err) => setError(err instanceof Error ? err.message : "Gagal mengambil data siswa.")).finally(() => setLoadingProfile(false));
  }, []);

  function toggleArrayValue(field: ArrayField, value: string) {
    setProfile((current) => {
      const exists = current[field].includes(value);
      return { ...current, [field]: exists ? current[field].filter((item) => item !== value) : [...current[field], value] };
    });
  }

  async function handleSaveOnly() {
    setError(""); setMessage("");
    try { await saveSiswaProfile(buildPayload(profile)); setMessage("Profil berhasil disimpan."); }
    catch (err) { setError(err instanceof Error ? err.message : "Gagal menyimpan profil."); }
  }

  async function handleProcessSpk() {
    setError(""); setMessage(""); setProcessing(true);
    try {
      const result = await processSiswaSpk(buildPayload(profile));
      setRecommendations(result.recommendations);
      setMessage(result.message || "Rekomendasi berhasil diproses.");
      setModalOpen(true);
      window.setTimeout(() => document.querySelector("#hasil")?.scrollIntoView({ behavior: "smooth", block: "start" }), 150);
    } catch (err) { setError(err instanceof Error ? err.message : "Gagal memproses rekomendasi."); }
    finally { setProcessing(false); }
  }

  async function handleSelectRoadmap(roadmapId?: number | null) {
    if (!roadmapId) return;
    setError(""); setMessage("");
    try { await selectStudentRoadmap(roadmapId); window.location.href = "/siswa/roadmap"; }
    catch (err) { setError(err instanceof Error ? err.message : "Gagal memilih roadmap."); }
  }

  const academicAverage = average(profile.academicScores);
  const academicRows = [["Numerik", profile.academicScores.numerik ?? 0], ["Bahasa", profile.academicScores.bahasa ?? 0], ["Sains", profile.academicScores.sains ?? 0], ["Sosial", profile.academicScores.sosial ?? 0], ["Teknologi", profile.academicScores.teknologi ?? 0], ["Kreativitas", profile.academicScores.kreativitas ?? 0], ["Softskill/P5", profile.academicScores.softskill ?? 0], ["Praktik", profile.academicScores.praktik ?? 0], ["Agama", profile.academicScores.agama ?? 0]] as const;

  return (
    <StudentTopNav>
      <section className="mx-auto max-w-7xl px-5 py-8">
        <div className="rounded-[2.5rem] bg-slate-950 p-7 text-white shadow-2xl shadow-slate-950/15 md:p-10">
          <p className="text-sm font-extrabold uppercase tracking-[0.24em] text-cyan-200">Ruang Siswa</p>
          <h1 className="mt-3 text-3xl font-extrabold tracking-tight md:text-5xl">Lengkapi profil dan lihat rekomendasi terbaikmu.</h1>
          <p className="mt-4 max-w-3xl text-sm font-medium leading-7 text-slate-300">Nilai akademik dibaca dari data sekolah. Kamu cukup melengkapi minat, hobi, bakat, pengalaman, dan prestasi agar rekomendasi lebih akurat.</p>
        </div>

        {loadingProfile && <div className="mt-6 rounded-2xl bg-white p-4 text-sm font-bold text-slate-500 shadow-sm">Memuat data siswa...</div>}
        {(message || error) && <div className={`mt-6 rounded-2xl p-4 text-sm font-bold ${error ? "bg-rose-50 text-rose-700 ring-1 ring-rose-100" : "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"}`}>{error || message}</div>}

        <div className="mt-6 grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <Panel id="profil">
            <div className="flex items-start justify-between gap-4">
              <div><p className="text-sm font-extrabold uppercase tracking-[0.2em] text-sky-700">Profil</p><h2 className="mt-2 text-2xl font-extrabold text-slate-950">Data potensi siswa</h2></div>
              <span className="rounded-full bg-slate-100 px-4 py-2 text-xs font-extrabold text-slate-600">{profile.name || "Siswa"}</span>
            </div>
            <div className="mt-6 grid gap-4 md:grid-cols-2">
              <OptionPicker title="Minat" options={interestOptions} selected={profile.interests} onToggle={(value) => toggleArrayValue("interests", value)} />
              <OptionPicker title="Hobi" options={hobbyOptions} selected={profile.hobbies} onToggle={(value) => toggleArrayValue("hobbies", value)} />
              <OptionPicker title="Bakat" options={talentOptions} selected={profile.talents} onToggle={(value) => toggleArrayValue("talents", value)} />
              <OptionPicker title="Pengalaman" options={experienceOptions} selected={profile.experiences} onToggle={(value) => toggleArrayValue("experiences", value)} />
            </div>
            <div className="mt-5 grid gap-4 md:grid-cols-[1fr_260px]">
              <label className="block"><span className="mb-2 block text-sm font-extrabold text-slate-700">Prestasi</span><textarea value={profile.achievements} onChange={(event) => setProfile((current) => ({ ...current, achievements: event.target.value }))} placeholder="Contoh: Juara lomba desain poster, finalis OSN, aktif organisasi" className="min-h-28 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold outline-none focus:border-sky-700 focus:bg-white" /></label>
              <label className="block"><span className="mb-2 block text-sm font-extrabold text-slate-700">Tujuan</span><select value={profile.goal} onChange={(event) => setProfile((current) => ({ ...current, goal: event.target.value }))} className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-bold outline-none focus:border-sky-700 focus:bg-white"><option value="kuliah">Kuliah</option><option value="kerja">Kerja</option><option value="wirausaha">Wirausaha</option></select></label>
            </div>
            <div className="mt-6 flex flex-wrap gap-3"><button type="button" onClick={handleSaveOnly} className="rounded-full border border-slate-200 bg-white px-5 py-3 text-sm font-extrabold text-slate-700 transition hover:border-sky-200 hover:text-sky-700">Simpan Profil</button><button type="button" onClick={handleProcessSpk} disabled={processing} className="rounded-full bg-slate-950 px-5 py-3 text-sm font-extrabold text-white shadow-lg transition hover:bg-sky-700 disabled:opacity-60"><Icon name="rocket" className="mr-2 inline h-4 w-4" />{processing ? "Memproses..." : "Proses Rekomendasi"}</button></div>
          </Panel>

          <Panel id="akademik">
            <p className="text-sm font-extrabold uppercase tracking-[0.2em] text-sky-700">Akademik</p><h2 className="mt-2 text-2xl font-extrabold text-slate-950">Ringkasan nilai</h2>
            <div className="mt-6 rounded-3xl bg-slate-950 p-6 text-white"><p className="text-sm font-bold text-slate-300">Rata-rata akademik</p><p className="mt-3 text-6xl font-extrabold">{academicAverage}</p></div>
            <div className="mt-5 grid gap-3">{academicRows.map(([label, value]) => <div key={label} className="rounded-2xl bg-slate-50 p-4"><div className="flex items-center justify-between text-sm font-extrabold"><span>{label}</span><span>{Math.round(value || 0)}</span></div><div className="mt-3 h-2 rounded-full bg-white"><div className="h-full rounded-full bg-sky-700" style={{ width: `${Math.min(100, Math.max(0, value || 0))}%` }} /></div></div>)}</div>
          </Panel>
        </div>

        <Panel id="hasil" className="mt-6">
          <p className="text-sm font-extrabold uppercase tracking-[0.2em] text-sky-700">Hasil Rekomendasi</p><h2 className="mt-2 text-2xl font-extrabold text-slate-950">Pilihan terbaik berdasarkan SPK</h2>
          {recommendations.length ? <div className="mt-6 grid gap-5 lg:grid-cols-3">{recommendations.map((item) => <RecommendationCard key={item.id} item={item} onSelectRoadmap={handleSelectRoadmap} />)}</div> : <div className="mt-6 rounded-3xl bg-slate-50 p-8 text-center text-sm font-bold text-slate-500">Belum ada rekomendasi. Lengkapi profil lalu tekan tombol Proses Rekomendasi.</div>}
        </Panel>
      </section>
      <FeedbackModal open={modalOpen} title="Rekomendasi berhasil diproses" description="Hasil rekomendasi sudah tersedia. Silakan cek peringkat dan pilih roadmap yang paling sesuai." actionLabel="Lihat Hasil" onClose={() => setModalOpen(false)} onAction={() => setModalOpen(false)} />
    </StudentTopNav>
  );
}
