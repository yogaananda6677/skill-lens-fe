import type { JurusanRow, SiswaRow } from "../types";
import { PageCard } from "./AdminSchoolShared";

export function AdminSchoolDataSiswa({
  siswaRows,
  siswaTotal,
  siswaPage,
  siswaLimit,
  siswaSearch,
  siswaJurusanFilter,
  siswaTahunFilter,
  jurusanRows,
  setSiswaSearch,
  setSiswaJurusanFilter,
  setSiswaTahunFilter,
  setSiswaPage,
  loadSiswa,
}: {
  siswaRows: SiswaRow[];
  siswaTotal: number;
  siswaPage: number;
  siswaLimit: number;
  siswaSearch: string;
  siswaJurusanFilter: string;
  siswaTahunFilter: string;
  jurusanRows: JurusanRow[];
  setSiswaSearch: (value: string) => void;
  setSiswaJurusanFilter: (value: string) => void;
  setSiswaTahunFilter: (value: string) => void;
  setSiswaPage: (value: number) => void;
  loadSiswa: (page?: number) => void;
}) {
  const totalPages = Math.max(1, Math.ceil(siswaTotal / siswaLimit));

  return (
    <PageCard
      eyebrow="Data Siswa"
      title="Kelola data siswa"
      description="Lihat siswa hasil import dengan filter jurusan dan tahun ajaran."
      icon="profile"
    >
      <div className="mb-5 grid gap-3 md:grid-cols-3">
        <input
          value={siswaSearch}
          onChange={(event) => setSiswaSearch(event.target.value)}
          placeholder="Cari nama, NISN, username..."
          className="rounded-2xl border border-slate-200 px-4 py-3.5 text-sm font-medium outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
        />

        <select
          value={siswaJurusanFilter}
          onChange={(event) => setSiswaJurusanFilter(event.target.value)}
          className="rounded-2xl border border-slate-200 px-4 py-3.5 text-sm font-medium outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
        >
          <option value="semua">Semua jurusan</option>
          {jurusanRows.map((jurusan) => (
            <option key={jurusan.id} value={jurusan.id}>
              {jurusan.nama}
            </option>
          ))}
        </select>

        <input
          value={siswaTahunFilter === "semua" ? "" : siswaTahunFilter}
          onChange={(event) =>
            setSiswaTahunFilter(event.target.value.trim() || "semua")
          }
          placeholder="Tahun ajaran, contoh: 2025/2026"
          className="rounded-2xl border border-slate-200 px-4 py-3.5 text-sm font-medium outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
        />
      </div>

      <div className="overflow-hidden rounded-3xl border border-slate-200">
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-slate-50 text-xs font-semibold uppercase tracking-wide text-slate-500">
              <tr>
                <th className="px-5 py-4">Siswa</th>
                <th className="px-5 py-4">NISN</th>
                <th className="px-5 py-4">Kelas</th>
                <th className="px-5 py-4">Jurusan</th>
                <th className="px-5 py-4">Tahun Ajaran</th>
                <th className="px-5 py-4">Username</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {siswaRows.length ? (
                siswaRows.map((siswa) => (
                  <tr key={siswa.id} className="hover:bg-sky-50/50">
                    <td className="px-5 py-4 font-semibold text-slate-900">
                      {siswa.nama}
                    </td>
                    <td className="px-5 py-4 text-slate-600">{siswa.nisn}</td>
                    <td className="px-5 py-4 text-slate-600">{siswa.kelas}</td>
                    <td className="px-5 py-4 text-slate-600">
                      {siswa.jurusan || "-"}
                    </td>
                    <td className="px-5 py-4 text-slate-600">
                      {siswa.tahun_ajaran || "-"}
                    </td>
                    <td className="px-5 py-4 text-slate-600">
                      {siswa.username}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={6}
                    className="px-5 py-10 text-center text-sm font-medium text-slate-400"
                  >
                    Belum ada data siswa.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-5 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
        <p className="text-sm font-medium text-slate-500">
          Total {siswaTotal} data
        </p>

        <div className="flex gap-2">
          <button
            type="button"
            disabled={siswaPage <= 1}
            onClick={() => {
              const next = siswaPage - 1;
              setSiswaPage(next);
              loadSiswa(next);
            }}
            className="rounded-full border border-slate-200 px-4 py-2 text-sm font-semibold disabled:opacity-50"
          >
            Sebelumnya
          </button>

          <span className="rounded-full bg-sky-50 px-4 py-2 text-sm font-semibold text-sky-700">
            {siswaPage} / {totalPages}
          </span>

          <button
            type="button"
            disabled={siswaPage >= totalPages}
            onClick={() => {
              const next = siswaPage + 1;
              setSiswaPage(next);
              loadSiswa(next);
            }}
            className="rounded-full border border-slate-200 px-4 py-2 text-sm font-semibold disabled:opacity-50"
          >
            Berikutnya
          </button>
        </div>
      </div>
    </PageCard>
  );
}