"use client";

import { Icon } from "../../../components/ui/icons";
import {
  experienceOptions,
  hobbyOptions,
  interestOptions,
  talentOptions,
} from "../../../data/profile-options";
import type {
  StudentAchievement,
  StudentProfileForm,
} from "../../../features/siswa/types";
import { OptionPicker, Panel, SectionTitle, type ArrayField } from "./StudentShared";

export function StudentProfilePanel({
  profile,
  prestasiRows,
  processing,
  onChangeProfile,
  onToggleArray,
  onSave,
  onProcess,
}: {
  profile: StudentProfileForm;
  prestasiRows: StudentAchievement[];
  processing: boolean;
  onChangeProfile: (patch: Partial<StudentProfileForm>) => void;
  onToggleArray: (field: ArrayField, value: string) => void;
  onSave: () => void;
  onProcess: () => void;
  processLabel?: string;
}) {
  return (
    <Panel id="profil">
      <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
        <SectionTitle
          eyebrow="Profil Potensi"
          title="Data minat dan pengalaman"
          description="Pilih beberapa hal yang paling menggambarkan dirimu."
        />

        <span className="w-fit rounded-full bg-sky-50 px-4 py-2 text-xs font-bold text-sky-700 ring-1 ring-sky-100">
          {profile.name || "Siswa"}
        </span>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <OptionPicker
          title="Minat"
          options={interestOptions}
          selected={profile.interests}
          onToggle={(value) => onToggleArray("interests", value)}
        />

        <OptionPicker
          title="Hobi"
          options={hobbyOptions}
          selected={profile.hobbies}
          onToggle={(value) => onToggleArray("hobbies", value)}
        />

        <OptionPicker
          title="Bakat"
          options={talentOptions}
          selected={profile.talents}
          onToggle={(value) => onToggleArray("talents", value)}
        />

        <OptionPicker
          title="Pengalaman"
          options={experienceOptions}
          selected={profile.experiences}
          onToggle={(value) => onToggleArray("experiences", value)}
        />
      </div>

      <div className="mt-5 grid gap-4 md:grid-cols-[1fr_260px]">
  <div className="block">
    <span className="mb-2 block text-sm font-bold text-slate-700">
      Prestasi
    </span>

    <div className="min-h-28 rounded-2xl border border-slate-200 bg-slate-50 p-4">
      {prestasiRows.length ? (
        <div className="grid gap-3">
          {prestasiRows.map((item) => (
            <div
              key={item.id ?? item.id_prestasi ?? item.nama_prestasi}
              className="rounded-2xl border border-sky-100 bg-white p-4"
            >
              <div className="flex flex-col gap-2 md:flex-row md:items-start md:justify-between">
                <div>
                  <p className="text-sm font-bold text-slate-950">
                    {item.nama_prestasi}
                  </p>

                  <p className="mt-1 text-xs font-semibold text-slate-500">
                    {[item.tingkat, item.tahun, item.penyelenggara]
                      .filter(Boolean)
                      .join(" • ") || "Detail prestasi belum lengkap"}
                  </p>
                </div>

                {item.bukti_url ? (
                  <a
                    href={item.bukti_url}
                    target="_blank"
                    rel="noreferrer"
                    className="w-fit rounded-full bg-sky-50 px-3 py-1 text-xs font-bold text-sky-700 ring-1 ring-sky-100 transition hover:bg-sky-600 hover:text-white"
                  >
                    Lihat bukti
                  </a>
                ) : (
                  <span className="w-fit rounded-full bg-slate-100 px-3 py-1 text-xs font-bold text-slate-500">
                    Tanpa bukti
                  </span>
                )}
              </div>

              {item.keterangan ? (
                <p className="mt-3 text-xs font-medium leading-6 text-slate-500">
                  {item.keterangan}
                </p>
              ) : null}
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-slate-200 bg-white p-5 text-center">
          <p className="text-sm font-semibold text-slate-500">
            Belum ada data prestasi.
          </p>
          <p className="mt-1 text-xs font-medium text-slate-400">
            Data prestasi diambil dari tabel prestasi siswa, bukan diketik
            manual di halaman ini.
          </p>
        </div>
      )}
    </div>

    <p className="mt-2 text-xs font-medium text-slate-400">
      Prestasi otomatis diambil dari tabel prestasi siswa.
    </p>
  </div>

  <label className="block">
    <span className="mb-2 block text-sm font-bold text-slate-700">
      Tujuan
    </span>

    <select
      value={profile.goal}
      onChange={(event) => onChangeProfile({ goal: event.target.value })}
      className="w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm font-medium text-slate-800 outline-none transition focus:border-sky-500 focus:bg-white focus:ring-4 focus:ring-sky-100"
    >
      <option value="kuliah">Kuliah</option>
      <option value="kerja">Kerja</option>
      <option value="wirausaha">Wirausaha</option>
    </select>

    <div className="mt-4 rounded-2xl bg-slate-50 p-4 text-xs font-medium leading-6 text-slate-500">
      Hasil rekomendasi akan menyesuaikan tujuan yang kamu pilih.
    </div>
  </label>
</div>

      <div className="mt-6 flex flex-wrap gap-3">
        <button
          type="button"
          onClick={onSave}
          className="rounded-full border border-slate-200 bg-white px-5 py-3 text-sm font-bold text-slate-700 transition hover:border-sky-200 hover:text-sky-700"
        >
          Simpan Profil
        </button>

        <button
          type="button"
          onClick={onProcess}
          disabled={processing}
          className="rounded-full bg-sky-600 px-5 py-3 text-sm font-bold text-white shadow-lg shadow-sky-600/20 transition hover:-translate-y-0.5 hover:bg-sky-700 disabled:opacity-60"
        >
          <Icon name="rocket" className="mr-2 inline h-4 w-4" />
          {processing ? "Memproses..." : "Proses Rekomendasi"}
        </button>
      </div>
    </Panel>
  );
}