"use client";

import { useEffect } from "react";
import { useOnborda } from "onborda";
import { STUDENT_ONBORDA_TOUR } from "./StudentOnbordaProvider";

function onboardingKey(studentKey?: string | number | null) {
  return `skilllens_student_onborda_seen_${studentKey || "unknown"}`;
}

type StudentOnbordaAutoStartProps = {
  autoStart?: boolean;
  studentKey?: string | number | null;
};

export function StudentOnbordaAutoStart({
  autoStart = false,
  studentKey,
}: StudentOnbordaAutoStartProps) {
  const { startOnborda } = useOnborda();

  useEffect(() => {
    if (!autoStart || !studentKey) return;

    const key = onboardingKey(studentKey);
    const alreadySeen = window.localStorage.getItem(key) === "true";

    if (alreadySeen) return;

    const timer = window.setTimeout(() => {
      startOnborda(STUDENT_ONBORDA_TOUR);
      window.localStorage.setItem(key, "true");
    }, 450);

    return () => window.clearTimeout(timer);
  }, [autoStart, startOnborda, studentKey]);

  return null;
}
