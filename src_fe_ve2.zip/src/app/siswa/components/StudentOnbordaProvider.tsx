"use client";

import type { ReactNode } from "react";
import { Onborda, OnbordaProvider } from "onborda";
import { Icon } from "../../../components/ui/icons";
import { StudentOnbordaCard } from "./StudentOnbordaCard";
import { StudentOnbordaAutoStart } from "./StudentOnbordaAutoStart";

export const STUDENT_ONBORDA_TOUR = "student-dashboard-tour";

const studentSteps = [
  {
    tour: STUDENT_ONBORDA_TOUR,
    steps: [
      {
        icon: <Icon name="home" className="h-5 w-5" />,
        title: "Selamat datang di ruang siswa",
        content: (
          <p>
            Di halaman ini kamu bisa mulai dari profil, melihat nilai akademik,
            memproses rekomendasi, sampai mengikuti roadmap belajar.
          </p>
        ),
        selector: "#student-tour-hero",
        side: "bottom" as const,
        showControls: true,
        pointerPadding: 12,
        pointerRadius: 28,
      },
      {
        icon: <Icon name="profile" className="h-5 w-5" />,
        title: "Lengkapi profil siswa",
        content: (
          <p>
            Isi minat, bakat, hobi, pengalaman, dan prestasi. Data ini membantu
            sistem memberi rekomendasi yang lebih sesuai dengan dirimu.
          </p>
        ),
        selector: "#student-tour-profile-action",
        side: "top" as const,
        showControls: true,
        pointerPadding: 10,
        pointerRadius: 18,
      },
      {
        icon: <Icon name="chart" className="h-5 w-5" />,
        title: "Cek ringkasan akademik",
        content: (
          <p>
            Nilai mentah yang diimport sekolah akan disiapkan menjadi kategori
            akademik saat kamu membuka dashboard.
          </p>
        ),
        selector: "#student-tour-academic",
        side: "top" as const,
        showControls: true,
        pointerPadding: 12,
        pointerRadius: 24,
      },
      {
        icon: <Icon name="sparkles" className="h-5 w-5" />,
        title: "Lihat hasil rekomendasi",
        content: (
          <p>
            Setelah profil siap, buka rekomendasi untuk melihat pilihan jurusan,
            karier, atau jalur belajar yang cocok berdasarkan perhitungan sistem.
          </p>
        ),
        selector: "#student-tour-recommendation-action",
        side: "top" as const,
        showControls: true,
        pointerPadding: 10,
        pointerRadius: 18,
      },
      {
        icon: <Icon name="roadmap" className="h-5 w-5" />,
        title: "Ikuti roadmap belajar",
        content: (
          <p>
            Gunakan roadmap sebagai langkah lanjutan supaya proses belajarmu
            lebih terarah setelah memilih rekomendasi.
          </p>
        ),
        selector: "#student-tour-roadmap-action",
        side: "top" as const,
        showControls: true,
        pointerPadding: 10,
        pointerRadius: 18,
      },
    ],
  },
];

type StudentOnbordaProviderProps = {
  children: ReactNode;
  autoStart?: boolean;
  studentKey?: string | number | null;
};

export function StudentOnbordaProvider({
  children,
  autoStart = false,
  studentKey,
}: StudentOnbordaProviderProps) {
  return (
    <OnbordaProvider>
      <Onborda
        steps={studentSteps}
        showOnborda
        shadowRgb="15,23,42"
        shadowOpacity="0.72"
        cardComponent={StudentOnbordaCard}
        cardTransition={{ duration: 0.22, type: "tween" }}
      >
        {children}
        <StudentOnbordaAutoStart autoStart={autoStart} studentKey={studentKey} />
      </Onborda>
    </OnbordaProvider>
  );
}
