"use client";

import { useEffect, useState } from "react";
import {
  getSiswaMe,
  normalizeStudentAchievements,
  toStudentProfile,
  type SiswaMeResponse,
} from "../../../features/siswa/api";
import type {
  StudentAchievement,
  StudentProfileForm,
} from "../../../features/siswa/types";

const emptyProfile: StudentProfileForm = {
  name: "",
  nisn: "",
  school: "",
  className: "",
  major: "",
  academicScores: {},
  interests: [],
  hobbies: [],
  talents: [],
  experiences: [],
  achievements: "",
  goal: "kuliah",
  learningPreference: "",
  constraints: "",
};

export function useStudentData() {
  const [profile, setProfile] = useState<StudentProfileForm>(emptyProfile);
  const [studentData, setStudentData] = useState<SiswaMeResponse | null>(null);
  const [prestasiRows, setPrestasiRows] = useState<StudentAchievement[]>([]);
  const [loadingProfile, setLoadingProfile] = useState(true);
  const [error, setError] = useState("");

  async function loadStudent() {
    setLoadingProfile(true);
    setError("");

    try {
      const data = await getSiswaMe();
      setStudentData(data);
      setProfile(toStudentProfile(data));
      setPrestasiRows(normalizeStudentAchievements(data));
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Gagal mengambil data siswa.",
      );
    } finally {
      setLoadingProfile(false);
    }
  }

  useEffect(() => {
    loadStudent();
  }, []);

  function updateProfile(patch: Partial<StudentProfileForm>) {
    setProfile((current) => ({ ...current, ...patch }));
  }

  function markPasswordChanged() {
    setStudentData((current) =>
      current ? { ...current, must_change_password: false } : current,
    );
  }

  return {
    profile,
    setProfile,
    studentData,
    mustChangePassword: Boolean(studentData?.must_change_password),
    prestasiRows,
    loadingProfile,
    error,
    setError,
    updateProfile,
    markPasswordChanged,
    reloadStudent: loadStudent,
  };
}
