import { apiFetch } from "../../lib/axios";

export type AdminDashboardResponse = {
  stats: { schools: number; pendingSchools: number; teachers: number; students: number };
  activities: Array<{ title: string; text: string; tone: string }>;
};

export type VerificationRow = {
  id: number;
  school: string;
  level: string;
  city: string;
  status: string;
  address: string;
  phone: string;
};

export function getAdminDashboard() {
  return apiFetch<AdminDashboardResponse>("/admin/dashboard");
}

export function getSchoolVerifications() {
  return apiFetch<VerificationRow[]>("/admin/verifikasi");
}

export function approveSchool(id: number) {
  return apiFetch<{ message: string }>(`/admin/verifikasi/${id}`, { method: "PUT" });
}
