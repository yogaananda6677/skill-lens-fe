import { apiFetch } from "../../lib/axios";
import {
  ACADEMIC_CATEGORIES,
  type AcademicCategory,
  type CategoryScores,
  type GeneratedAccount,
  type GradeSummary,
  type GuidanceCase,
  type ImportDatabaseStats,
  type ImportPreview,
  type SchoolRecord,
  type SemesterGrade,
  type StudentRecord,
  type SubjectMapping,
} from "./types";

const delay = (ms = 260) => new Promise((resolve) => setTimeout(resolve, ms));

const DEFAULT_SEMESTER_WEIGHTS: Record<number, number> = {
  1: 0.1,
  2: 0.15,
  3: 0.2,
  4: 0.25,
  5: 0.3,
};

const schools: SchoolRecord[] = [
  {
    id: "1",
    backendId: 1,
    name: "SMK Negeri 2 Jakarta",
    level: "SMK",
    city: "Jakarta Pusat",
    accreditation: "A",
    address: "Jl. Batu No. 3, Gambir",
    totalStudents: 936,
  },
  {
    id: "2",
    backendId: 2,
    name: "SMA Negeri 8 Bandung",
    level: "SMA",
    city: "Bandung",
    accreditation: "A",
    address: "Jl. Solontongan No. 3",
    totalStudents: 1120,
  },
  {
    id: "3",
    backendId: 3,
    name: "SMK Kreatif Nusantara Surabaya",
    level: "SMK",
    city: "Surabaya",
    accreditation: "A",
    address: "Jl. Ketintang Madya No. 12",
    totalStudents: 784,
  },
  {
    id: "4",
    backendId: 4,
    name: "SMA Harapan Bangsa Yogyakarta",
    level: "SMA",
    city: "Yogyakarta",
    accreditation: "B",
    address: "Jl. Kaliurang Km. 6",
    totalStudents: 642,
  },
];

const rawStudents = [
  ["0012457788", "Alya Putri Rahmadani", "P", "XII RPL 1", 88, 91, 94, 86],
  ["0012457791", "Fikri Ramadhan", "L", "XII RPL 1", 82, 80, 89, 84],
  ["0012457794", "Nabila Zahra", "P", "XII DKV 2", 91, 88, 79, 94],
  ["0012457798", "Raka Pradipta", "L", "XII TKJ 1", 77, 81, 83, 80],
  ["0012457802", "Salsa Kirana", "P", "XII AKL 1", 86, 84, 88, 85],
  ["0012457810", "Dimas Arya", "L", "XII BDP 1", 74, 78, 76, 82],
  ["0012457814", "Tania Safitri", "P", "XII RPL 2", 89, 93, 90, 87],
  ["0012457819", "Bima Alfarizi", "L", "XII TKJ 2", 80, 76, 85, 79],
  ["0012457822", "Maya Sekar", "P", "XII DKV 1", 94, 86, 82, 95],
  ["0012457827", "Reza Maulana", "L", "XII MM 1", 81, 87, 78, 89],
  ["0012457830", "Citra Nandini", "P", "XII IPA 1", 92, 89, 96, 88],
  ["0012457833", "Hanif Akbar", "L", "XII IPS 2", 78, 83, 75, 84],
] as const;

function emptyScores(): CategoryScores {
  return ACADEMIC_CATEGORIES.reduce((acc, category) => {
    acc[category] = 0;
    return acc;
  }, {} as CategoryScores);
}

function roundScore(value: number): number {
  return Math.round(value * 100) / 100;
}

function averageNonZero(scores: Partial<Record<AcademicCategory, number>>): number {
  const values = ACADEMIC_CATEGORIES.map((category) => scores[category] ?? 0).filter((value) => value > 0);
  if (!values.length) return 0;
  return Math.round(values.reduce((total, value) => total + value, 0) / values.length);
}

function labelAverage(score: number): StudentRecord["fuzzyAcademicLabel"] {
  if (score >= 86) return "Tinggi";
  if (score >= 78) return "Sedang";
  return "Perlu dukungan";
}

function buildMockCategoryScores(base: readonly [string, string, string, string, number, number, number, number], movement = 0): CategoryScores {
  const [, , , , bahasa, softskill, numerik, kreativitas] = base;
  const scores = emptyScores();
  scores.numerik = Math.max(70, Math.min(100, numerik + movement));
  scores.bahasa = Math.max(70, Math.min(100, bahasa + movement));
  scores.sains = Math.max(70, Math.min(100, Math.round((numerik + bahasa) / 2) + movement));
  scores.sosial = Math.max(70, Math.min(100, softskill + movement - 1));
  scores.teknologi = Math.max(70, Math.min(100, numerik + movement + 2));
  scores.agama = Math.max(70, Math.min(100, 82 + movement));
  scores.kreativitas = Math.max(70, Math.min(100, kreativitas + movement));
  scores.softskill = Math.max(70, Math.min(100, softskill + movement));
  return scores;
}

function buildSemesters(base: readonly [string, string, string, string, number, number, number, number]): SemesterGrade[] {
  return [1, 2, 3, 4, 5].map((semester) => {
    const movement = semester - 3;
    const categories = buildMockCategoryScores(base, movement);
    const average = averageNonZero(categories);

    return {
      semester: semester as 1 | 2 | 3 | 4 | 5,
      categories,
      bahasaIndonesia: categories.bahasa,
      bahasaInggris: categories.bahasa,
      matematika: categories.numerik,
      dll: categories.softskill,
      average,
    };
  });
}

function buildStudents(schoolId: string, major: string): StudentRecord[] {
  return rawStudents.map((row, index) => {
    const semesterGrades = buildSemesters(row);
    const academicCategories = emptyScores();

    ACADEMIC_CATEGORIES.forEach((category) => {
      let numerator = 0;
      let denominator = 0;
      semesterGrades.forEach((semester) => {
        const weight = DEFAULT_SEMESTER_WEIGHTS[semester.semester] ?? 1;
        numerator += semester.categories[category] * weight;
        denominator += weight;
      });
      academicCategories[category] = denominator ? roundScore(numerator / denominator) : 0;
    });

    const academicAverage = averageNonZero(academicCategories);
    const topsisReadiness = Math.min(98, Math.max(62, Math.round(academicAverage * 0.68 + (index % 5) * 4 + 18)));
    const status = index === 3 || index === 11 ? "Perlu Review" : "Valid";

    return {
      id: `stu-${index + 1}`,
      no: index + 1,
      nisn: row[0],
      name: row[1],
      gender: row[2] as "L" | "P",
      className: row[3],
      major,
      schoolId,
      semesterGrades,
      academicCategories,
      academicAverage,
      fuzzyAcademicLabel: labelAverage(academicAverage),
      topsisReadiness,
      interestSummary: index % 3 === 0 ? "Teknologi, data, analisis" : index % 3 === 1 ? "Bisnis, komunikasi, layanan" : "Desain, kreatif, visual",
      importStatus: status,
      accountGenerated: false,
    };
  });
}

type ImportExcelPayload = {
  file: File;
  dryRun?: boolean;
  tahunAjaran: string;
  jenisSekolah: "SMA" | "SMK" | string;
  jurusan: string;
  tujuanKarir: string;
  sekolahId?: string | number;
  jurusanId?: string | number;
  topN?: number;
  semesterWeights?: Record<number, number>;
};

type BackendStudent = {
  nisn: string;
  nama: string;
  jk?: string;
  kelas?: string;
  jurusan?: string;
  id_siswa?: number;
  akun?: {
    username: string;
    password_default: string;
    akun_baru: boolean;
    perlu_ganti_password: boolean;
  };
  nilai_akademik?: Partial<Record<AcademicCategory, number>>;
  rincian_per_kategori?: Partial<Record<AcademicCategory, Array<{ semester: number; bobot: number; rata_rata: number; jumlah_mapel: number; mapel: string[] }>>>;
  rincian_per_semester?: Record<string, Partial<Record<AcademicCategory, { rata_rata: number | null; jumlah_mapel: number; mapel: string[] }>>>;
};

type BackendImportResponse = {
  status: "success" | string;
  message: string;
  meta?: {
    mode?: "dry_run" | "import_and_generate";
    jumlah_siswa?: number;
    jumlah_nilai?: number;
    semester_terbaca?: number[];
    jumlah_mapel_terdeteksi?: number;
    jumlah_mapel_fallback?: number;
    kategori_akademik?: AcademicCategory[];
    urutan_penyimpanan?: string[];
    database?: ImportDatabaseStats;
  };
  bobot_semester?: Record<number, number>;
  mapping_mapel?: SubjectMapping[];
  warnings?: string[];
  data?: BackendStudent[];
};

function toFormData(payload: ImportExcelPayload): FormData {
  const formData = new FormData();
  formData.append("file", payload.file);
  formData.append("dryRun", payload.dryRun ? "true" : "false");
  formData.append("tahunAjaran", payload.tahunAjaran);
  formData.append("jenisSekolah", payload.jenisSekolah);
  formData.append("jurusan", payload.jurusan);
  formData.append("tujuanKarir", payload.tujuanKarir);
  formData.append("topN", String(payload.topN ?? 3));
  formData.append("semesterWeights", JSON.stringify(payload.semesterWeights ?? DEFAULT_SEMESTER_WEIGHTS));

  if (payload.sekolahId) formData.append("sekolahId", String(payload.sekolahId));
  if (payload.jurusanId) formData.append("jurusanId", String(payload.jurusanId));

  return formData;
}

function normalizeAcademicScores(raw?: Partial<Record<AcademicCategory, number>>): CategoryScores {
  const scores = emptyScores();
  ACADEMIC_CATEGORIES.forEach((category) => {
    const value = Number(raw?.[category] ?? 0);
    scores[category] = Number.isFinite(value) ? roundScore(value) : 0;
  });
  return scores;
}

function normalizeBackendStudent(student: BackendStudent, index: number, schoolId: string, major: string): StudentRecord {
  const academicCategories = normalizeAcademicScores(student.nilai_akademik);
  const semesterGrades = [1, 2, 3, 4, 5].map((semester) => {
    const detail = student.rincian_per_semester?.[String(semester)] ?? student.rincian_per_semester?.[semester as unknown as string];
    const categories = emptyScores();

    ACADEMIC_CATEGORIES.forEach((category) => {
      const value = detail?.[category]?.rata_rata;
      categories[category] = value === null || value === undefined ? 0 : roundScore(Number(value));
    });

    const fallbackCategories = averageNonZero(categories) ? categories : academicCategories;
    const average = averageNonZero(fallbackCategories);

    return {
      semester: semester as 1 | 2 | 3 | 4 | 5,
      categories: fallbackCategories,
      bahasaIndonesia: fallbackCategories.bahasa,
      bahasaInggris: fallbackCategories.bahasa,
      matematika: fallbackCategories.numerik,
      dll: fallbackCategories.softskill,
      average,
    };
  });

  const academicAverage = averageNonZero(academicCategories);
  const validCategoryCount = ACADEMIC_CATEGORIES.filter((category) => academicCategories[category] > 0).length;
  const status: StudentRecord["importStatus"] = validCategoryCount >= 4 ? "Valid" : "Perlu Review";

  return {
    id: student.id_siswa ? `db-${student.id_siswa}` : `import-${student.nisn || index + 1}`,
    backendId: student.id_siswa,
    no: index + 1,
    nisn: student.nisn,
    name: student.nama,
    gender: student.jk === "P" ? "P" : "L",
    className: student.kelas || "-",
    major: student.jurusan || major,
    schoolId,
    semesterGrades,
    academicCategories,
    categoryDetails: student.rincian_per_kategori,
    academicAverage,
    fuzzyAcademicLabel: labelAverage(academicAverage),
    topsisReadiness: Math.min(99, Math.max(50, Math.round(academicAverage * 0.82 + validCategoryCount * 2))),
    interestSummary: "Menunggu kelengkapan data minat, bakat, hobi, prestasi, dan tujuan siswa.",
    importStatus: status,
    accountGenerated: Boolean(student.akun?.username),
    backendAccount: student.akun
      ? {
          username: student.akun.username,
          passwordDefault: student.akun.password_default,
          isNew: student.akun.akun_baru,
          mustChangePassword: student.akun.perlu_ganti_password,
        }
      : undefined,
  };
}

function normalizeImportResponse(response: BackendImportResponse, payload: ImportExcelPayload): ImportPreview {
  const students = (response.data ?? []).map((student, index) => normalizeBackendStudent(student, index, String(payload.sekolahId ?? ""), payload.jurusan));
  const warnings = response.warnings ?? [];
  const mappedSubjects = response.mapping_mapel ?? [];
  const semesterNumbers = response.meta?.semester_terbaca?.length ? response.meta.semester_terbaca : [1, 2, 3, 4, 5];

  return {
    sourceFile: payload.file.name,
    templateName: "Template Nilai SkillLens - Semester 1 sampai Semester 5",
    message: response.message,
    importMode: response.meta?.mode ?? (payload.dryRun ? "dry_run" : "import_and_generate"),
    rowsDetected: response.meta?.jumlah_siswa ?? students.length,
    validRows: students.filter((student) => student.importStatus === "Valid").length,
    reviewRows: students.filter((student) => student.importStatus === "Perlu Review").length,
    sheetsDetected: semesterNumbers.map((semester) => `Semester ${semester}`),
    mappedColumns: ["No", "NISN", "Nama", "JK", "Kelas", ...mappedSubjects.map((mapping) => mapping.mapel)].filter(Boolean),
    students,
    warnings,
    semesterWeights: response.bobot_semester ?? DEFAULT_SEMESTER_WEIGHTS,
    mappingMapel: mappedSubjects,
    backendMeta: {
      jumlahSiswa: response.meta?.jumlah_siswa,
      jumlahNilai: response.meta?.jumlah_nilai,
      jumlahMapelTerdeteksi: response.meta?.jumlah_mapel_terdeteksi,
      jumlahMapelFallback: response.meta?.jumlah_mapel_fallback,
      urutanPenyimpanan: response.meta?.urutan_penyimpanan,
      database: response.meta?.database,
    },
  };
}

export async function importExcelGrades(payload: ImportExcelPayload): Promise<ImportPreview> {
  const response = await apiFetch<BackendImportResponse>("/nilai-siswa/import-excel", {
    method: "POST",
    body: toFormData(payload),
  });

  return normalizeImportResponse(response, payload);
}

export function extractAccountsFromImportedStudents(students: StudentRecord[]): GeneratedAccount[] {
  return students
    .filter((student) => student.backendAccount?.username)
    .map((student) => ({
      studentId: student.id,
      name: student.name,
      username: student.backendAccount!.username,
      password: student.backendAccount!.passwordDefault,
      role: "siswa" as const,
      status: student.importStatus === "Valid" ? "Siap dikirim" : "Draft",
    }));
}

export async function getSchoolsFromDatabase(): Promise<SchoolRecord[]> {
  return apiFetch<SchoolRecord[]>("/sekolah");
}

export const getSchoolsFromMockDatabase = getSchoolsFromDatabase;

export async function previewExcelImport({
  fileName,
  schoolId,
  major,
}: {
  fileName: string;
  schoolId: string;
  major: string;
}): Promise<ImportPreview> {
  throw new Error(`Preview dummy sudah dinonaktifkan. Pilih file Excel asli (${fileName || "tanpa nama"}) lalu klik Cek file / dry-run agar data dibaca dari backend untuk sekolah ${schoolId} dan jurusan ${major}.`);
}

export async function generateStudentAccounts(students: StudentRecord[]): Promise<GeneratedAccount[]> {
  const accountsFromBackend = extractAccountsFromImportedStudents(students);
  if (!accountsFromBackend.length) {
    throw new Error("Akun siswa belum tersedia. Jalankan Import ke database agar backend membuat akun real untuk siswa.");
  }
  return accountsFromBackend;
}

export async function getGuidanceCases(): Promise<GuidanceCase[]> {
  return apiFetch<GuidanceCase[]>("/guru/guidance-cases");
}

export function summarizeGrades(students: StudentRecord[]): GradeSummary {
  const totalStudents = students.length;
  const totalAverage = totalStudents
    ? Math.round(students.reduce((sum, student) => sum + (student.academicAverage || 0), 0) / totalStudents)
    : 0;

  return {
    totalStudents,
    importedSheets: totalStudents ? 5 : 0,
    averageScore: totalAverage,
    reviewNeeded: students.filter((student) => student.importStatus === "Perlu Review").length,
    readyForTopsis: students.filter((student) => student.topsisReadiness >= 75).length,
  };
}
