"use client";

import type { ChangeEvent, ReactNode } from "react";
import { useEffect, useMemo, useState } from "react";
import { DashboardShell, type DashboardNavItem } from "../../components/layout/DashboardShell";
import {
  extractAccountsFromImportedStudents,
  generateStudentAccounts,
  getGuidanceCases,
  getSchoolsFromMockDatabase,
  importExcelGrades,
  previewExcelImport,
  summarizeGrades,
} from "../../features/guru/api";
import { ACADEMIC_CATEGORIES, ACADEMIC_CATEGORY_LABELS } from "../../features/guru/types";
import type { GeneratedAccount, GuidanceCase, ImportPreview, SchoolRecord, StudentRecord } from "../../features/guru/types";

const majorOptions = [
  "Rekayasa Perangkat Lunak",
  "Teknik Komputer dan Jaringan",
  "Desain Komunikasi Visual",
  "Akuntansi dan Keuangan Lembaga",
  "Bisnis Digital",
  "IPA",
  "IPS",
];

const majorDatabaseIdByName: Record<string, string> = {
  "Rekayasa Perangkat Lunak": "1",
  "Teknik Komputer dan Jaringan": "2",
  "Desain Komunikasi Visual": "3",
  "Akuntansi dan Keuangan Lembaga": "4",
  "Bisnis Digital": "5",
  IPA: "6",
  IPS: "7",
};

const defaultSemesterWeights: Record<number, number> = {
  1: 0.1,
  2: 0.15,
  3: 0.2,
  4: 0.25,
  5: 0.3,
};

const sections = [
  { key: "overview", label: "Ringkasan", description: "Kondisi sekolah", icon: "▦" },
  { key: "import", label: "Import Nilai", description: "Template Excel", icon: "⇧" },
  { key: "nilai", label: "Data Akademik", description: "Semester 1-5", icon: "▤" },
  { key: "bimbingan", label: "Bimbingan", description: "Agenda siswa", icon: "◉", badge: "6" },
  { key: "akun", label: "Akun Siswa", description: "Akses login", icon: "◎" },
  { key: "metode", label: "Metode SPK", description: "Fuzzy + TOPSIS", icon: "◇" },
] as const satisfies readonly DashboardNavItem[];

type SectionKey = (typeof sections)[number]["key"];

type MetricCardProps = {
  label: string;
  value: string;
  detail: string;
  icon: string;
  tone?: "indigo" | "emerald" | "amber" | "cyan";
};

function ProgressBar({ value }: { value: number }) {
  return (
    <div className="h-2 overflow-hidden rounded-full bg-slate-100">
      <div className="h-full rounded-full bg-gradient-to-r from-[#0f2a5f] to-cyan-300" style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  );
}

function MetricCard({ label, value, detail, icon, tone = "indigo" }: MetricCardProps) {
  const tones = {
    indigo: "from-[#0f2a5f] to-[#1d4ed8]",
    emerald: "from-emerald-500 to-teal-300",
    amber: "from-amber-400 to-orange-300",
    cyan: "from-cyan-400 to-sky-400",
  } as const;

  return (
    <article className="rounded-[1.4rem] border border-slate-100 bg-white p-5 shadow-lg shadow-slate-900/5 transition hover:-translate-y-0.5 hover:shadow-xl">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.18em] text-slate-400">{label}</p>
          <p className="mt-3 text-3xl font-black tracking-[-0.04em] text-slate-950">{value}</p>
        </div>
        <div className={`grid h-12 w-12 place-items-center rounded-2xl bg-gradient-to-br ${tones[tone]} text-lg font-black text-white shadow-lg shadow-slate-900/10`}>
          {icon}
        </div>
      </div>
      <p className="mt-3 text-sm font-semibold leading-6 text-slate-500">{detail}</p>
    </article>
  );
}

function StatusBadge({ status }: { status: string }) {
  const style =
    status === "Valid" || status === "Selesai" || status === "Siap dikirim"
      ? "bg-emerald-50 text-emerald-700 ring-emerald-100"
      : status === "Perlu Review" || status === "Menunggu" || status === "Draft"
        ? "bg-amber-50 text-amber-700 ring-amber-100"
        : "bg-indigo-50 text-indigo-700 ring-indigo-100";

  return <span className={`inline-flex rounded-full px-3 py-1 text-xs font-black ring-1 ${style}`}>{status}</span>;
}

function Panel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <section className={`rounded-[1.75rem] border border-slate-100 bg-white p-5 shadow-lg shadow-slate-900/5 sm:p-6 ${className}`}>{children}</section>;
}

function ChartPanel() {
  const values = [38, 45, 52, 48, 61, 58, 68, 73, 70, 79, 82, 90];
  const width = 720;
  const height = 260;
  const stepX = width / (values.length - 1);
  const coords = values.map((value, index) => {
    const x = index * stepX;
    const y = height - (value / 100) * (height - 36) - 18;
    return [x, y] as const;
  });
  const linePath = coords.map(([x, y], index) => `${index === 0 ? "M" : "L"}${x},${y}`).join(" ");
  const areaPath = `${linePath} L${width},${height} L0,${height} Z`;

  return (
    <Panel className="overflow-hidden">
      <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Tren kesiapan siswa</p>
          <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Kelengkapan profil dan validitas nilai</h2>
          <p className="mt-2 max-w-2xl text-sm font-semibold leading-7 text-slate-500">Grafik ini membantu guru melihat apakah data akademik dan data bimbingan sudah siap diproses sebagai bahan keputusan.</p>
        </div>
        <span className="w-fit rounded-full bg-emerald-50 px-4 py-2 text-xs font-black text-emerald-700">Meningkat 18%</span>
      </div>
      <div className="mt-7 overflow-hidden rounded-[1.35rem] bg-gradient-to-b from-slate-50 to-white p-4">
        <svg viewBox={`0 0 ${width} ${height}`} className="h-[250px] w-full" role="img" aria-label="Grafik tren kesiapan siswa">
          <defs>
            <linearGradient id="teacherArea" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#0f2a5f" stopOpacity="0.28" />
              <stop offset="100%" stopColor="#0f2a5f" stopOpacity="0.02" />
            </linearGradient>
          </defs>
          {[0, 1, 2, 3].map((line) => (
            <line key={line} x1="0" x2={width} y1={60 + line * 48} y2={60 + line * 48} stroke="#e2e8f0" strokeWidth="1" />
          ))}
          <path d={areaPath} fill="url(#teacherArea)" />
          <path d={linePath} fill="none" stroke="#0f2a5f" strokeLinecap="round" strokeLinejoin="round" strokeWidth="5" />
          {coords.map(([x, y], index) => (
            <circle key={index} cx={x} cy={y} r="6" fill="white" stroke="#0f2a5f" strokeWidth="4" />
          ))}
        </svg>
      </div>
    </Panel>
  );
}

function DistributionPanel() {
  const rows = [
    ["Teknologi dan data", 42, "#0f2a5f"],
    ["Bisnis dan keuangan", 27, "#22c55e"],
    ["Desain dan komunikasi", 21, "#f59e0b"],
    ["Kesehatan dan layanan", 10, "#06b6d4"],
  ] as const;

  return (
    <Panel>
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Distribusi minat</p>
          <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Arah dominan siswa</h2>
        </div>
        <span className="rounded-full bg-slate-950 px-3 py-1 text-xs font-black text-white">XII</span>
      </div>
      <div className="mt-6 space-y-5">
        {rows.map(([label, value, color]) => (
          <div key={label}>
            <div className="mb-2 flex items-center justify-between gap-4 text-sm font-black text-slate-600">
              <span>{label}</span>
              <span>{value}%</span>
            </div>
            <div className="h-3 overflow-hidden rounded-full bg-slate-100">
              <div className="h-full rounded-full" style={{ width: `${value}%`, backgroundColor: color }} />
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );
}


function GradeTable({ students, semester }: { students: StudentRecord[]; semester: 1 | 2 | 3 | 4 | 5 }) {
  return (
    <div className="overflow-hidden rounded-[1.35rem] border border-slate-100 bg-white">
      <div className="overflow-x-auto">
        <table className="w-full min-w-[1320px] text-left text-sm">
          <thead className="bg-slate-50 text-xs font-black uppercase tracking-[0.16em] text-slate-400">
            <tr>
              <th className="px-4 py-4">No</th>
              <th className="px-4 py-4">NISN</th>
              <th className="px-4 py-4">Nama siswa</th>
              <th className="px-4 py-4">Kelas</th>
              {ACADEMIC_CATEGORIES.map((category) => (
                <th key={category} className="px-4 py-4">{ACADEMIC_CATEGORY_LABELS[category]}</th>
              ))}
              <th className="px-4 py-4">Rata-rata</th>
              <th className="px-4 py-4">Status data</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {students.map((student) => {
              const grade = student.semesterGrades.find((item) => item.semester === semester) ?? student.semesterGrades[0];
              const semesterScores = grade?.categories ?? student.academicCategories;

              return (
                <tr key={student.id} className="transition hover:bg-indigo-50/35">
                  <td className="px-4 py-4 font-bold text-slate-500">{student.no}</td>
                  <td className="px-4 py-4 font-black text-slate-800">{student.nisn}</td>
                  <td className="px-4 py-4 font-black text-slate-950">{student.name}</td>
                  <td className="px-4 py-4 font-bold text-slate-600">{student.className}</td>
                  {ACADEMIC_CATEGORIES.map((category) => {
                    const value = Math.round(semesterScores[category] ?? 0);
                    return (
                      <td key={category} className="px-4 py-4">
                        <div className="flex items-center gap-3">
                          <span className="w-9 font-black text-slate-800">{value || "-"}</span>
                          <div className="w-20"><ProgressBar value={value} /></div>
                        </div>
                      </td>
                    );
                  })}
                  <td className="px-4 py-4">
                    <div className="flex items-center gap-3">
                      <span className="w-10 font-black text-[#0f2a5f]">{grade?.average ?? student.academicAverage}</span>
                      <div className="w-24"><ProgressBar value={grade?.average ?? student.academicAverage} /></div>
                    </div>
                  </td>
                  <td className="px-4 py-4"><StatusBadge status={student.importStatus} /></td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function GuidanceList({ cases, activeId, onSelect }: { cases: GuidanceCase[]; activeId: string; onSelect: (id: string) => void }) {
  return (
    <div className="space-y-3">
      {cases.map((item) => (
        <button
          key={item.id}
          type="button"
          onClick={() => onSelect(item.id)}
          className={`w-full rounded-[1.35rem] border p-4 text-left transition hover:-translate-y-0.5 ${
            activeId === item.id ? "border-[#0f2a5f] bg-[#eef5ff] shadow-lg shadow-blue-950/10" : "border-slate-100 bg-white hover:border-blue-200"
          }`}
        >
          <div className="flex items-start justify-between gap-4">
            <div>
              <p className="font-black text-slate-950">{item.studentName}</p>
              <p className="mt-1 text-xs font-bold text-slate-500">{item.className} · {item.requestedAt}</p>
            </div>
            <StatusBadge status={item.status} />
          </div>
          <p className="mt-3 text-sm font-bold leading-6 text-slate-600">{item.topic}</p>
          <div className="mt-4"><ProgressBar value={item.progress} /></div>
        </button>
      ))}
    </div>
  );
}

export default function GuruPage() {
  const [activeSection, setActiveSection] = useState<SectionKey>("overview");
  const [schools, setSchools] = useState<SchoolRecord[]>([]);
  const [selectedSchoolId, setSelectedSchoolId] = useState("1");
  const [major, setMajor] = useState(majorOptions[0]);
  const [customMajor, setCustomMajor] = useState("");
  const [fileName, setFileName] = useState("Belum ada file dipilih");
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [schoolDatabaseId, setSchoolDatabaseId] = useState("1");
  const [jurusanDatabaseId, setJurusanDatabaseId] = useState("1");
  const [tahunAjaran, setTahunAjaran] = useState("2025/2026");
  const [jenisSekolah, setJenisSekolah] = useState<"SMA" | "SMK">("SMK");
  const [tujuanKarir, setTujuanKarir] = useState("kuliah");
  const [preview, setPreview] = useState<ImportPreview | null>(null);
  const [accounts, setAccounts] = useState<GeneratedAccount[]>([]);
  const [guidanceCases, setGuidanceCases] = useState<GuidanceCase[]>([]);
  const [selectedGuidanceId, setSelectedGuidanceId] = useState("g-001");
  const [guidanceFilter, setGuidanceFilter] = useState("Semua");
  const [studentSearch, setStudentSearch] = useState("");
  const [selectedSemester, setSelectedSemester] = useState<1 | 2 | 3 | 4 | 5>(5);
  const [isLoading, setIsLoading] = useState(false);
  const [isPersisting, setIsPersisting] = useState(false);
  const [apiMessage, setApiMessage] = useState("");
  const [apiError, setApiError] = useState("");
  const [note, setNote] = useState("Diskusikan alasan tiga peringkat teratas, cek kesiapan keluarga, lalu tetapkan satu langkah belajar minggu ini.");

  const selectedMajor = customMajor.trim() || major;

  useEffect(() => {
    async function init() {
      const schoolData = await getSchoolsFromMockDatabase();
      setSchools(schoolData);
      const defaultSchoolId = schoolData[0]?.id ?? selectedSchoolId;
      setSelectedSchoolId(defaultSchoolId);
      const [importPreview, guidance] = await Promise.all([
        previewExcelImport({ fileName: "Template Nilai.xlsx", schoolId: defaultSchoolId, major: selectedMajor }),
        getGuidanceCases(),
      ]);

      setSchoolDatabaseId(String(schoolData[0]?.backendId ?? schoolData[0]?.id ?? 1));
      setJenisSekolah(schoolData[0]?.level ?? "SMK");
      setJurusanDatabaseId(majorDatabaseIdByName[majorOptions[0]] ?? "1");
      setPreview(importPreview);
      setGuidanceCases(guidance);
      setSelectedGuidanceId(guidance[0]?.id ?? "");
    }

    init();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const selectedSchool = useMemo(() => schools.find((school) => school.id === selectedSchoolId), [schools, selectedSchoolId]);
  const students = preview?.students ?? [];
  const summary = useMemo(() => summarizeGrades(students), [students]);

  const visibleStudents = useMemo(() => {
    const keyword = studentSearch.toLowerCase();
    return students.filter((student) => [student.name, student.nisn, student.className, student.major].join(" ").toLowerCase().includes(keyword));
  }, [studentSearch, students]);

  const filteredGuidance = useMemo(() => {
    return guidanceCases.filter((item) => {
      const matchesStatus = guidanceFilter === "Semua" || item.status === guidanceFilter;
      const matchesSearch = [item.studentName, item.className, item.topic, item.recommendation].join(" ").toLowerCase().includes(studentSearch.toLowerCase());
      return matchesStatus && matchesSearch;
    });
  }, [guidanceCases, guidanceFilter, studentSearch]);

  const selectedGuidance = guidanceCases.find((item) => item.id === selectedGuidanceId) ?? guidanceCases[0];

  const buildImportRequest = (dryRun: boolean) => {
    if (!selectedFile) {
      throw new Error("Pilih file Excel terlebih dahulu sebelum menjalankan import.");
    }

    return {
      file: selectedFile,
      dryRun,
      tahunAjaran,
      jenisSekolah,
      jurusan: selectedMajor,
      tujuanKarir,
      sekolahId: schoolDatabaseId || selectedSchool?.backendId || selectedSchool?.id,
      jurusanId: jurusanDatabaseId || majorDatabaseIdByName[major] || undefined,
      topN: 3,
      semesterWeights: defaultSemesterWeights,
    };
  };

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] ?? null;
    setSelectedFile(file);
    setFileName(file?.name ?? "Template Nilai.xlsx");
    setAccounts([]);
    setApiError("");
    setApiMessage(file ? "File siap diperiksa. Jalankan dry-run untuk membaca struktur Excel sebelum disimpan." : "");
  };

  const handlePreview = async () => {
    setIsLoading(true);
    setApiError("");
    setApiMessage("");

    try {
      if (!selectedFile) {
        const result = await previewExcelImport({ fileName, schoolId: selectedSchoolId, major: selectedMajor });
        setPreview(result);
        setApiMessage("Preview contoh ditampilkan. Pilih file Excel untuk membaca data asli melalui backend.");
      } else {
        const result = await importExcelGrades(buildImportRequest(true));
        setPreview(result);
        setApiMessage(result.message ?? "Dry-run berhasil. Data Excel sudah terbaca, tetapi belum disimpan ke database.");
      }

      setAccounts([]);
      setActiveSection("import");
    } catch (error) {
      setApiError(error instanceof Error ? error.message : "Gagal memeriksa file Excel.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleImportToDatabase = async () => {
    setIsPersisting(true);
    setApiError("");
    setApiMessage("");

    try {
      const result = await importExcelGrades(buildImportRequest(false));
      setPreview(result);
      const generated = extractAccountsFromImportedStudents(result.students);
      setAccounts(generated);
      setApiMessage(result.message ?? "Import berhasil. Data siswa, mapel, kurikulum mapel, nilai mentah, dan nilai kategori sudah disimpan di backend.");
      setActiveSection("nilai");
    } catch (error) {
      setApiError(error instanceof Error ? error.message : "Gagal menyimpan import ke database.");
    } finally {
      setIsPersisting(false);
    }
  };

  const handleGenerateAccounts = async () => {
    if (!students.length) return;
    setIsLoading(true);
    const result = await generateStudentAccounts(students);
    setAccounts(result);
    setPreview({
      ...preview!,
      students: students.map((student) => ({ ...student, accountGenerated: true })),
    });
    setActiveSection("akun");
    setIsLoading(false);
  };

  const metrics = [
    { label: "Siswa terdata", value: `${summary.totalStudents}`, detail: "Data siswa dari template nilai.", icon: "👥", tone: "indigo" as const },
    { label: "Data valid", value: `${summary.readyForTopsis}`, detail: "Siap menjadi bahan perhitungan SPK.", icon: "✓", tone: "emerald" as const },
    { label: "Perlu review", value: `${summary.reviewNeeded}`, detail: "Baris yang perlu diperiksa kembali.", icon: "!", tone: "amber" as const },
    { label: "Bimbingan", value: `${guidanceCases.length}`, detail: "Agenda pendampingan aktif.", icon: "◉", tone: "cyan" as const },
  ];

  return (
    <DashboardShell
      activeKey={activeSection}
      navItems={sections}
      onNavigate={(key) => setActiveSection(key as SectionKey)}
      title="Ruang Kerja Bimbingan Karier"
      subtitle="Kelola nilai akademik, data siswa, akun akses, dan pendampingan karier dalam satu tampilan yang terstruktur."
      userName="Budi Santoso"
      userLabel="Guru BK"
      schoolName={selectedSchool?.name ?? "Sekolah aktif"}
      rightSlot={<span className="hidden rounded-full bg-white/15 px-4 py-2 text-xs font-black text-white md:inline-flex">Semester 2025/2026</span>}
    >
      <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
        {metrics.map((item) => (
          <MetricCard key={item.label} {...item} />
        ))}
      </div>

      {activeSection === "overview" && (
        <div className="mt-6 grid gap-6 xl:grid-cols-[1.4fr_0.75fr]">
          <div className="space-y-6">
            <ChartPanel />
            <Panel>
              <div className="flex flex-col justify-between gap-4 md:flex-row md:items-end">
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Prioritas hari ini</p>
                  <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Siswa yang membutuhkan tindak lanjut</h2>
                </div>
                <button type="button" onClick={() => setActiveSection("bimbingan")} className="rounded-full bg-slate-950 px-5 py-3 text-sm font-black text-white transition hover:-translate-y-0.5 hover:bg-[#0f2a5f]">
                  Buka bimbingan
                </button>
              </div>
              <div className="mt-6 grid gap-4 lg:grid-cols-3">
                {guidanceCases.slice(0, 3).map((item) => (
                  <article key={item.id} className="rounded-[1.35rem] bg-slate-50 p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="font-black text-slate-950">{item.studentName}</p>
                        <p className="mt-1 text-xs font-bold text-slate-500">{item.className}</p>
                      </div>
                      <StatusBadge status={item.priority} />
                    </div>
                    <p className="mt-3 text-sm font-semibold leading-6 text-slate-600">{item.topic}</p>
                    <div className="mt-4"><ProgressBar value={item.progress} /></div>
                  </article>
                ))}
              </div>
            </Panel>
          </div>

          <div className="space-y-6">
            <DistributionPanel />
            <Panel>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Konteks sekolah</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">{selectedSchool?.name ?? "Memuat sekolah"}</h2>
              <div className="mt-5 grid gap-3">
                {[
                  ["Kota", selectedSchool?.city ?? "-"],
                  ["Jenjang", selectedSchool?.level ?? "-"],
                  ["Akreditasi", selectedSchool?.accreditation ?? "-"],
                  ["Jumlah siswa", `${selectedSchool?.totalStudents ?? 0} siswa`],
                ].map(([label, value]) => (
                  <div key={label} className="flex items-center justify-between rounded-2xl bg-slate-50 px-4 py-3">
                    <span className="text-sm font-bold text-slate-500">{label}</span>
                    <span className="text-sm font-black text-slate-950">{value}</span>
                  </div>
                ))}
              </div>
              <p className="mt-5 text-sm font-semibold leading-7 text-slate-500">{selectedSchool?.address}</p>
            </Panel>
          </div>
        </div>
      )}

      {activeSection === "import" && (
        <div className="mt-6 grid gap-6 xl:grid-cols-[0.85fr_1.15fr]">
          <Panel>
            <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Import nilai Excel</p>
            <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Unggah data akademik siswa</h2>
            <p className="mt-2 text-sm font-semibold leading-7 text-slate-500">Gunakan template resmi agar kolom dan sheet semester terbaca konsisten saat data diproses.</p>

            <div className="mt-6 space-y-4">
              <label className="block">
                <span className="text-sm font-black text-slate-700">Nama sekolah</span>
                <select
                  value={selectedSchoolId}
                  onChange={(event) => {
                    const nextSchoolId = event.target.value;
                    const nextSchool = schools.find((school) => school.id === nextSchoolId);
                    setSelectedSchoolId(nextSchoolId);
                    setSchoolDatabaseId(String(nextSchool?.backendId ?? ""));
                    setJenisSekolah(nextSchool?.level ?? jenisSekolah);
                  }}
                  className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
                >
                  {schools.map((school) => (
                    <option key={school.id} value={school.id}>{school.name} - {school.city}</option>
                  ))}
                </select>
              </label>

              <div className="grid gap-4 sm:grid-cols-2">
                <label className="block">
                  <span className="text-sm font-black text-slate-700">Jurusan</span>
                  <select
                    value={major}
                    onChange={(event) => {
                      const nextMajor = event.target.value;
                      setMajor(nextMajor);
                      setJurusanDatabaseId(majorDatabaseIdByName[nextMajor] ?? jurusanDatabaseId);
                    }}
                    className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
                  >
                    {majorOptions.map((option) => <option key={option} value={option}>{option}</option>)}
                  </select>
                </label>
                <label className="block">
                  <span className="text-sm font-black text-slate-700">Jurusan lainnya</span>
                  <input value={customMajor} onChange={(event) => setCustomMajor(event.target.value)} placeholder="Contoh: Teknik Mesin" className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition placeholder:text-slate-400 focus:border-[#0f2a5f] focus:bg-white" />
                </label>
              </div>

              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <label className="block">
                  <span className="text-sm font-black text-slate-700">ID sekolah database</span>
                  <input value={schoolDatabaseId} onChange={(event) => setSchoolDatabaseId(event.target.value)} placeholder="Contoh: 1" className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition placeholder:text-slate-400 focus:border-[#0f2a5f] focus:bg-white" />
                </label>
                <label className="block">
                  <span className="text-sm font-black text-slate-700">ID jurusan database</span>
                  <input value={jurusanDatabaseId} onChange={(event) => setJurusanDatabaseId(event.target.value)} placeholder="Opsional" className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition placeholder:text-slate-400 focus:border-[#0f2a5f] focus:bg-white" />
                </label>
                <label className="block">
                  <span className="text-sm font-black text-slate-700">Tahun ajaran</span>
                  <input value={tahunAjaran} onChange={(event) => setTahunAjaran(event.target.value)} placeholder="2025/2026" className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition placeholder:text-slate-400 focus:border-[#0f2a5f] focus:bg-white" />
                </label>
                <label className="block">
                  <span className="text-sm font-black text-slate-700">Jenjang</span>
                  <select value={jenisSekolah} onChange={(event) => setJenisSekolah(event.target.value as "SMA" | "SMK")} className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white">
                    <option value="SMA">SMA</option>
                    <option value="SMK">SMK</option>
                  </select>
                </label>
              </div>

              <label className="block">
                <span className="text-sm font-black text-slate-700">Tujuan proses SPK</span>
                <select value={tujuanKarir} onChange={(event) => setTujuanKarir(event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white">
                  <option value="kuliah">Melanjutkan kuliah</option>
                  <option value="kerja">Persiapan kerja</option>
                  <option value="pelatihan">Pelatihan keterampilan</option>
                  <option value="wirausaha">Wirausaha</option>
                </select>
              </label>

              <div className="rounded-[1.25rem] border border-emerald-100 bg-emerald-50 px-4 py-3 text-sm font-bold text-emerald-700">
                Tombol preview dan simpan akan mengirim file ke endpoint NestJS <span className="font-black">POST /nilai-siswa/import-excel</span>. Default API memakai http://localhost:3000, atau isi NEXT_PUBLIC_API_URL di .env.local bila backend memakai alamat lain.
              </div>

              <label className="flex cursor-pointer flex-col items-center justify-center rounded-[1.5rem] border-2 border-dashed border-blue-200 bg-[#f6f9ff] px-6 py-9 text-center transition hover:border-[#0f2a5f] hover:bg-[#eef5ff]">
                <input type="file" accept=".xlsx,.xls,.csv" onChange={handleFileChange} className="sr-only" />
                <div className="grid h-14 w-14 place-items-center rounded-2xl bg-white text-sm font-black text-[#0f2a5f] shadow-lg shadow-blue-950/10">XLSX</div>
                <p className="mt-4 text-base font-black text-slate-900">{fileName || "Pilih file nilai"}</p>
                <p className="mt-2 max-w-sm text-sm leading-6 text-slate-500">Format kolom: identitas siswa di awal, lalu mata pelajaran per semester. Mapel boleh berbeda karena backend akan memetakan ke kategori akademik.</p>
              </label>

              <div className="grid gap-3 lg:grid-cols-3">
                <a href="/templates/template-nilai-skilllens.xlsx" className="rounded-full border border-slate-200 bg-white px-6 py-4 text-center text-sm font-black text-slate-700 transition hover:-translate-y-0.5 hover:border-[#0f2a5f]/30 hover:text-[#0f2a5f]">
                  Download template
                </a>
                <button type="button" onClick={handlePreview} disabled={isLoading || isPersisting} className="rounded-full bg-slate-950 px-6 py-4 text-sm font-black text-white shadow-xl shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-[#0f2a5f] disabled:cursor-not-allowed disabled:opacity-60">
                  {isLoading ? "Membaca Excel..." : "Cek file / dry-run"}
                </button>
                <button type="button" onClick={handleImportToDatabase} disabled={!selectedFile || isLoading || isPersisting} className="rounded-full bg-[#0f2a5f] px-6 py-4 text-sm font-black text-white shadow-xl shadow-blue-950/20 transition hover:-translate-y-0.5 hover:bg-slate-950 disabled:cursor-not-allowed disabled:opacity-50">
                  {isPersisting ? "Menyimpan..." : "Import ke database"}
                </button>
              </div>

              {(apiMessage || apiError) && (
                <div className={`rounded-[1.25rem] px-4 py-3 text-sm font-bold leading-6 ${apiError ? "bg-rose-50 text-rose-700 ring-1 ring-rose-100" : "bg-emerald-50 text-emerald-700 ring-1 ring-emerald-100"}`}>
                  {apiError || apiMessage}
                </div>
              )}
            </div>
          </Panel>

          <Panel>
            <div className="flex flex-col justify-between gap-4 md:flex-row md:items-start">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Struktur template</p>
                <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Mapping sheet dan kolom</h2>
              </div>
              {preview && <StatusBadge status={preview.reviewRows ? "Perlu Review" : "Valid"} />}
            </div>

            {apiError && (
              <div className="mt-5 rounded-[1.25rem] border border-rose-100 bg-rose-50 px-4 py-3 text-sm font-bold leading-6 text-rose-700">
                {apiError}
              </div>
            )}
            {apiMessage && !apiError && (
              <div className="mt-5 rounded-[1.25rem] border border-emerald-100 bg-emerald-50 px-4 py-3 text-sm font-bold leading-6 text-emerald-700">
                {apiMessage}
              </div>
            )}

            {preview && (
              <div className="mt-6 space-y-5">
                <div className="grid gap-3 sm:grid-cols-3">
                  {[
                    ["Baris terbaca", preview.rowsDetected],
                    ["Valid", preview.validRows],
                    ["Review", preview.reviewRows],
                  ].map(([label, value]) => (
                    <div key={label} className="rounded-2xl bg-slate-50 p-4">
                      <p className="text-xs font-black uppercase tracking-[0.16em] text-slate-400">{label}</p>
                      <p className="mt-2 text-2xl font-black text-slate-950">{value}</p>
                    </div>
                  ))}
                </div>

                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="rounded-2xl bg-[#eef5ff] p-4">
                    <p className="text-xs font-black uppercase tracking-[0.16em] text-[#0f2a5f]">Mode proses</p>
                    <p className="mt-2 text-sm font-black text-slate-950">{preview.importMode === "import_and_generate" ? "Import tersimpan" : preview.importMode === "dry_run" ? "Dry-run backend" : "Data contoh"}</p>
                  </div>
                  <div className="rounded-2xl bg-slate-50 p-4">
                    <p className="text-xs font-black uppercase tracking-[0.16em] text-slate-400">Nilai mentah</p>
                    <p className="mt-2 text-2xl font-black text-slate-950">{preview.backendMeta?.jumlahNilai ?? "-"}</p>
                  </div>
                  <div className="rounded-2xl bg-slate-50 p-4">
                    <p className="text-xs font-black uppercase tracking-[0.16em] text-slate-400">Mapel terbaca</p>
                    <p className="mt-2 text-2xl font-black text-slate-950">{preview.backendMeta?.jumlahMapelTerdeteksi ?? preview.mappingMapel?.length ?? "-"}</p>
                  </div>
                </div>

                {preview.warnings?.length ? (
                  <div className="rounded-[1.35rem] bg-amber-50 p-4 text-sm font-bold leading-6 text-amber-700 ring-1 ring-amber-100">
                    <p className="font-black">Catatan validasi</p>
                    <ul className="mt-2 list-disc space-y-1 pl-5">
                      {preview.warnings?.slice(0, 4).map((warning) => <li key={warning}>{warning}</li>)}
                    </ul>
                  </div>
                ) : null}

                {preview.backendMeta?.database && (
                  <div className="rounded-[1.35rem] bg-emerald-50 p-4 ring-1 ring-emerald-100">
                    <p className="text-sm font-black text-emerald-800">Ringkasan penyimpanan database</p>
                    <div className="mt-3 grid gap-2 sm:grid-cols-3">
                      {Object.entries(preview.backendMeta.database ?? {}).map(([key, value]) => (
                        <div key={key} className="rounded-2xl bg-white px-3 py-3 shadow-sm">
                          <p className="text-[11px] font-black uppercase tracking-[0.12em] text-slate-400">{key.replaceAll("_", " ")}</p>
                          <p className="mt-1 text-lg font-black text-slate-950">{value ?? 0}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="rounded-[1.35rem] bg-slate-50 p-4">
                  <p className="text-sm font-black text-slate-950">Sheet terdeteksi</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {preview.sheetsDetected.map((sheet) => <span key={sheet} className="rounded-full bg-white px-3 py-1 text-xs font-black text-slate-600 shadow-sm">{sheet}</span>)}
                  </div>
                </div>

                <div className="rounded-[1.35rem] bg-slate-50 p-4">
                  <p className="text-sm font-black text-slate-950">Kolom utama</p>
                  <div className="mt-3 grid gap-2 sm:grid-cols-3">
                    {preview.mappedColumns.map((column) => <div key={column} className="rounded-2xl bg-white px-3 py-3 text-xs font-black text-slate-600 shadow-sm">{column}</div>)}
                  </div>
                </div>

                {preview.mappingMapel?.length ? (
                  <div className="rounded-[1.35rem] bg-slate-50 p-4">
                    <div className="flex items-center justify-between gap-3">
                      <p className="text-sm font-black text-slate-950">Mapping mapel ke kategori</p>
                      <span className="rounded-full bg-white px-3 py-1 text-xs font-black text-[#0f2a5f] shadow-sm">{preview.mappingMapel.length} mapel</span>
                    </div>
                    <div className="mt-3 grid max-h-56 gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
                      {preview.mappingMapel.slice(0, 24).map((mapping) => (
                        <div key={`${mapping.mapel}-${mapping.kategori}`} className="flex items-center justify-between gap-3 rounded-2xl bg-white px-3 py-3 text-xs shadow-sm">
                          <span className="font-black text-slate-700">{mapping.mapel}</span>
                          <span className="rounded-full bg-[#eef5ff] px-2 py-1 font-black text-[#4c51d9]">{mapping.kategori}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : null}

                <GradeTable students={visibleStudents.slice(0, 6)} semester={selectedSemester} />
              </div>
            )}
          </Panel>
        </div>
      )}

      {activeSection === "nilai" && (
        <Panel className="mt-6">
          <div className="flex flex-col justify-between gap-5 xl:flex-row xl:items-end">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Data akademik</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Nilai per semester</h2>
              <p className="mt-2 max-w-3xl text-sm font-semibold leading-7 text-slate-500">Guru dapat menelusuri nilai siswa, memeriksa baris yang perlu review, dan memastikan data akademik siap masuk ke perhitungan SPK.</p>
            </div>
            <div className="flex flex-col gap-3 sm:flex-row">
              <input value={studentSearch} onChange={(event) => setStudentSearch(event.target.value)} placeholder="Cari nama, NISN, kelas..." className="rounded-full border border-slate-200 bg-slate-50 px-5 py-3 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white" />
              <select value={selectedSemester} onChange={(event) => setSelectedSemester(Number(event.target.value) as 1 | 2 | 3 | 4 | 5)} className="rounded-full border border-slate-200 bg-slate-50 px-5 py-3 text-sm font-black outline-none transition focus:border-[#0f2a5f] focus:bg-white">
                {[1, 2, 3, 4, 5].map((semester) => <option key={semester} value={semester}>Semester {semester}</option>)}
              </select>
            </div>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-4">
            <MetricCard label="Rata-rata" value={`${summary.averageScore}`} detail="Akademik semua semester." icon="∑" />
            <MetricCard label="Sheet" value={`${summary.importedSheets}`} detail="Semester yang disiapkan." icon="▤" tone="cyan" />
            <MetricCard label="Jurusan" value={selectedMajor} detail="Kelompok data aktif." icon="↗" tone="amber" />
            <MetricCard label="Siap proses" value={`${summary.readyForTopsis}`} detail="Profil akademik valid." icon="✓" tone="emerald" />
          </div>

          <div className="mt-6"><GradeTable students={visibleStudents} semester={selectedSemester} /></div>
        </Panel>
      )}

      {activeSection === "bimbingan" && (
        <div className="mt-6 grid gap-6 xl:grid-cols-[0.85fr_1.15fr]">
          <Panel>
            <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Bimbingan siswa</p>
            <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Agenda pendampingan</h2>
            <p className="mt-2 text-sm font-semibold leading-7 text-slate-500">Pilih siswa untuk melihat konteks bimbingan, hasil keputusan, prioritas, dan catatan arahan.</p>
            <div className="my-5 grid gap-3 sm:grid-cols-2">
              <input value={studentSearch} onChange={(event) => setStudentSearch(event.target.value)} placeholder="Cari siswa/topik..." className="rounded-full border border-slate-200 bg-slate-50 px-5 py-3 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white" />
              <select value={guidanceFilter} onChange={(event) => setGuidanceFilter(event.target.value)} className="rounded-full border border-slate-200 bg-slate-50 px-5 py-3 text-sm font-black outline-none transition focus:border-[#0f2a5f] focus:bg-white">
                {["Semua", "Menunggu", "Dijadwalkan", "Selesai"].map((status) => <option key={status}>{status}</option>)}
              </select>
            </div>
            <GuidanceList cases={filteredGuidance} activeId={selectedGuidance?.id ?? ""} onSelect={setSelectedGuidanceId} />
          </Panel>

          <Panel>
            {selectedGuidance ? (
              <div>
                <div className="flex flex-col justify-between gap-4 md:flex-row md:items-start">
                  <div>
                    <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Detail pendampingan</p>
                    <h2 className="mt-2 text-3xl font-black tracking-[-0.04em] text-slate-950">{selectedGuidance.studentName}</h2>
                    <p className="mt-2 text-sm font-bold text-slate-500">{selectedGuidance.className} · {selectedGuidance.topic}</p>
                  </div>
                  <StatusBadge status={selectedGuidance.status} />
                </div>

                <div className="mt-6 grid gap-4 md:grid-cols-3">
                  <div className="rounded-2xl bg-slate-50 p-4"><p className="text-xs font-black uppercase tracking-[0.18em] text-slate-400">Prioritas</p><p className="mt-2 font-black text-slate-950">{selectedGuidance.priority}</p></div>
                  <div className="rounded-2xl bg-slate-50 p-4"><p className="text-xs font-black uppercase tracking-[0.18em] text-slate-400">Jadwal</p><p className="mt-2 font-black text-slate-950">{selectedGuidance.schedule}</p></div>
                  <div className="rounded-2xl bg-slate-50 p-4"><p className="text-xs font-black uppercase tracking-[0.18em] text-slate-400">Arah utama</p><p className="mt-2 font-black text-slate-950">{selectedGuidance.recommendation}</p></div>
                </div>

                <div className="mt-6 rounded-[1.5rem] bg-[#eef5ff] p-5">
                  <div className="flex items-center justify-between gap-4">
                    <p className="text-sm font-black text-[#4c51d9]">Progress pendampingan</p>
                    <p className="text-sm font-black text-[#4c51d9]">{selectedGuidance.progress}%</p>
                  </div>
                  <div className="mt-3"><ProgressBar value={selectedGuidance.progress} /></div>
                  <p className="mt-4 text-sm font-bold leading-7 text-slate-700">{selectedGuidance.lastNote}</p>
                </div>

                <label className="mt-6 block">
                  <span className="text-sm font-black text-slate-700">Catatan arahan guru</span>
                  <textarea value={note} onChange={(event) => setNote(event.target.value)} className="mt-2 min-h-36 w-full rounded-[1.35rem] border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold leading-7 outline-none transition focus:border-[#0f2a5f] focus:bg-white" />
                </label>

                <div className="mt-5 grid gap-3 sm:grid-cols-3">
                  <button type="button" className="rounded-full bg-slate-950 px-5 py-3 text-sm font-black text-white transition hover:-translate-y-0.5 hover:bg-[#0f2a5f]">Simpan catatan</button>
                  <button type="button" className="rounded-full border border-slate-200 bg-white px-5 py-3 text-sm font-black text-slate-700 transition hover:-translate-y-0.5 hover:border-indigo-300 hover:text-[#0f2a5f]">Atur jadwal</button>
                  <button type="button" className="rounded-full bg-emerald-50 px-5 py-3 text-sm font-black text-emerald-700 transition hover:-translate-y-0.5">Tandai selesai</button>
                </div>
              </div>
            ) : (
              <div className="grid min-h-[360px] place-items-center text-center text-slate-500">Pilih agenda bimbingan.</div>
            )}
          </Panel>
        </div>
      )}

      {activeSection === "akun" && (
        <Panel className="mt-6">
          <div className="flex flex-col justify-between gap-5 xl:flex-row xl:items-end">
            <div>
              <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Akun siswa</p>
              <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Buat akses siswa dari data nilai</h2>
              <p className="mt-2 max-w-3xl text-sm font-semibold leading-7 text-slate-500">Siswa menggunakan akun yang dibuat sekolah sehingga identitas dan data akademik tetap konsisten.</p>
            </div>
            <button type="button" onClick={handleGenerateAccounts} disabled={!students.length || isLoading} className="rounded-full bg-[#0f2a5f] px-6 py-4 text-sm font-black text-white shadow-xl shadow-blue-950/20 transition hover:-translate-y-0.5 hover:bg-slate-950 disabled:cursor-not-allowed disabled:opacity-50">
              {isLoading ? "Membuat akses..." : "Generate akun siswa"}
            </button>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-3">
            <MetricCard label="Siswa" value={`${students.length}`} detail="Sumber dari import nilai." icon="👥" />
            <MetricCard label="Akun dibuat" value={`${accounts.length}`} detail="Siap dibagikan ke siswa." icon="✓" tone="emerald" />
            <MetricCard label="Draft" value={`${accounts.filter((item) => item.status === "Draft").length}`} detail="Butuh pemeriksaan data." icon="!" tone="amber" />
          </div>

          <div className="mt-6 overflow-hidden rounded-[1.35rem] border border-slate-100">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[780px] text-left text-sm">
                <thead className="bg-slate-50 text-xs font-black uppercase tracking-[0.16em] text-slate-400">
                  <tr>
                    <th className="px-4 py-4">Nama</th>
                    <th className="px-4 py-4">Username</th>
                    <th className="px-4 py-4">Password awal</th>
                    <th className="px-4 py-4">Hak akses</th>
                    <th className="px-4 py-4">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 bg-white">
                  {(accounts.length ? accounts : students.slice(0, 6).map((student) => ({ studentId: student.id, name: student.name, username: `${student.nisn}@skilllens`, password: "Belum dibuat", role: "siswa" as const, status: "Draft" as const }))).map((account) => (
                    <tr key={account.studentId} className="transition hover:bg-indigo-50/35">
                      <td className="px-4 py-4 font-black text-slate-950">{account.name}</td>
                      <td className="px-4 py-4 font-bold text-slate-600">{account.username}</td>
                      <td className="px-4 py-4 font-black text-[#0f2a5f]">{account.password}</td>
                      <td className="px-4 py-4 font-bold text-slate-600">Portal siswa</td>
                      <td className="px-4 py-4"><StatusBadge status={account.status} /></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </Panel>
      )}

      {activeSection === "metode" && (
        <div className="mt-6 grid gap-6 xl:grid-cols-[1fr_0.9fr]">
          <Panel>
            <p className="text-xs font-black uppercase tracking-[0.2em] text-[#0f2a5f]">Posisi data Fuzzy + TOPSIS</p>
            <h2 className="mt-2 text-2xl font-black tracking-[-0.03em] text-slate-950">Kriteria yang dikelola sekolah</h2>
            <p className="mt-2 text-sm font-semibold leading-7 text-slate-500">Nilai akademik menjadi kriteria terukur. Data nonakademik dari siswa melengkapi profil agar peringkat akhir lebih personal dan dapat dijelaskan.</p>
            <div className="mt-6 grid gap-4 md:grid-cols-2">
              {[
                ["C1 Akademik", "Nilai Bahasa Indonesia, Bahasa Inggris, Matematika, dan mapel lain dari semester 1 sampai 5."],
                ["C2 Minat", "Minat dipilih siswa dari katalog besar untuk membentuk sinyal preferensi."],
                ["C3 Bakat dan skill", "Hobi, bakat, skill, dan pengalaman digunakan sebagai penguat kecocokan."],
                ["C4 Tujuan", "Rencana kuliah, pelatihan, kerja, serta kendala dipakai untuk menyesuaikan bobot keputusan."],
              ].map(([title, text]) => (
                <div key={title} className="rounded-[1.35rem] bg-slate-50 p-5">
                  <p className="font-black text-slate-950">{title}</p>
                  <p className="mt-2 text-sm font-semibold leading-6 text-slate-500">{text}</p>
                </div>
              ))}
            </div>
          </Panel>
          <Panel className="bg-slate-950 text-white">
            <p className="text-xs font-black uppercase tracking-[0.2em] text-cyan-200">Alur pengolahan</p>
            <h2 className="mt-2 text-2xl font-black tracking-[-0.03em]">Dari import nilai sampai roadmap</h2>
            <div className="mt-6 space-y-4">
              {["Validasi template nilai", "Normalisasi kriteria akademik", "Fuzzyfikasi minat, hobi, bakat, dan tujuan", "Pemeringkatan alternatif dengan TOPSIS", "Pemilihan satu arah karier dan penyusunan roadmap"].map((item, index) => (
                <div key={item} className="flex gap-4 rounded-[1.25rem] border border-white/10 bg-white/8 p-4">
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-cyan-300 text-sm font-black text-slate-950">{index + 1}</div>
                  <p className="text-sm font-bold leading-6 text-slate-200">{item}</p>
                </div>
              ))}
            </div>
          </Panel>
        </div>
      )}
    </DashboardShell>
  );
}
