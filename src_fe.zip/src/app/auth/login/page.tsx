"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { apiFetch } from "../../../lib/axios";
import { AppShell } from "../../../components/layout/AppShell";

const accessProfiles = [
  {
    key: "pembimbing",
    title: "Pembimbing sekolah",
    email: "guru@skilllens.id",
    password: "guru123",
    destination: "/guru",
    description: "Mengelola nilai, akun siswa, dan agenda bimbingan karier.",
  },
  {
    key: "siswa",
    title: "Akses siswa",
    email: "0012457788@skilllens",
    password: "SL-7788-01",
    destination: "/siswa",
    description: "Melengkapi profil, melihat hasil keputusan, dan menjalankan roadmap.",
  },
  {
    key: "admin",
    title: "Administrator",
    email: "admin@skilllens.id",
    password: "admin123",
    destination: "/admin/dashboard",
    description: "Memantau sekolah, verifikasi akun, dan kualitas data sistem.",
  },
] as const;

type AccessKey = (typeof accessProfiles)[number]["key"];

export default function LoginPage() {
  const router = useRouter();
  const [accessKey, setAccessKey] = useState<AccessKey>("pembimbing");
  const activeProfile = useMemo(() => accessProfiles.find((item) => item.key === accessKey) ?? accessProfiles[0], [accessKey]);
  const [email, setEmail] = useState<string>(activeProfile.email);
  const [password, setPassword] = useState<string>(activeProfile.password);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const selectProfile = (key: AccessKey) => {
    const profile = accessProfiles.find((item) => item.key === key) ?? accessProfiles[0];
    setAccessKey(key);
    setEmail(profile.email);
    setPassword(profile.password);
  };

  return (
    <AppShell
      active="auth"
      eyebrow="Autentikasi SkillLens"
      title="Masuk ke ruang kerja SkillLens."
      description="Akun siswa dibuat oleh sekolah melalui data nilai yang telah diverifikasi. Pendaftaran mandiri hanya tersedia untuk guru atau pembimbing sekolah."
    >
      <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
        <section className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-900/5 md:p-8">
          <div className="mb-8">
            <p className="text-sm font-black uppercase tracking-[0.22em] text-[#0f2a5f]">Form masuk</p>
            <h2 className="mt-3 text-3xl font-black tracking-[-0.04em] text-slate-950">Gunakan akun yang sudah terdaftar</h2>
            <p className="mt-3 text-sm leading-7 text-slate-500">Masukkan email atau username dan password sesuai akses yang diberikan sekolah.</p>
          </div>

          <form
            className="space-y-5"
            onSubmit={async (event) => {
              event.preventDefault();
              setError("");
              setIsLoading(true);
              try {
                const data = await apiFetch<{ token: string; user: { role: string; id: number; nama: string; username: string } }>("/auth/login", {
                  method: "POST",
                  body: JSON.stringify({ username: email, password }),
                });
                localStorage.setItem("skilllens_token", data.token);
                localStorage.setItem("skilllens_user", JSON.stringify(data.user));
                const role = data.user.role;
                router.push(role === "admin" ? "/admin/dashboard" : role === "siswa" ? "/siswa" : "/guru");
              } catch (err) {
                setError(err instanceof Error ? err.message : "Login gagal. Periksa username dan password.");
              } finally {
                setIsLoading(false);
              }
            }}
          >
            <label className="block">
              <span className="text-sm font-black text-slate-700">Email / username</span>
              <input value={email} onChange={(event) => setEmail(event.target.value)} className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white" />
            </label>
            <label className="block">
              <span className="text-sm font-black text-slate-700">Password</span>
              <input value={password} onChange={(event) => setPassword(event.target.value)} type="password" className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white" />
            </label>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <label className="flex items-center gap-3 text-sm font-bold text-slate-600">
                <input type="checkbox" className="h-4 w-4 accent-[#0f2a5f]" />
                Ingat perangkat ini
              </label>
              <a className="text-sm font-black text-[#0f2a5f]" href="#bantuan-login">Lupa password?</a>
            </div>

            {error && <div className="rounded-2xl bg-rose-50 p-4 text-sm font-bold text-rose-700 ring-1 ring-rose-100">{error}</div>}
            <button type="submit" disabled={isLoading} className="flex w-full justify-center rounded-full bg-slate-950 px-6 py-4 text-sm font-black text-white shadow-xl shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-[#0f2a5f] disabled:opacity-60">
              {isLoading ? "Memeriksa akun..." : "Masuk ke dashboard"}
            </button>
          </form>

          <div className="mt-8 rounded-[1.5rem] bg-slate-50 p-5">
            <p className="font-black text-slate-950">Belum memiliki akun pembimbing?</p>
            <p className="mt-1 text-sm font-bold leading-6 text-slate-500">Ajukan pendaftaran terlebih dahulu. Setelah diverifikasi, akun dapat digunakan untuk mengelola data sekolah.</p>
            <Link href="/auth/register" className="mt-4 inline-flex rounded-full bg-white px-5 py-3 text-sm font-black text-[#0f2a5f] shadow-sm transition hover:-translate-y-0.5 hover:bg-[#eef5ff]">
              Ajukan akun guru
            </Link>
          </div>
        </section>

        <aside className="space-y-6">
          <section className="rounded-[2rem] bg-slate-950 p-6 text-white shadow-xl shadow-slate-900/10 md:p-8">
            <p className="text-sm font-black uppercase tracking-[0.24em] text-cyan-200">Akses cepat presentasi</p>
            <h2 className="mt-3 text-3xl font-black tracking-[-0.04em]">Gunakan akun yang sudah tersimpan di database backend.</h2>
            <div className="mt-6 grid gap-3">
              {accessProfiles.map((profile) => {
                const active = accessKey === profile.key;
                return (
                  <button
                    key={profile.key}
                    type="button"
                    onClick={() => selectProfile(profile.key)}
                    className={`rounded-[1.25rem] border p-4 text-left transition hover:-translate-y-0.5 ${
                      active ? "border-cyan-300 bg-white text-slate-950" : "border-white/10 bg-white/8 text-white hover:bg-white/14"
                    }`}
                  >
                    <p className="font-black">{profile.title}</p>
                    <p className={`mt-1 text-sm font-semibold leading-6 ${active ? "text-slate-500" : "text-slate-300"}`}>{profile.description}</p>
                  </button>
                );
              })}
            </div>
          </section>

          <section id="bantuan-login" className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-900/5 md:p-8">
            <p className="text-sm font-black uppercase tracking-[0.24em] text-[#0f2a5f]">Keamanan akses</p>
            <div className="mt-5 space-y-4">
              {[
                "Siswa masuk menggunakan akun yang dibuat oleh pembimbing sekolah.",
                "Data akademik tetap mengikuti template nilai yang dikelola sekolah.",
                "Hak akses menentukan halaman yang tampil setelah proses masuk berhasil.",
              ].map((item, index) => (
                <div key={item} className="flex gap-4 rounded-[1.25rem] bg-slate-50 p-4">
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-[#0f2a5f] text-sm font-black text-white">{index + 1}</div>
                  <p className="text-sm font-bold leading-6 text-slate-600">{item}</p>
                </div>
              ))}
            </div>
          </section>
        </aside>
      </div>
    </AppShell>
  );
}
