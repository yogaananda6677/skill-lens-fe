"use client";

import Link from "next/link";
import { useState } from "react";
import { AppShell } from "../../../components/layout/AppShell";

export default function RegisterPage() {
  const [submitted, setSubmitted] = useState(false);

  return (
    <AppShell
      active="auth"
      eyebrow="Pendaftaran Guru"
      title="Daftar akun guru."
      description="Pendaftaran digunakan oleh guru atau pembimbing sekolah. Data sekolah dapat dipilih setelah akun berhasil dibuat dan masuk ke dashboard."
    >
      <div className="grid gap-6 lg:grid-cols-[1.05fr_0.95fr]">
        <section className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-900/5 md:p-8">
          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-start">
            <div>
              <p className="text-sm font-black uppercase tracking-[0.24em] text-[#0f2a5f]">
                Identitas guru
              </p>
              <h2 className="mt-3 text-3xl font-black tracking-[-0.04em] text-slate-950">
                Data akun dan guru
              </h2>
              <p className="mt-3 max-w-2xl text-sm leading-7 text-slate-500">
                Isi data akun dan identitas guru. Pemilihan sekolah dilakukan setelah akun berhasil dibuat.
              </p>
            </div>
            <span className="rounded-full bg-emerald-50 px-4 py-2 text-xs font-black text-emerald-700">
              Register Guru
            </span>
          </div>

          <form
            className="mt-8 grid gap-4 md:grid-cols-2"
            onSubmit={(event) => {
              event.preventDefault();
              setSubmitted(true);
            }}
          >
            <label className="block">
              <span className="text-sm font-black text-slate-700">Nama lengkap</span>
              <input
                name="nama"
                placeholder="Masukkan nama lengkap"
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
              />
            </label>

            <label className="block">
              <span className="text-sm font-black text-slate-700">NIP / NUPTK</span>
              <input
                name="nip"
                placeholder="Masukkan NIP / NUPTK"
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
              />
            </label>



            <label className="block">
              <span className="text-sm font-black text-slate-700">Nomor HP</span>
              <input
                name="no_hp"
                placeholder="Masukkan nomor HP"
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
              />
            </label>

            <label className="block">
              <span className="text-sm font-black text-slate-700">Username</span>
              <input
                name="username"
                placeholder="Masukkan username"
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
              />
            </label>

            <label className="block">
              <span className="text-sm font-black text-slate-700">Email aktif</span>
              <input
                name="email"
                type="email"
                placeholder="Masukkan email aktif"
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
              />
            </label>

            <label className="block">
              <span className="text-sm font-black text-slate-700">Password</span>
              <input
                name="password"
                type="password"
                placeholder="Masukkan password"
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
              />
            </label>

            <label className="block">
              <span className="text-sm font-black text-slate-700">Konfirmasi password</span>
              <input
                name="password_confirmation"
                type="password"
                placeholder="Ulangi password"
                className="mt-2 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 text-sm font-bold outline-none transition focus:border-[#0f2a5f] focus:bg-white"
              />
            </label>

            {submitted && (
              <div className="rounded-2xl bg-emerald-50 p-4 text-sm font-bold leading-6 text-emerald-800 md:col-span-2">
                Akun guru berhasil didaftarkan. Silakan lanjutkan memilih sekolah setelah login.
              </div>
            )}

            <div className="flex flex-col gap-3 md:col-span-2 sm:flex-row">
              <button
                type="submit"
                className="rounded-full bg-slate-950 px-6 py-4 text-sm font-black text-white shadow-xl shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-[#0f2a5f]"
              >
                Daftar akun
              </button>

              <Link
                href="/auth/login"
                className="rounded-full border border-slate-200 bg-white px-6 py-4 text-center text-sm font-black text-slate-700 transition hover:-translate-y-0.5 hover:border-[#0f2a5f]/30 hover:text-[#0f2a5f]"
              >
                Sudah punya akun
              </Link>
            </div>
          </form>
        </section>

        <aside className="space-y-6">
          <section className="rounded-[2rem] bg-slate-950 p-6 text-white shadow-xl shadow-slate-900/10 md:p-8">
            <p className="text-sm font-black uppercase tracking-[0.24em] text-cyan-200">
              Setelah register
            </p>
            <h2 className="mt-3 text-3xl font-black tracking-[-0.04em]">
              Lengkapi sekolah setelah login
            </h2>
            <p className="mt-4 text-sm font-bold leading-7 text-slate-200">
              Guru dapat membuat akun terlebih dahulu. Data sekolah akan dipilih atau dilengkapi
              melalui dashboard setelah proses login berhasil.
            </p>
          </section>

          <section className="rounded-[2rem] bg-white p-6 shadow-xl shadow-slate-900/5 md:p-8">
            <p className="text-sm font-black uppercase tracking-[0.24em] text-[#0f2a5f]">
              Alur pendaftaran
            </p>

            <div className="mt-5 space-y-4">
              {[
                "Guru mengisi data akun dan identitas pribadi.",
                "Guru login menggunakan akun yang sudah dibuat.",
                "Guru memilih atau melengkapi data sekolah melalui dashboard.",
              ].map((item, index) => (
                <div key={item} className="flex gap-4 rounded-[1.25rem] bg-slate-50 p-4">
                  <div className="grid h-9 w-9 shrink-0 place-items-center rounded-2xl bg-[#0f2a5f] text-sm font-black text-white">
                    {index + 1}
                  </div>
                  <p className="text-sm font-bold leading-6 text-slate-600">{item}</p>
                </div>
              ))}
            </div>
          </section>
        </aside>
      </div>
    </AppShell>
  );
}