import Link from "next/link";
import type { ReactNode } from "react";

type AppShellProps = {
  active?: "home" | "guru" | "siswa" | "admin" | "auth";
  eyebrow?: string;
  title?: string;
  description?: string;
  children: ReactNode;
};

const publicNav = [
  { href: "/#fitur", label: "Fitur" },
  { href: "/#alur", label: "Alur" },
  { href: "/#metode", label: "Metode" },
  { href: "/#kontak", label: "Bantuan" },
] as const;

export function AppShell({ eyebrow, title, description, children }: AppShellProps) {
  return (
    <main className="min-h-screen bg-[#f2f5fb] text-slate-950">
      <div className="fixed inset-x-0 top-0 z-50 border-b border-white/70 bg-white/88 backdrop-blur-2xl">
        <nav className="mx-auto flex w-[min(1220px,calc(100%-32px))] items-center justify-between gap-4 py-4">
          <Link href="/" className="flex items-center gap-3">
            <div className="grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-[#0f2a5f] to-[#38bdf8] text-sm font-black text-white shadow-lg shadow-blue-950/20">
              SL
            </div>
            <div className="hidden sm:block">
              <p className="text-base font-black tracking-tight">SkillLens</p>
              <p className="text-xs font-bold text-slate-500">Career Decision Support</p>
            </div>
          </Link>

          <div className="hidden items-center gap-8 text-sm font-black text-slate-500 md:flex">
            {publicNav.map((item) => (
              <Link key={item.href} href={item.href} className="transition hover:text-[#0f2a5f]">
                {item.label}
              </Link>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <Link
              href="/auth/login"
              className="hidden rounded-full border border-slate-200 bg-white px-4 py-3 text-sm font-black text-slate-700 shadow-sm transition hover:-translate-y-0.5 hover:border-[#0f2a5f]/30 hover:text-[#0f2a5f] sm:inline-flex"
            >
              Masuk
            </Link>
            <Link
              href="/auth/register"
              className="rounded-full bg-slate-950 px-5 py-3 text-sm font-black text-white shadow-lg shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-[#0f2a5f]"
            >
              Daftar Guru
            </Link>
          </div>
        </nav>
      </div>

      {(title || description || eyebrow) && (
        <section className="relative overflow-hidden bg-[#0b1530] px-4 pb-14 pt-32 text-white md:pb-20 md:pt-36">
          <div className="absolute inset-0 opacity-45">
            <div className="absolute left-[-120px] top-[-180px] h-[380px] w-[380px] rounded-full bg-[#38bdf8] blur-[120px]" />
            <div className="absolute bottom-[-180px] right-[-80px] h-[460px] w-[460px] rounded-full bg-[#0f2a5f] blur-[140px]" />
          </div>
          <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.06)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.06)_1px,transparent_1px)] bg-[size:72px_72px]" />
          <div className="relative z-10 mx-auto w-[min(1220px,calc(100%-32px))]">
            {eyebrow && (
              <div className="mb-6 inline-flex items-center gap-3 rounded-full border border-cyan-200/20 bg-white/10 px-4 py-2 text-sm font-black text-cyan-100 backdrop-blur">
                <span className="h-2 w-2 rounded-full bg-cyan-300 shadow-[0_0_16px_rgba(103,232,249,0.9)]" />
                {eyebrow}
              </div>
            )}
            {title && (
              <h1 className="max-w-5xl text-4xl font-black leading-[1.02] tracking-[-0.05em] md:text-6xl lg:text-7xl">
                {title}
              </h1>
            )}
            {description && (
              <p className="mt-6 max-w-3xl text-base leading-8 text-slate-300 md:text-lg">
                {description}
              </p>
            )}
          </div>
        </section>
      )}

      <div className="mx-auto w-[min(1220px,calc(100%-32px))] py-8 md:py-12">{children}</div>
    </main>
  );
}
